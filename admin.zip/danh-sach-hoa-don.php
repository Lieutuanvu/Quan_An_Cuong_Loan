<?php
include_once("cosodulieu.php");

//Kiểm tra xem, nếu đăng nhập rồi thì thôi, chưa thì quay về block.php
if (!isset($_SESSION['chuthe'])){
    header('Location: block.php');
}

date_default_timezone_set('Asia/Ho_Chi_Minh');
$thang=date('m');
$nam=date('Y');
if (!isset($_GET['thang']) || !isset($_GET['nam'])){ //Nếu không get được tháng năm thì thôi, in tất cả
    include_once("tao_phan_trang.php");
    $ds_hoadon=$ketnoi->query("SELECT `nguoi_xac_nhan`,`id_hoadon`, `trang_thai`, `ngaytao`,`thanhtien`,`gio_tao`  FROM `hoadon_vanchuyen` ORDER BY `id_hoadon` DESC LIMIT $bat_dau_hien_thi,$hien_thi");
} else 
if (isset($_GET['thang']) && isset($_GET['nam'])){ //Nếu get được tháng với năm thì in hoá đơn theo điều kiện đó
    $nam=$_GET['nam'];
    $thang=$_GET['thang'];
    include_once("tao_phan_trang.php");
    $ds_hoadon=$ketnoi->query("SELECT `nguoi_xac_nhan`,`id_hoadon`, `trang_thai`, `ngaytao`,`thanhtien`,`gio_tao`  FROM `hoadon_vanchuyen` WHERE `thang_tao`='$thang' AND `nam_tao`='$nam' ORDER BY `id_hoadon` DESC LIMIT $bat_dau_hien_thi,$hien_thi");
}

?>
<html class="no-js" lang="vi">
<head>
    <!--Chèn meta.php vào-->
    <?php include("meta.php"); ?>
</head>
<body class="body-bg">
    <!-- Load trước khi tải xong trang-->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!-- Load trước khi tải xong trang-->
    <!-- main wrapper start -->
    <div class="horizontal-main-wrapper">
        <!-- chèn mainhead.php vào đây -->
        <?php include("mainheader.php"); ?>
        <!-- chèn mainhead.php vào đây -->
        <!-- Đặt menu -->
        <?php include("menu.php");?>
        <!-- Đặt menu -->
            <div class="main-content-inner">
                <div class="row">
                    <!-- danh sách hoá đơn -->
                    <div class="col-12 mt-5">
                        <div class="card">
                            <div class="card-body">
                            <h4 class="header-title">Danh sách hoá đơn <?php echo "tháng ".$thang." năm ".$nam;?></h4>
                                <!-- form tìm kiếm tháng năm hoá đơn -->
                                    <form action="danh-sach-hoa-don.php" method="GET">
                                        <div class="form-row align-items-center">
                                            <div class="col-sm-3 my-1">
                                                <select name="thang" class="form-control">
                                                    <option value="<?php echo $thang;?>">Tháng <?php echo $thang;?></option>
                                                    <?php
                                                    for ($i=1;$i<=12;$i++){
                                                        if ($i!=$thang){
                                                            echo'<option value="'.$i.'">Tháng '.$i.'</option>';
                                                        }
                                                    } 
                                                    ?>
                                                </select>
                                            </div>                            
                                            <div class="col-sm-3 my-1">
                                                <select name="nam" class="form-control">
                                                    <option value="<?php echo $nam;?>">Năm <?php echo $nam;?></option>
                                                    <?php
                                                    $nam_hien_tai=date('Y');
                                                    for ($i=2020;$i<=$nam_hien_tai;$i++){
                                                        if ($i!=$nam){
                                                        echo'<option value="'.$i.'">Năm '.$i.'</option>';
                                                        }
                                                    } 
                                                    ?>
                                                </select>                                            
                                            </div>
                                            <div class="col-auto my-1">
                                                <button type="submit" class="btn btn-primary">XEM</button>
                                            </div>
                                        </div>
                                    </form>
                                 <!-- form tìm kiếm tháng năm hoá đơn -->
                                <div class="single-table">
                                    <div class="table-responsive">
                                        <table class="table table-hover progress-table text-center">
                                            <thead class="text-uppercase">
                                                <tr>
                                                    <th scope="col">Mã HĐ</th>
                                                    <th scope="col">Ngày tạo</th>
                                                    <th scope="col">Giờ tạo</th>
                                                    <th scope="col">Giá tiền (VND)</th>
                                                    <th scope="col">Trạng thái</th>
                                                    <th scope="col">Nhân viên</th>
                                                    <th scope="col">Xem chi tiết</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                if ($ds_hoadon && $ds_hoadon->num_rows>0){
                                                    while($xuat=$ds_hoadon->fetch_assoc()){
                                                
                                                        if ($xuat['trang_thai']!=-1 && (date_format(new DateTime($xuat['ngaytao']),'m')==$thang) && (date_format(new DateTime($xuat['ngaytao']),'Y')==$nam)){
                                                            //Nếu trạng thái !=-1 nghĩa là hoá đơn không bị huỷ mới hiển thị
                                                            echo '<tr>';
                                                            echo    '<th scope="row">'.$xuat['id_hoadon'].'</th>';
                                                            echo    '<th scope="row">'.date_format(new DateTime($xuat['ngaytao']),'d-m-Y').'</th>';
                                                            echo    '<th scope="row">'.date_format(new DateTime($xuat['gio_tao']),'H:i:s').'</th>';
                                                            echo    '<td>'.number_format($xuat['thanhtien']).'</td>';
                                                            if($xuat['trang_thai']==1){
                                                            echo    '<td><span class="status-p bg-success">ĐÃ THANH TOÁN</span></td>';
                                                            } else if ($xuat['trang_thai']==0){
                                                            echo    '<td><span class="status-p bg-primary">CHƯA THANH TOÁN</span></td>';
                                                            }

                                                            //Lấy tên nhân viên ra
                                                            $id_nv="";
                                                            $ten_nv="";
                                                            $ma_nv=$xuat['nguoi_xac_nhan'];
                                                            $lay_ten_nv=$ketnoi->query("SELECT `hoten`,`id` FROM `nhanvien` WHERE `ma_nv`='$ma_nv'");
                                                            if ($lay_ten_nv && $lay_ten_nv->num_rows>0){
                                                                while($xuat_ten_nv=$lay_ten_nv->fetch_assoc()){
                                                                    $ten_nv=$xuat_ten_nv['hoten'];
                                                                    $id_nv=$xuat_ten_nv['id'];
                                                                }
                                                            }
                                                            echo    '<td scope="row"><a scope="row" target="_blank" href="thong-tin-nhan-vien.php?id='.$id_nv.'">'.$ten_nv.'</a></td>';    
                                                            echo    '<td><a target="_blank" href="hoa-don.php?id='.$xuat['id_hoadon'].'">XEM</a></td>';     
                                                            echo '</tr>';
                                                            }
                                                        }
                                                    }
                                                ?>        

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <?php
                                        //Tiếp tục của if ($ds_hoadon->num_rows>0) ở trên
                                        if  ($ds_hoadon && $ds_hoadon->num_rows<=0) { //Tháng và năm này không có hoá đơn thì không hiển thị
                                             echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                                                        <strong><h4>Tháng '.$thang.' năm '.$nam.' không có hoá đơn</h4></strong>
                                                    </div>';    
                                                }
                                ?>
                            </div>
                            <!--Hiển thị phân trang-->
                            <div class="col-lg-12 col-md-6 mt-5">
                                <div class="card">
                                    <div class="card-body">
                                            <ul class="pagination justify-content-center">          
                                                <?php
                                                //In phân trang
                                                for($i=1;$i<=$so_trang;$i++){
                                                    if ($i==$trang_hien_tai){//Nếu đang ở trang đó thì vô hiệu pagination đó
                                                    echo '<li class="page-item active">';
                                                    } else{
                                                    echo '<li class="page-item">';
                                                    }
                                                    echo'<a tabindex="-1" class="page-link" href="danh-sach-hoa-don.php?thang='.$thang.'&nam='.$nam.'&trang='.$i.'">'.$i.'</a></li>';
                                                }
                                                ?>
                                            </ul>
                                        </nav>
                                    </div>
                                </div>
                            </div>
                            <!--Hiển thị phân trang-->                            
                        </div>
                        
                    </div>
                    <!-- Danh sách hoá đơn end -->
                </div>
            </div>
        </div>      
        <!-- footer area start-->
        <!-- chèn footer.php ở đây-->
        <?php include("footer.php"); ?>
        <!-- chèn footer.php ở đây-->
    </div>
<!--Đặt dinhdang.php các css, js, jquery, plugin ở đây-->
<?php include_once("dinhdang.php");?>
</body>

</html>
