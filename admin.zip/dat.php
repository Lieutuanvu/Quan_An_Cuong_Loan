<?php
include_once("cosodulieu.php");
if (!isset($_POST['quykhach']) && !isset($_POST['sdt'])){
    header('Location: mon-da-chon.php');
} else {
    $sl_1=0;$sl_2=0;$sl_3=0;$sl_4=0;$sl_5=0;$sl_6=0;$sl_7=0;$sl_8=0;$sl_9=0;$sl_10=0;
    $mon_1="";$mon_2="";$mon_3="";$mon_4="";$mon_5="";$mon_6="";$mon_7="";$mon_8="";$mon_9="";$mon_10="";
    $ten_mon_1="";$ten_mon_2="";$ten_mon_3="";$ten_mon_4="";$ten_mon_5="";$ten_mon_6="";$ten_mon_7="";$ten_mon_8="";$ten_mon_9="";$ten_mon_10="";

    $khach=$_POST['quykhach'];
    $sdt=$_POST['sdt'];
    $lay_noi_dung="Khách: ".$khach.", SĐT: ".$sdt.".";
    if (isset($_POST['mon_1']) && isset($_POST['sl_1']) && isset($_POST['ten_mon_1'])){
        $mon_1=$_POST['mon_1'];
        $ten_mon_1=$_POST['ten_mon_1'];
        $sl_1=$_POST['sl_1'];
        $lay_noi_dung=$lay_noi_dung." Món: ".$ten_mon_1.", số lượng: ".$sl_1.".";
    }
    if (isset($_POST['mon_2']) && isset($_POST['sl_2']) && isset($_POST['ten_mon_2'])){
        $mon_2=$_POST['mon_2'];
        $ten_mon_2=$_POST['ten_mon_2'];
        $sl_2=$_POST['sl_2'];
        $lay_noi_dung=$lay_noi_dung." Món: ".$ten_mon_2.", số lượng: ".$sl_2.".";

    }
    if (isset($_POST['mon_3']) && isset($_POST['sl_3']) && isset($_POST['ten_mon_3'])){
        $mon_3=$_POST['mon_3'];        
        $ten_mon_3=$_POST['ten_mon_3'];
        $sl_3=$_POST['sl_3'];
        $lay_noi_dung=$lay_noi_dung." Món: ".$ten_mon_3.", số lượng: ".$sl_3.".";

    }
    if (isset($_POST['mon_4']) && isset($_POST['sl_4']) && isset($_POST['ten_mon_4'])){
        $mon_4=$_POST['mon_4'];
        $ten_mon_4=$_POST['ten_mon_4'];
        $sl_4=$_POST['sl_4'];
        $lay_noi_dung=$lay_noi_dung." Món: ".$ten_mon_4.", số lượng: ".$sl_4.".";

    }
    if (isset($_POST['mon_5']) && isset($_POST['sl_5']) && isset($_POST['ten_mon_5'])){
        $mon_5=$_POST['mon_5'];
        $ten_mon_5=$_POST['ten_mon_5'];
        $sl_5=$_POST['sl_5'];
        $lay_noi_dung=$lay_noi_dung." Món: ".$ten_mon_5.", số lượng: ".$sl_5.".";

    }
    if (isset($_POST['mon_6']) && isset($_POST['sl_6']) && isset($_POST['ten_mon_6'])){
        $mon_6=$_POST['mon_6'];
        $ten_mon_6=$_POST['ten_mon_6'];
        $sl_6=$_POST['sl_6'];
        $lay_noi_dung=$lay_noi_dung." Món: ".$ten_mon_6.", số lượng: ".$sl_6.".";

    }
    if (isset($_POST['mon_7']) && isset($_POST['sl_7']) && isset($_POST['ten_mon_7'])){
        $mon_7=$_POST['mon_7'];
        $ten_mon_7=$_POST['ten_mon_7'];
        $sl_7=$_POST['sl_7'];
        $lay_noi_dung=$lay_noi_dung." Món: ".$ten_mon_7.", số lượng: ".$sl_7.".";

    }
    if (isset($_POST['mon_8']) && isset($_POST['sl_8']) && isset($_POST['ten_mon_8'])){
        $mon_8=$_POST['mon_8'];
        $ten_mon_8=$_POST['ten_mon_8'];
        $sl_8=$_POST['sl_8'];
        $lay_noi_dung=$lay_noi_dung." Món: ".$ten_mon_8.", số lượng: ".$sl_8.".";

    }
    if (isset($_POST['mon_9']) && isset($_POST['sl_9']) && isset($_POST['ten_mon_9'])){
        $mon_9=$_POST['mon_9'];
        $ten_mon_9=$_POST['ten_mon_9'];
        $sl_9=$_POST['sl_9'];
        $lay_noi_dung=$lay_noi_dung." Món: ".$ten_mon_9.", số lượng: ".$sl_9.".";

    }
    if (isset($_POST['mon_10']) && isset($_POST['sl_10']) && isset($_POST['ten_mon_10'])){
        $mon_10=$_POST['mon_10'];
        $ten_mon_10=$_POST['ten_mon_10'];
        $sl_10=$_POST['sl_10'];
        $lay_noi_dung=$lay_noi_dung." Món: ".$ten_mon_10.", số lượng: ".$sl_10.".";

    }
    $so_don_da_co=$ketnoi->query("SELECT * FROM `dat_mon`");//Lấy số dòng hiện tại để chèn id
    $id=0;
    if($so_don_da_co && $so_don_da_co->num_rows>0){
        while($hien_thi=$so_don_da_co->fetch_assoc()){
            $id=$hien_thi['id_don'];
        }
    }
    $id++;
    $dat=$ketnoi->query("INSERT INTO `dat_mon`(`id_don`,`trang_thai`, `sdt`, `ten_khach`, `id_mon_1`, `id_mon_2`, `id_mon_3`, `id_mon_4`, `id_mon_5`, `id_mon_6`, `id_mon_7`, `id_mon_8`, `id_mon_9`, `id_mon_10`, `sl_1`, `sl_2`, `sl_3`, `sl_4`, `sl_5`, `sl_6`, `sl_7`, `sl_8`, `sl_9`, `sl_10`) VALUES ('$id','0','$sdt','$khach','$mon_1','$mon_2','$mon_3','$mon_4','$mon_5','$mon_6','$mon_7','$mon_8','$mon_9','$mon_10','$sl_1','$sl_2','$sl_3','$sl_4','$sl_5','$sl_6','$sl_7','$sl_8','$sl_9','$sl_10')");
    if ($dat){
        //Tạo thông báo trên fb
        $noi_dung='
        [
            {"text": "'.$lay_noi_dung.'"}
        ]';
        //Gửi tin nhắn lên fb
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,"https://fchat.vn/api/send_message");
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS,
                    "sender_id=3803300989686856&user_id=3803300989686856&message=".$noi_dung."&page_id=100577888372174&id=5ee4f026648bdf4e4f76677e&token=81bcd90df9bb13c397b4bfa5cb91b27ff293a6b5");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $server_output = curl_exec($ch);

        curl_close ($ch);    
        //đặt thành công thì xoá hết 10 cookie
        setcookie('mon_1',"", time()- 60, "/","", 0);
        setcookie('mon_2',"", time()- 60, "/","", 0);
        setcookie('mon_3',"", time()- 60, "/","", 0);
        setcookie('mon_4',"", time()- 60, "/","", 0);
        setcookie('mon_5',"", time()- 60, "/","", 0);
        setcookie('mon_6',"", time()- 60, "/","", 0);
        setcookie('mon_7',"", time()- 60, "/","", 0);
        setcookie('mon_8',"", time()- 60, "/","", 0);
        setcookie('mon_9',"", time()- 60, "/","", 0);
        setcookie('mon_10',"", time()- 60, "/","", 0);
        $url="hoan-thanh.php?id=".$id;
        // echo $noi_dung;
        header('Location: '.$url);
    }
}
?>