<?php
include_once("cosodulieu.php");
//Kiểm tra xem, nếu đăng nhập rồi thì thôi, chưa thì quay về block.php
if (!isset($_SESSION['chuthe'])){
    header('Location: block.php');
} else {
    $dem=$ketnoi->query("SELECT * FROM `dat_mon` WHERE `trang_thai`=0");
    if ($dem){
        echo $dem->num_rows;
    }
}

?>