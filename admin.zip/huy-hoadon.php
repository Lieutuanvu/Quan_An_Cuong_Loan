<?php
include_once("cosodulieu.php");

//Kiểm tra xem, nếu đăng nhập rồi thì thôi, chưa thì quay về block.php
if (!isset($_SESSION['chuthe'])){
    header('Location: block.php');
} else {
    if (!isset($_GET['id'])){
        header('Location: index.php');
    } else {
    $id = $_GET['id'];
    $kiemtra=$ketnoi->query("SELECT `trang_thai` FROM `hoadon_vanchuyen` WHERE `id_hoadon`='$id'");
    if ($kiemtra && $kiemtra->num_rows>0){
        while($out_kiemtra=$kiemtra->fetch_assoc()){            //Kiểm tra này để tránh bug do có người dùng phá
            $trangthaihientai=$out_kiemtra['trang_thai'];       //Kiểm tra trạng thái hiện tại
        }                                                       //Nếu trạng thái ==1 thì tức là đã xác nhận nên không thể huỷ
    }
    if ($trangthaihientai==0){
        if ($ketnoi->query("UPDATE `hoadon_vanchuyen` SET `trang_thai`='-1' WHERE `id_hoadon`='$id'")){
            $url = "hoa-don.php?id=".$id;
            header('Location: '.$url);
        } 
    } else {
            $url = "hoa-don.php?id=".$id;
            header('Location: '.$url);
    }
       
    }
}


?>