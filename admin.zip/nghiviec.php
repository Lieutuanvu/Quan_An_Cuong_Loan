<?php
include_once("cosodulieu.php");

//Kiểm tra xem, nếu đăng nhập rồi thì thôi, chưa thì quay về block.php
if (!isset($_SESSION['chuthe'])){
    header('Location: block.php');
} else {
    //Nếu không phải là admin thì không cho đuổi việc
    if (!isset($_GET['id']) || ($_SESSION['chuthe']!="admin")){
        header('Location: nhanvien.php');
    } else{
        // header('Location: thong-tin-nhan-vien.php?id=$id');
    $id=$_GET['id']; $url="thong-tin-nhan-vien.php?id=".$id;
    //Nếu không phải là admin thì không cho đuổi việc - quay về trang thông tin
    // if ($_SESSION['chuthe']!="admin"){
    //     header('Location: '.$url);
    // }    
        if ($_SESSION['chuthe']=="admin"){
            $ngaynghi=date('Y-m-d');
            if ($ketnoi->query("UPDATE `nhanvien` SET `tinhtrang`=0,`ngaynghi`='$ngaynghi' WHERE `id`='$id'")){
                header('Location: nhanvien.php');
            }
        } else {
                header('Location: '.$url);
        }    
    
    }
}


?>