<!doctype html>
<?php include_once("cosodulieu.php");

//Kiểm tra xem, nếu đăng nhập rồi thì thôi, chưa thì quay về block.php
if (!isset($_SESSION['chuthe'])){
    header('Location: block.php');
}
?>
<html class="no-js" lang="en">
<head>
    <!--Chèn meta.php vào-->
    <?php include("meta.php"); ?>
</head>
<body>
    <!-- Load trước khi tải xong trang-->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!-- Load trước khi tải xong trang-->
    <!-- main wrapper start -->
    <div class="horizontal-main-wrapper">
        <!-- chèn mainhead.php vào đây -->
        <?php include("mainheader.php"); ?>
        <!-- chèn mainhead.php vào đây -->
        <!-- Đặt menu -->
        <?php include("menu.php");?>
        <!-- Đặt menu -->
            <div class="main-content-inner">
                <div class="row">
                    <!-- Danh sách các hoá đơn, các mâm bàn đang còn tồn đọng -->
                    <div class="col-12 mt-5">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="header-title">Danh sách hoá đơn khách chưa thanh toán</h4>
                                <div class="single-table">
                                    <div class="table-responsive">
                                        <table class="table table-hover progress-table text-center">
                                            <thead class="text-uppercase">
                                                <tr>
                                                    <th scope="col">STT</th>
                                                    <th scope="col">Mã HĐ</th>
                                                    <th scope="col">Ngày tạo</th>
                                                    <th scope="col">Giá tiền</th>
                                                    <th scope="col">Trạng thái</th>
                                                    <th scope="col">Chi tiết</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                <?php 
                                                    $lay_hd_con_lai=$ketnoi->query("SELECT * FROM `hoadon_vanchuyen` WHERE `trang_thai`='0'");
                                                    if ($lay_hd_con_lai && $lay_hd_con_lai->num_rows>0){
                                                        $dem=1;
                                                        while($in=$lay_hd_con_lai->fetch_assoc()){
                                                                echo '<tr>';
                                                                echo '<th scope="row">'.$dem.'</th>';$dem++;                                                        
                                                                echo '<td>'.$in['id_hoadon'].'</td>';
                                                                echo '<td>'.date_format(new DateTime($in['ngaytao']),'d-m-Y').'</td>';
                                                                echo '<td>'.number_format($in['thanhtien'],0,'.','.').'</td>';
                                                                echo '<td><span class="status-p bg-danger">CHƯA THANH TOÁN</span></td>';
                                                                echo '<td><a target="_blank" href="hoa-don.php?id='.$in['id_hoadon'].'">Chi tiết</a></td>';
                                                                echo '</tr>';
                                                        }
                                                    }
                                                ?>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <hr/>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-body">
                                <h4 class="header-title">Danh sách tiệc chưa đãi</h4>
                                <div class="single-table">
                                    <div class="table-responsive">
                                        <table class="table table-hover progress-table text-center">
                                            <thead class="text-uppercase">
                                                <tr>
                                                    <th scope="col">STT</th>
                                                    <th scope="col">Địa chỉ</th>
                                                    <th scope="col">Ngày đãi</th>
                                                    <th scope="col">Số mâm</th>
                                                    <th scope="col">Giá tiền</th>
                                                    <th scope="col">Trạng thái</th>
                                                    <th scope="col">Chi tiết</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                <?php 
                                                    $lay_hd_con_lai=$ketnoi->query("SELECT * FROM `mam_tiec` WHERE `tinh_trang`='0' ORDER BY `ngay_dai` ASC");
                                                    if ($lay_hd_con_lai && $lay_hd_con_lai->num_rows>0){
                                                        $dem=1;
                                                        while($in=$lay_hd_con_lai->fetch_assoc()){
                                                                echo '<tr>';
                                                                echo '<th scope="row">'.$dem.'</th>';$dem++;                                                        
                                                                echo '<td>'.$in['dia_chi'].'</td>';
                                                                echo '<td>'.date_format(new DateTime($in['ngay_dai']),'d-m-Y').'</td>';
                                                                echo '<td>'.$in['so_mam'].'</td>';
                                                                echo '<td>'.number_format($in['thanhtien'],0,'.','.').'</td>';
                                                                echo '<td><span class="status-p bg-danger">Chưa đãi</span></td>';
                                                                echo '<td><a target="_blank" href="xem-tiec.php?id='.$in['id_tiec'].'">Chi tiết</a></td>';
                                                                echo '</tr>';
                                                        }
                                                    }
                                                ?>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <hr/>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- main content area end -->
        <!-- chèn footer.php ở đây-->
        <?php include("footer.php"); ?>
        <!-- chèn footer.php ở đây-->
    </div>
    <!-- jquery latest version -->
    <script src="assets/js/vendor/jquery-2.2.4.min.js"></script>
    <!-- bootstrap 4 js -->
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/metisMenu.min.js"></script>
    <script src="assets/js/jquery.slimscroll.min.js"></script>
    <script src="assets/js/jquery.slicknav.min.js"></script>

    <!-- others plugins -->
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/scripts.js"></script>
</body>

</html>
