<?php
include_once("cosodulieu.php");
date_default_timezone_set('Asia/Ho_Chi_Minh');
$ngay_nay=date('Y-m-d');
$ngay=date('d');
$thang=date('m');
$nam=date('Y');
$gio_nay=date('H:i:s');
//Kiểm tra xem, nếu đăng nhập rồi thì thôi, chưa thì quay về block.php
if (!isset($_SESSION['chuthe'])){
    header('Location: block.php');
} else{
    if (!isset($_GET['id'])){
        header('Location: danh-sach-tiec.php');
    } else {
        $id=$_GET['id'];
        $kt_da_xac_nhan=$ketnoi->query("SELECT `tinh_trang` FROM `mam_tiec` WHERE `id_tiec`='$id'");
        if ($kt_da_xac_nhan && $kt_da_xac_nhan->num_rows>0){
            while($in=$kt_da_xac_nhan->fetch_assoc()){
                $tinh_trang=$in['tinh_trang'];
            }
        }
        if ($tinh_trang==1){
            header('Location: xem-tiec.php?id='.$id);
        } else{
            $cap_nhat = "UPDATE `mam_tiec` SET `tinh_trang`=1 WHERE `id_tiec`='$id'";
            $tao_hd=$ketnoi->query("SELECT * FROM `mam_tiec` WHERE `id_tiec`='$id'");
            if ($tao_hd && $tao_hd->num_rows>0){
                while($xuat=$tao_hd->fetch_assoc()){
                    $dia_chi=$xuat['dia_chi'];
                    $cachlienhe=$xuat['cachlienhe'];
                    $so_mam=$xuat['so_mam'];
                    $mon1=$xuat['tenmon_1'];$mon2="";$mon3="";$mon4="";$mon5="";$mon6="";$mon7="";$mon8="";$mon9="";$mon10="";
                    $dongia1=$xuat['dongia_1'];$dongia2=0;$dongia3=0;$dongia4=0;$dongia5=0;$dongia6=0;$dongia7=0;$dongia8=0;$dongia9=0;$dongia10=0;
                    if ($xuat['tenmon_2']!=""){
                        $mon2=$xuat['tenmon_2'];
                        $dongia2=$xuat['dongia_2'];
                    }
                    if ($xuat['tenmon_3']!=""){
                        $mon3=$xuat['tenmon_3'];
                        $dongia3=$xuat['dongia_3'];
                    }
                    if ($xuat['tenmon_4']!=""){
                        $mon4=$xuat['tenmon_4'];
                        $dongia4=$xuat['dongia_4'];
                    }
                    if ($xuat['tenmon_5']!=""){
                        $mon5=$xuat['tenmon_5'];
                        $dongia5=$xuat['dongia_5'];
                    }
                    if ($xuat['tenmon_6']!=""){
                        $mon6=$xuat['tenmon_6'];
                        $dongia6=$xuat['dongia_6'];
                    }
                    if ($xuat['tenmon_7']!=""){
                        $mon7=$xuat['tenmon_7'];
                        $dongia7=$xuat['dongia_7'];
                    }
                    if ($xuat['tenmon_8']!=""){
                        $mon8=$xuat['tenmon_8'];
                        $dongia8=$xuat['dongia_8'];
                    }
                    if ($xuat['tenmon_9']!=""){
                        $mon9=$xuat['tenmon_9'];
                        $dongia9=$xuat['dongia_9'];
                    }
                    if ($xuat['tenmon_10']!=""){
                        $mon10=$xuat['tenmon_10'];
                        $dongia10=$xuat['dongia_10'];
                    }
                    $thanh_tien=$xuat['thanhtien'];
                }
            }
            $tao_hoa_don=$ketnoi->query("INSERT INTO `hoadon_vanchuyen`(`trang_thai`, `ngay_tao`, `thang_tao`, `nam_tao`, `diachi`, `cachlienhe`, `ngaytao`, `gio_tao`, `tenmon_1`, `dongia_1`, `soluong_1`, `tenmon_2`, `dongia_2`, `soluong_2`, `tenmon_3`, `dongia_3`, `soluong_3`, `tenmon_4`, `dongia_4`, `soluong_4`, `tenmon_5`, `dongia_5`, `soluong_5`, `tenmon_6`, `dongia_6`, `soluong_6`, `tenmon_7`, `dongia_7`, `soluong_7`, `tenmon_8`, `dongia_8`, `soluong_8`, `tenmon_9`, `dongia_9`, `soluong_9`, `tenmon_10`, `dongia_10`, `soluong_10`, `thanhtien`) VALUES (0,'$ngay','$thang','$nam','$dia_chi','$cachlienhe','$ngay_nay','$gio_nay','$mon1','$dongia1','$so_mam','$mon2','$dongia2','$so_mam','$mon3','$dongia3','$so_mam','$mon4','$dongia4','$so_mam','$mon5','$dongia5','$so_mam','$mon6','$dongia6','$so_mam','$mon7','$dongia7','$so_mam','$mon8','$dongia8','$so_mam','$mon9','$dongia9','$so_mam','$mon10','$dongia10','$so_mam','$thanh_tien')");
            if (($ketnoi->query($cap_nhat)) && $tao_hoa_don){
                header('Location: xem-tiec.php?id='.$id);
            }
        }
    }
}

?>