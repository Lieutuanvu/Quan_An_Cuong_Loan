<?php
include_once("cosodulieu.php");
date_default_timezone_set('Asia/Ho_Chi_Minh');

//Kiểm tra xem, nếu đăng nhập rồi thì thôi, chưa thì quay về block.php
if (!isset($_SESSION['chuthe'])){
    header('Location: block.php');
} else {

    date_default_timezone_set('Asia/Ho_Chi_Minh');
    $id=0;
    $lay_id=$ketnoi->query("SELECT `id_tiec` FROM `mam_tiec` ORDER BY `id_tiec` ASC");
    if ($lay_id && $lay_id->num_rows>0){
        while($xuat=$lay_id->fetch_assoc()){
            $id=$xuat['id_tiec'];
        }
    }
    $id++; // id++ để tạo id hoá đơn mới
    if (!isset($_POST['diachi']) || !isset($_POST['somam']) || !isset($_POST['ngaydai']) ||  !isset($_POST['giodai'])|| !isset($_POST['tenmon_1'])|| !isset($_POST['dongia_1'])){
        header('Location: dat-tiec.php');
    } else{
        //Khai báo trước khi nhận được _POST
        $tenmon_1="";$dongia_1=0;
        $tenmon_2="";$dongia_2=0;
        $tenmon_3="";$dongia_3=0;
        $tenmon_4="";$dongia_4=0;
        $tenmon_5="";$dongia_5=0;
        $tenmon_6="";$dongia_6=0;
        $tenmon_7="";$dongia_7=0;
        $tenmon_8="";$dongia_8=0;
        $tenmon_9="";$dongia_9=0;
        $tenmon_10="";$dongia_10=0;
        $cachlienhe="Không có";
        $ghichu="Không có";
    
        //Khai báo sau khi nhận được _POST, nếu có hay không thì cũng insert vào db được!
        if (isset($_POST['tenmon_1'])|| isset($_POST['dongia_1'])){
            $tenmon_1=$_POST['tenmon_1'];$dongia_1=$_POST['dongia_1'];
        }
        if (isset($_POST['tenmon_2'])|| isset($_POST['dongia_2'])){
            $tenmon_2=$_POST['tenmon_2'];$dongia_2=$_POST['dongia_2'];
        }
        if (isset($_POST['tenmon_3'])|| isset($_POST['dongia_3'])){
            $tenmon_3=$_POST['tenmon_3'];$dongia_3=$_POST['dongia_3'];
        }
        if (isset($_POST['tenmon_4'])|| isset($_POST['dongia_4'])){
            $tenmon_4=$_POST['tenmon_4'];$dongia_4=$_POST['dongia_4'];
        }
        if (isset($_POST['tenmon_5'])|| isset($_POST['dongia_5'])){
            $tenmon_5=$_POST['tenmon_5'];$dongia_5=$_POST['dongia_5'];
        }
        if (isset($_POST['tenmon_6'])|| isset($_POST['dongia_6'])){
            $tenmon_6=$_POST['tenmon_6'];$dongia_6=$_POST['dongia_6'];
        }
        if (isset($_POST['tenmon_7'])|| isset($_POST['dongia_7'])){
            $tenmon_7=$_POST['tenmon_7'];$dongia_7=$_POST['dongia_7'];
        }
        if (isset($_POST['tenmon_8'])|| isset($_POST['dongia_8'])){
            $tenmon_8=$_POST['tenmon_8'];$dongia_8=$_POST['dongia_8'];
        }
        if (isset($_POST['tenmon_9'])|| isset($_POST['dongia_9'])){
            $tenmon_9=$_POST['tenmon_9'];$dongia_9=$_POST['dongia_9'];
        }
        if (isset($_POST['tenmon_10'])|| isset($_POST['dongia_10'])){
            $tenmon_10=$_POST['tenmon_10'];$dongia_10=$_POST['dongia_10'];
        }
        if (isset($_POST['cachlienhe'])){
            $cachlienhe=$_POST['cachlienhe'];
            if ($cachlienhe==""){
                $cachlienhe="Không có";
            }
        }
     
        //Insert vào csdl
        $diachi=$_POST['diachi'];
        $ghichu=$_POST['ghichu'];
        $somam=$_POST['somam'];
        $ngaydai=$_POST['ngaydai'];
        $giodai=$_POST['giodai'];
        $ngay=date_format(date_create($ngaydai),"d");
        $thang=date_format(date_create($ngaydai),"m");
        $nam=date_format(date_create($ngaydai),"Y");
        $thanhtien=$somam*$dongia_1+$somam*$dongia_2+$somam*$dongia_3+$somam*$dongia_4+$somam*$dongia_5+$somam*$dongia_6+$somam*$dongia_7+$somam*$dongia_8+$somam*$dongia_9+$somam*$dongia_10;    
        if($ketnoi->query("INSERT INTO `mam_tiec`(`ngay`,`thang`,`nam`,`id_tiec`,`ghi_chu` ,`tinh_trang`, `dia_chi`, `cachlienhe`, `so_mam`, `ngay_dai`, `gio_dai`, `tenmon_1`, `dongia_1`, `tenmon_2`, `dongia_2`, `tenmon_3`, `dongia_3`, `tenmon_4`, `dongia_4`, `tenmon_5`, `dongia_5`, `tenmon_6`, `dongia_6`, `tenmon_7`, `dongia_7`, `tenmon_8`, `dongia_8`, `tenmon_9`, `dongia_9`, `tenmon_10`, `dongia_10`, `thanhtien`) VALUES ('$ngay','$thang','$nam','$id','$ghichu','0','$diachi','$cachlienhe','$somam','$ngaydai','$giodai','$tenmon_1','$dongia_1','$tenmon_2','$dongia_2','$tenmon_3','$dongia_3','$tenmon_4','$dongia_4','$tenmon_5','$dongia_5','$tenmon_6','$dongia_6','$tenmon_7','$dongia_7','$tenmon_8','$dongia_8','$tenmon_9','$dongia_9','$tenmon_10','$dongia_10','$thanhtien')")){
            $url="xem-tiec.php?id=".$id;
            header('Location: '.$url);
        }    
    }
    
}

?>