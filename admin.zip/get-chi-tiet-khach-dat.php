<?php
include_once("cosodulieu.php");
//Kiểm tra xem, nếu đăng nhập rồi thì thôi, chưa thì quay về block.php
if (!isset($_SESSION['chuthe']) || !isset($_GET['id'])){
    header('Location: block.php');
} else if (isset($_GET['id']) && isset($_SESSION['chuthe']) && isset($_GET['action'])){
    //Xoá đơn hàng
        $id=$_GET['id'];
        if ($_GET['action']=="xoa"){
            $xoa_don=$ketnoi->query("DELETE FROM `dat_mon` WHERE `id_don`='$id'");//Xoá đơn hàng
            if($xoa_don);
        }
    }
    else if (isset($_GET['id']) && isset($_SESSION['chuthe'])) {
    $id=$_GET['id'];
    //////
    $cap_nhat_trang_thai=$ketnoi->query("UPDATE `dat_mon` SET `trang_thai`=1 WHERE `id_don`='$id'");//Cập nhật lại trạng thái đơn khi đã xem
    if ($cap_nhat_trang_thai);
    //Hàm in tên món
    function xuat_ten_mon($id_mon,$ketnoi){
        $lay_ten_mon=$ketnoi->query("SELECT `ten_mon_an` FROM `thucdon` WHERE `ma_mon_an`='$id_mon'");
        if ($lay_ten_mon && $lay_ten_mon ->num_rows>0){
            while ($hien_thi=$lay_ten_mon->fetch_assoc()){
                return $hien_thi['ten_mon_an'];
            }
        }
    }
    ///truy xuất thông tin đơn hàng
    $lay_chi_tiet=$ketnoi->query("SELECT * FROM `dat_mon` WHERE `id_don`='$id'");
    if ($lay_chi_tiet && $lay_chi_tiet->num_rows>0){
        while($xuat=$lay_chi_tiet->fetch_assoc()){
            echo "                 
            <p>Tên Khách: ".$xuat['ten_khach']."</p>               
            <p>SĐT Khách: ".$xuat['sdt']."</p>               
            <div class=".'"'."single-table".'"'.">
            <div class=".'"'."table-responsive".'"'.">
                <table class=".'"'."table text-center".'"'.">
                    <thead class=".'"'."text-uppercase bg-primary".'"'.">
                        <tr class=".'"'."text-white".'"'.">
                            <th scope=".'"'."col".'"'.">STT</th>
                            <th scope=".'"'."col".'"'.">Tên món</th>
                            <th scope=".'"'."col".'"'.">Số lượng</th>
                        </tr>
                    </thead>
                    <tbody>";
                        $i=0;
                        for ($i=1;$i<=10;$i++){
                            $id_mon="id_mon_".$i;
                            $sl="sl_".$i;
                            if ($xuat["$id_mon"]!=0){
                                echo"   <tr>
                                        <th scope=".'"'."row".'"'.">".$i."</th>
                                        <td>".xuat_ten_mon($xuat["$id_mon"],$ketnoi)."</td>
                                        <td>".$xuat["$sl"]."</td>
                                        </tr>";
                            }
                        }
            echo"   </tbody>
                </table>
            </div>
        </div>";
        }
    } else echo "Không truy vấn được";

} 

?>