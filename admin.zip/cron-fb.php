<?php
                    
        //Tạo thông báo trên fb
        $noi_dung='
        [
            {"text": "Check Page"}
        ]';
        //Gửi tin nhắn lên fb
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,"https://fchat.vn/api/send_message");
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS,
                    "sender_id=3803300989686856&user_id=3803300989686856&message=".$noi_dung."&page_id=100577888372174&id=5ee4f026648bdf4e4f76677e&token=81bcd90df9bb13c397b4bfa5cb91b27ff293a6b5");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $server_output = curl_exec($ch);

        curl_close ($ch);    
?>