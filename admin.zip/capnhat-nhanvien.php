<?php
include_once("cosodulieu.php");
//Kiểm tra xem, nếu đăng nhập rồi thì thôi, chưa thì quay về block.php
if (!isset($_SESSION['chuthe'])){
    header('Location: block.php');
} else {
    if (!isset($_POST['id']) || !isset($_POST['hoten']) || !isset($_POST['cmnd']) || !isset($_POST['gioitinh']) || !isset($_POST['quequan']) || !isset($_POST['sdt']) || !isset($_POST['mucluong'])){
        header('Location: nhanvien.php');
    } else{
        $id=$_POST['id'];
        $hoten=$_POST['hoten'];
        $cmnd=$_POST['cmnd'];
        $gioitinh=$_POST['gioitinh'];
        $quequan=$_POST['quequan'];
        $sdt=$_POST['sdt'];
        $mucluong=$_POST['mucluong'];
        if ($ketnoi->query("UPDATE `nhanvien` SET `hoten`='$hoten',`quequan`='$quequan',`gioitinh`='$gioitinh',`cmnd`='$cmnd',`sdt`='$sdt',`mucluong`='$mucluong' WHERE `id`='$id'")){
            $url="thong-tin-nhan-vien.php?id=".$id;
            header('Location: '.$url);
        }
    }
}



?>