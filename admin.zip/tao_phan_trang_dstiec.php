<?php
$so_tiec=$ketnoi->query("SELECT `id_tiec` FROM `mam_tiec` WHERE `thang`='$thang' AND `nam`='$nam' AND `tinh_trang`=0 ORDER BY `id_tiec` DESC");
if ($so_tiec){
    $tong_record=$so_tiec->num_rows; //Lấy tổng sô tiệc
}
$hien_thi=5;//Hiển thị 1 trang là 5 tiệc
$so_trang=ceil($tong_record/$hien_thi);//Chia lấy số nguyên trang, tổng tiệc / 10 tiệc 1 trang

if(!isset($_GET['trang'])){
    $trang_hien_tai=1;

} else if (isset($_GET['trang'])){
    $trang_hien_tai=$_GET['trang'];
    if ($trang_hien_tai>$so_trang){ //Truy cập trang lớn hơn tổng số trang
        $trang_hien_tai=$so_trang;
    } else if ($trang_hien_tai<1){  //Truy cập trang nhỏ hơn 1 thì quá sai
        $trang_hien_tai=1;
    }

}
$bat_dau_hien_thi=($trang_hien_tai-1)*$hien_thi; // Hiển thị từ $bat_dau_hien_thi trang đến $hien_thi trang


?>