<?php 
session_start();
if (isset($_SESSION['chuthe'])){
    session_destroy();
    header('Location: block.php');
}

?>