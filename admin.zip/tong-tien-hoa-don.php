<?php
include_once("cosodulieu.php");
if (!isset($_SESSION['chuthe'])){
    header('Location: block.php');
} else {
    if (!isset($_GET['id'])){
        header('Location: danh-sach-hoa-don.php');
    } else{
        $id=$_GET['id'];
        $lay_hoa_don=$ketnoi->query("SELECT * FROM `hoadon_vanchuyen` WHERE `id_hoadon`='$id'");
        if ($lay_hoa_don && $lay_hoa_don->num_rows>0){
            while($xuat=$lay_hoa_don->fetch_assoc()){
                    echo $xuat['thanhtien'];
                }

            }
        }
    }
?>