<?php
include_once("cosodulieu.php");
//Kiểm tra xem, nếu đăng nhập rồi thì thôi, chưa thì quay về block.php
if (!isset($_SESSION['chuthe'])){
    header('Location: block.php');
}  
    else if ((isset($_GET['id'])) && isset($_SESSION['chuthe']) && isset($_GET['action'])){
    //Xoá món ăn
    $id_get=$_GET['id'];
        if ($_GET['action']=="xoa"){
            $xoa_don=$ketnoi->query("DELETE FROM `thucdon` WHERE `ma_mon_an`='$id_get'");//Xoá món ăn
            if($xoa_don){
                header("Location: nhap-mon-an.php?hanh_dong=suamon&is_submited=yes");
            }
        }
    }
    else if ((isset($_POST['id'])) && isset($_SESSION['chuthe']) && isset($_GET['action'])){
    $id=$_POST['id'];
    if ($_GET['action']=="capnhat"){
        if (isset($_POST['tenmon']) && isset($_POST['mucgia']) && isset($_POST['mota']) && isset($_POST['urlanh1'])){
            $tenmon=$_POST['tenmon'];
            $mucgia=$_POST['mucgia'];
            $mota=$_POST['mota'];
            $urlanh1=$_POST['urlanh1'];
            $urlanh2=$_POST['urlanh2'];
            $urlanh3=$_POST['urlanh3'];
            $urlanh4=$_POST['urlanh4'];
            $urlanh5=$_POST['urlanh5'];
            // $urlanh6=$_POST['urlanh6'];
            // $urlanh7=$_POST['urlanh7'];
            // $urlanh8=$_POST['urlanh8'];
            // $urlanh9=$_POST['urlanh9'];
            // $urlanh10=$_POST['urlanh10'];
            $nhap=$ketnoi->query("UPDATE `thucdon` SET `ten_mon_an`='$tenmon',`muc_gia`='$mucgia',`mo_ta`='$mota',`url_anh_1`='$urlanh1',`url_anh_2`='$urlanh2',`url_anh_3`='$urlanh3',`url_anh_4`='$urlanh4',`url_anh_5`='$urlanh5' WHERE `ma_mon_an`='$id'");
            if ($nhap){
                header("Location: nhap-mon-an.php?hanh_dong=suamon&is_submited=yes#mon-id-".$id);
            }
        }
    }
}
    else if (isset($_GET['id'])) {
    $id=$_GET['id'];
    ///truy xuất thông tin
    $lay_chi_tiet=$ketnoi->query("SELECT * FROM `thucdon` WHERE `ma_mon_an`='$id'");
    if ($lay_chi_tiet && $lay_chi_tiet->num_rows>0){
        while($xuat=$lay_chi_tiet->fetch_assoc()){
            echo '
            <script>
                function xoa_mon_an(ten,id){
                        if(confirm("Bạn muốn xoá món " + ten) == true){
                            location.replace("chinh-sua-mon.php?action=xoa&id="+id);
                        }
                }
            </script>
            <style>
            .img-fluid{
                max-width: 140px;
                height: 100px;
            }
            </style>
                            <form method="POST" action="chinh-sua-mon.php?action=capnhat">
                                        <div class="form-group">
                                            <label for="ten-mon">Tên món</label>
                                            <input type="text" class="form-control" name="tenmon" required id="ten-mon" value="'.$xuat['ten_mon_an'].'" placeholder="Tên món">
                                            <input type="hidden" name="id" required value="'.$xuat['ma_mon_an'].'">
                                        </div>                                            
                                        <div class="form-group">
                                            <label for="muc-gia">Mức giá (VD: 250.000-400.000)</label>
                                            <input type="text" class="form-control" name="mucgia" required id="muc-gia" value="'.$xuat['muc_gia'].'" placeholder="Mức giá">
                                        </div>
                                        <div class="form-group">
                                            <label for="mo-ta">Mô tả món ăn</label>
                                            <textarea type="text" class="form-control" name="mota" required id="mo-ta" placeholder="Mô tả món ăn">'.$xuat['mo_ta'].'</textarea>
                                        </div>
                                        <div class="form-group">
                                            <div class="row">
                                                <div class="col">
                                                        <input type="url" class="form-control" name="urlanh1" value="'.$xuat['url_anh_1'].'" required placeholder="Url ảnh 1"/>
                                                </div>
                                                <div class="col-md-auto">
                                                    <img class="img-fluid" src="'.$xuat['url_anh_1'].'" alt="image"/>                                                 
                                                </div>
                                            </div>
                                        </div>';
                                        if ($xuat['url_anh_2']!=""){
                                            echo '                                        
                                            <div class="form-group">
                                                <div class="row">
                                                    <div class="col">
                                                            <input type="url" class="form-control" name="urlanh2" value="'.$xuat['url_anh_2'].'" placeholder="Url ảnh 2"/>
                                                    </div>
                                                    <div class="col-md-auto">
                                                        <img class="img-fluid" src="'.$xuat['url_anh_2'].'" alt="image"/>                                                 
                                                    </div>
                                                </div>
                                            </div>';
                                        }
                                        if ($xuat['url_anh_3']!=""){
                                            echo '                                        
                                            <div class="form-group">
                                                <div class="row">
                                                    <div class="col">
                                                            <input type="url" class="form-control" name="urlanh3" value="'.$xuat['url_anh_3'].'" placeholder="Url ảnh 2"/>
                                                    </div>
                                                    <div class="col-md-auto">
                                                        <img class="img-fluid" src="'.$xuat['url_anh_3'].'" alt="image"/>                                                 
                                                    </div>
                                                </div>
                                            </div>';
                                        }
                                        if ($xuat['url_anh_4']!=""){
                                            echo '                                        
                                            <div class="form-group">
                                                <div class="row">
                                                    <div class="col">
                                                            <input type="url" class="form-control" name="urlanh4" value="'.$xuat['url_anh_4'].'" placeholder="Url ảnh 2"/>
                                                    </div>
                                                    <div class="col-md-auto">
                                                        <img class="img-fluid" src="'.$xuat['url_anh_4'].'" alt="image"/>                                                 
                                                    </div>
                                                </div>
                                            </div>';
                                        }
                                        if ($xuat['url_anh_5']!=""){
                                            echo '                                        
                                            <div class="form-group">
                                                <div class="row">
                                                    <div class="col">
                                                            <input type="url" class="form-control" name="urlanh5" value="'.$xuat['url_anh_5'].'" placeholder="Url ảnh 2"/>
                                                    </div>
                                                    <div class="col-md-auto">
                                                        <img class="img-fluid" src="'.$xuat['url_anh_5'].'" alt="image"/>                                                 
                                                    </div>
                                                </div>
                                            </div>';
                                        }
                              echo'     <button type="submit" class="btn btn-primary mt-4 pr-4 pl-4">Nhập</button>
                                        <button onClick="xoa_mon_an('."'".''.$xuat['ten_mon_an'].''."'".','.$xuat['ma_mon_an'].')" type="button" class="btn btn-danger mt-4 pr-4 pl-4">Xoá món</button>
                                    </form>';
        }
    } else echo "Không truy vấn được";

} 

?>