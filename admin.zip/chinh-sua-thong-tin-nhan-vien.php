<!doctype html>
<?php include_once("cosodulieu.php");

//Kiểm tra xem, nếu đăng nhập rồi thì thôi, chưa thì quay về block.php
if (!isset($_SESSION['chuthe'])){
    header('Location: block.php');
} else {


    //Khởi tạo để kiểm tra
    $luong=0;
    if (!isset($_GET['id'])){
        echo "Không kết nối được, link truy cập sai";  //Nếu không có parameter id được truyền vào thì quay về trang nhanvien.php
        header('Location: nhanvien.php');}
    else if (isset($_GET['id'])){
    $id = $_GET['id'];
    $lay_nhanvien=$ketnoi->query("SELECT * FROM `nhanvien` WHERE `id`='$id'");
    if ($lay_nhanvien && $lay_nhanvien->num_rows<=0){
            header('Location: nhanvien.php'); //Nếu không có nhân viên có id này thì quay về trang nhanvien.php
    }
    else if ($lay_nhanvien && $lay_nhanvien->num_rows>0){
        while($in=$lay_nhanvien->fetch_assoc()){
                if($in['tinhtrang']==0){header('Location: nhanvien.php');} //Nếu tình trạng ==0 tức là đã nghỉ việc thì không cho chỉnh sửa
?>
<html class="no-js" lang="en">
<head>
    <!--Chèn meta.php vào-->
    <?php include("meta.php"); ?>
    <script>  
    //Chuyển số sang chữ by DNT
    function doc_luong(){
    var tienluong=document.getElementById("muc_luong").value;
	var Number=function(){var t=["không","một","hai","ba","bốn","năm","sáu","bảy","tám","chín"],r=function(r,n){var o="",a=Math.floor(r/10),e=r%10;return a>1?(o=" "+t[a]+" mươi",1==e&&(o+=" mốt")):1==a?(o=" mười",1==e&&(o+=" một")):n&&e>0&&(o=" lẻ"),5==e&&a>=1?o+=" lăm":4==e&&a>=1?o+=" tư":(e>1||1==e&&0==a)&&(o+=" "+t[e]),o},n=function(n,o){var a="",e=Math.floor(n/100),n=n%100;return o||e>0?(a=" "+t[e]+" trăm",a+=r(n,!0)):a=r(n,!1),a},o=function(t,r){var o="",a=Math.floor(t/1e6),t=t%1e6;a>0&&(o=n(a,r)+" triệu",r=!0);var e=Math.floor(t/1e3),t=t%1e3;return e>0&&(o+=n(e,r)+" ngàn",r=!0),t>0&&(o+=n(t,r)),o};return{doc:function(r){if(0==r)return t[0];var n="",a="";do ty=r%1e9,r=Math.floor(r/1e9),n=r>0?o(ty,!0)+a+n:o(ty,!1)+a+n,a=" tỷ";while(r>0);return n.trim()}}}();
    document.getElementById("tienbangchu").innerHTML="Lương: "+Number.doc(tienluong)+" đồng (VND)";}
    </script>
</head>
<body>
    <!-- Load trước khi tải xong trang-->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!-- Load trước khi tải xong trang-->
    <!-- thông tin nhân viên start -->
    <div class="login-area">
        <div class="container">
            <div class="login-box ptb--100">
                <form action="capnhat-nhanvien.php" method="POST">
                    <input type="text" name="id" value="<?php echo $in['id'];?>" style="display:none!important;">
                    <div class="login-form-head">
                        <h4>THÔNG TIN NHÂN VIÊN</h4>
                        <h4><?php echo $in['hoten'];?></h4>
                    </div>
                    <div class="login-form-body">
                    <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                        <span class="input-group-text" id="hoten">Họ tên:</span>
                                </div>
                                <input required type="text" name="hoten" id="hoten" value="<?php echo $in['hoten'];?>" class="form-control" aria-describedby="hoten">
                        </div>
                        <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                        <span class="input-group-text" id="quequan">Quê quán:</span>
                                </div>
                                <input required type="text" name="quequan" id="quequan" value="<?php echo $in['quequan'];$nhanvien=$in['hoten'];?>" class="form-control" aria-describedby="quequan">
                        </div>
                        <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                        <span class="input-group-text" id="gioitinh">Giới tính:</span>
                                </div>
                                <select required name="gioitinh" id="gioitinh" class="form-control" aria-describedby="gioitinh">
                                                <option><?php 
                                                        echo $in['gioitinh'];        //Nếu Đang là Nam thì còn lại là nữ và ngược lại
                                                        $gioitinh="Nam";
                                                        if ($in['gioitinh']=="Nam"){
                                                                $gioitinh="Nữ";
                                                        }
                                                        ?></option>
                                                <option><?php echo $gioitinh;?></option>
                                </select>
                        </div>
                        <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                        <span class="input-group-text" id="cmnd">CMND:</span>
                                </div>
                                <input required type="number" name="cmnd" id="cmnd" value="<?php echo $in['cmnd'];?>" class="form-control" aria-describedby="cmnd">
                        </div>
                        <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                        <span class="input-group-text" id="ngayvao">Ngày vào:</span>
                                </div>
                                <input type="text" id="ngayvao" disabled value="<?php echo date_format(new DateTime($in['ngayvao']),'d-m-Y');?>" class="form-control" aria-describedby="ngayvao">
                        </div>
                        <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                        <span class="input-group-text" id="sdt">SĐT:</span>
                                </div>
                                <input required type="number" name="sdt" id="sdt" value="<?php echo $in['sdt'];?>" class="form-control" aria-describedby="sdt">
                        </div>
                        <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                        <span class="input-group-text" id="mucluong">Mức lương</span>
                                </div>
                                <input value="<?php echo $in['mucluong'];}}}}?>" id="muc_luong" oninput="doc_luong()" required type="number" name="mucluong"  class="form-control" aria-describedby="mucluong">
                        </div>
                        <div class="input-group mb-3">
                            <hr/><p id="tienbangchu"></p>
                        </div>
                        <div class="submit-btn-area">
                            <button id="form_submit" type="submit">Cập nhật<i class="ti-arrow-right"></i></button>
                        </div>
                        <div class="form-footer text-center mt-5">
                            <p class="text-muted">Nếu người này đã nghỉ làm (xin nghỉ hoặc bị xa thải) thì bấm vào dòng chữ xanh này: <a href="#" data-toggle="modal" data-target="#nghiviec">Cho <?php echo $nhanvien;?> thôi việc</a></p>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- thông tin nhân viên end -->
    <?php 
    ?>
    <!-- jquery latest version -->
    <script src="assets/js/vendor/jquery-2.2.4.min.js"></script>
    <!-- bootstrap 4 js -->
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/metisMenu.min.js"></script>
    <script src="assets/js/jquery.slimscroll.min.js"></script>
    <script src="assets/js/jquery.slicknav.min.js"></script>
    
    <!-- others plugins -->
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/scripts.js"></script>
       
                        <!-- Xác nhận nghỉ việc -->                    
                        <div class="col-lg-6 mt-5">
                                <!-- Modal -->
                                <div class="modal fade" id="nghiviec">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title">Xác nhận người này nghỉ việc?</h5>
                                                <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                                            </div>
                                            <div class="modal-body">
                                            <p>Bấm vào nút Đồng ý để xác nhận <?php echo $nhanvien;?> nghỉ việc tại Quán ăn Cường Loan!</p><hr/>
                                            <p>Hành động này không thể hoàn tác, vui lòng xem xét kĩ!</p>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Huỷ</button>
                                                <a href="nghiviec.php?id=<?php echo $id;?>"<button type="button" class="btn btn-primary">Đồng ý</button></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    <!-- Xác nhận nghỉ việc -->
    
</body>

</html>