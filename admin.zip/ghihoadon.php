<?php
include_once("cosodulieu.php");

//Kiểm tra xem, nếu đăng nhập rồi thì thôi, chưa thì quay về block.php
if (!isset($_SESSION['chuthe'])){
    header('Location: block.php');
} else {
    date_default_timezone_set('Asia/Ho_Chi_Minh');
    $ngay_nay=date('d');
    $thang_nay=date('m');
    $nam_nay=date('Y');
    // $id=0;
    // $lay_id=$ketnoi->query("SELECT `id_hoadon` FROM `hoadon_vanchuyen` ORDER BY `id_hoadon` ASC");
    // if ($lay_id && $lay_id->num_rows>0){
    //     while($xuat=$lay_id->fetch_assoc()){
    //         $id=$xuat['id_hoadon'];
    //     }
    // }
    // $id++; // id++ để tạo id hoá đơn mới
    if (!isset($_POST['diachi']) || !isset($_POST['tenmon_1'])|| !isset($_POST['soluong_1']) || !isset($_POST['dongia_1'])){
        header('Location: goi-thuc-an.php');
    } else{
        //Khai báo trước khi nhận được _POST
        $tenmon_1="";$soluong_1=0;$dongia_1=0;
        $tenmon_2="";$soluong_2=0;$dongia_2=0;
        $tenmon_3="";$soluong_3=0;$dongia_3=0;
        $tenmon_4="";$soluong_4=0;$dongia_4=0;
        $tenmon_5="";$soluong_5=0;$dongia_5=0;
        $tenmon_6="";$soluong_6=0;$dongia_6=0;
        $tenmon_7="";$soluong_7=0;$dongia_7=0;
        $tenmon_8="";$soluong_8=0;$dongia_8=0;
        $tenmon_9="";$soluong_9=0;$dongia_9=0;
        $tenmon_10="";$soluong_19=0;$dongia_10=0;
        $cachlienhe="Không có";
    
        //Khai báo sau khi nhận được _POST, nếu có hay không thì cũng insert vào db được!
        if (isset($_POST['tenmon_1'])|| isset($_POST['soluong_1']) || isset($_POST['dongia_1'])){
            $tenmon_1=$_POST['tenmon_1'];$soluong_1=$_POST['soluong_1'];$dongia_1=$_POST['dongia_1'];
        }
        if (isset($_POST['tenmon_2'])|| isset($_POST['soluong_2']) || isset($_POST['dongia_2'])){
            $tenmon_2=$_POST['tenmon_2'];$soluong_2=$_POST['soluong_2'];$dongia_2=$_POST['dongia_2'];
        }
        if (isset($_POST['tenmon_3'])|| isset($_POST['soluong_3']) || isset($_POST['dongia_3'])){
            $tenmon_3=$_POST['tenmon_3'];$soluong_3=$_POST['soluong_3'];$dongia_3=$_POST['dongia_3'];
        }
        if (isset($_POST['tenmon_4'])|| isset($_POST['soluong_4']) || isset($_POST['dongia_4'])){
            $tenmon_4=$_POST['tenmon_4'];$soluong_4=$_POST['soluong_4'];$dongia_4=$_POST['dongia_4'];
        }
        if (isset($_POST['tenmon_5'])|| isset($_POST['soluong_5']) || isset($_POST['dongia_5'])){
            $tenmon_5=$_POST['tenmon_5'];$soluong_5=$_POST['soluong_5'];$dongia_5=$_POST['dongia_5'];
        }
        if (isset($_POST['tenmon_6'])|| isset($_POST['soluong_6']) || isset($_POST['dongia_6'])){
            $tenmon_6=$_POST['tenmon_6'];$soluong_6=$_POST['soluong_6'];$dongia_6=$_POST['dongia_6'];
        }
        if (isset($_POST['tenmon_7'])|| isset($_POST['soluong_7']) || isset($_POST['dongia_7'])){
            $tenmon_7=$_POST['tenmon_7'];$soluong_7=$_POST['soluong_7'];$dongia_7=$_POST['dongia_7'];
        }
        if (isset($_POST['tenmon_8'])|| isset($_POST['soluong_8']) || isset($_POST['dongia_8'])){
            $tenmon_8=$_POST['tenmon_8'];$soluong_8=$_POST['soluong_8'];$dongia_8=$_POST['dongia_8'];
        }
        if (isset($_POST['tenmon_9'])|| isset($_POST['soluong_9']) || isset($_POST['dongia_9'])){
            $tenmon_9=$_POST['tenmon_9'];$soluong_9=$_POST['soluong_9'];$dongia_9=$_POST['dongia_9'];
        }
        if (isset($_POST['tenmon_10'])|| isset($_POST['soluong_10']) || isset($_POST['dongia_10'])){
            $tenmon_10=$_POST['tenmon_10'];$soluong_10=$_POST['soluong_10'];$dongia_10=$_POST['dongia_10'];
        }
        if (isset($_POST['cachlienhe'])){
            $cachlienhe=$_POST['cachlienhe'];
            if ($cachlienhe==""){
                $cachlienhe="Không có";
            }
        }
        //Insert vào csdl
    $diachi=$_POST['diachi'];
    $ngay_tao=date('Y-m-d');    
    $gio_tao=date('H:i:s');    
    $thanhtien=$soluong_1*$dongia_1+$soluong_2*$dongia_2+$soluong_3*$dongia_3+$soluong_4*$dongia_4+$soluong_5*$dongia_5+$soluong_6*$dongia_6+$soluong_7*$dongia_7+$soluong_8*$dongia_8+$soluong_9*$dongia_9+$soluong_10*$dongia_10;    
        if($ketnoi->query("INSERT INTO `hoadon_vanchuyen`(`ngay_tao`,`thang_tao`,`nam_tao`,`trang_thai`,`diachi`,`cachlienhe`,`ngaytao`,`gio_tao`,`tenmon_1`, `soluong_1`, `dongia_1`, `tenmon_2`, `soluong_2`, `dongia_2`, `tenmon_3`, `soluong_3`, `dongia_3`, `tenmon_4`, `soluong_4`, `dongia_4`, `tenmon_5`, `soluong_5`, `dongia_5`, `tenmon_6`, `soluong_6`, `dongia_6`, `tenmon_7`, `soluong_7`, `dongia_7`, `tenmon_8`, `soluong_8`, `dongia_8`, `tenmon_9`, `soluong_9`, `dongia_9`, `tenmon_10`, `soluong_10`, `dongia_10`, `thanhtien`)  VALUES ('$ngay_nay','$thang_nay','$nam_nay','0','$diachi','$cachlienhe','$ngay_tao','$gio_tao','$tenmon_1','$soluong_1','$dongia_1','$tenmon_2','$soluong_2','$dongia_2','$tenmon_3','$soluong_3','$dongia_3','$tenmon_4','$soluong_4','$dongia_4','$tenmon_5','$soluong_5','$dongia_5','$tenmon_6','$soluong_6','$dongia_6','$tenmon_7','$soluong_7','$dongia_7','$tenmon_8','$soluong_8','$dongia_8','$tenmon_9','$soluong_9','$dongia_9','$tenmon_10','$soluong_10','$dongia_10','$thanhtien')")){
            $url="hoa-don.php?id=".$id;
            header('Location: '.$url);
        }    
    }
    
}

?>