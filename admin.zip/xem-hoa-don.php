<!doctype html>
<html class="no-js" lang="vi">
<head>
    <!--Chèn meta.php vào-->
    <?php include("meta.php"); ?>
</head>
<body class="body-bg">
    <!-- Load trước khi tải xong trang-->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!-- Load trước khi tải xong trang-->
    <!-- main wrapper start -->
    <div class="horizontal-main-wrapper">
            <div class="main-content-inner">
                <div class="row">
                    <div class="col-lg-12 mt-5">
                        <div class="card">
                            <div class="card-body">
                                <div class="invoice-area">
                                <?php   $sotien=0;
                                        include_once("cosodulieu.php"); 
                                        if (!isset($_GET['id'])){    //Không có id hoá đơn thì hiện form nhập mã hđ
                                        echo'
                                            <div class="invoice-head">
                                            <form action="xem-hoa-don.php" method="GET">
                                                        <div class="form-group">
                                                            <label for="nhap-ma-hd">Tra cứu hoá đơn điện tử</label>
                                                            <input name="id" type="text" class="form-control" id="nhap-ma-hd" placeholder="Nhập mã hoá đơn của Quý khách vào đây">
                                                        </div>
                                                        <button type="submit" class="btn btn-primary mt-4 pr-4 pl-4">XEM HOÁ ĐƠN</button>
                                                </form>
                                            </div>';
                                        } else{    //Nếu có id hoá đơn thì duyệt
                                        $id=$_GET['id'];
                                        $hoadon=$ketnoi->query("SELECT * FROM `hoadon_vanchuyen` WHERE `id_hoadon`='$id'");
                                        if ($hoadon && $hoadon->num_rows<=0){  //Nếu id hoá đơn không có trong csdl thì hiện form nhập mã hđ
                                        echo'
                                            <div class="invoice-head">
                                                <form action="xem-hoa-don.php" method="GET">
                                                        <div class="form-group">
                                                            <label for="nhap-ma-hd">Tra cứu hoá đơn điện tử</label>
                                                            <input name="id" type="text" class="form-control" id="nhap-ma-hd" placeholder="Nhập mã hoá đơn của Quý khách vào đây">
                                                        </div>
                                                        <button type="submit" class="btn btn-primary mt-4 pr-4 pl-4">XEM HOÁ ĐƠN</button>
                                                </form>
                                            </div>';
                                        }
                                        else 
                                        if ($hoadon && $hoadon->num_rows>0){   //Nếu id hoá đơn có trong clsd thì duyệt
                                            while($xuat=$hoadon->fetch_assoc()){
                                        echo'                 
                                        <div class="invoice-head">
                                            <div class="row">
                                                <div class="iv-left col-6">
                                                    <span>QUÁN ĂN CƯỜNG LOAN</span><hr/>
                                                    <h6>101/17 Hùng Vương, P6, TP-Sóc Trăng, Sóc Trăng</h6>
                                                    <p>SĐT: 02993826498 - 02993623056</p>
                                                </div>
                                                <div class="iv-right col-6 text-md-right">
                                                    <span>Số hoá đơn: #'.$id.'</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row align-items-center">
                                            <div class="col-md-6">
                                                <div class="invoice-address">
                                                    <h3>Khách hàng: '.$xuat['diachi'].'</h3>
                                                    <h4>Liên hệ: '.$xuat['cachlienhe'].'</h4>
                                                </div>
                                            </div>
                                            <div class="col-md-6 text-md-right">
                                                <ul class="invoice-date">
                                                    <li><h6>Tạo lúc : '.$xuat['gio_tao'].' ngày '.date_format(new DateTime($xuat['ngaytao']),'d-m-Y').'</h6></li>';
                                                    
                                                    if ($xuat['trang_thai']==1){
                                                        $ng_xac_nhan=$xuat['nguoi_xac_nhan'];
                                                        $layten_nv=$ketnoi->query("SELECT `hoten` FROM `nhanvien` WHERE `ma_nv`='$ng_xac_nhan'");
                                                        if ($layten_nv && $layten_nv->num_rows>0){
                                                            while($nv=$layten_nv->fetch_assoc()){
                                                                $nhanvien=$nv['hoten'];
                                                                $nhanvien="<li><h6>Nhân viên: ".$nhanvien.'</h6></li>'; 
                                                                echo '<li><h6>Thanh toán lúc: '.$xuat['gio_thanhtoan'].' ngày '.date_format(new DateTime($xuat['ngay_thanhtoan']),'d-m-Y').'</h6></li>';       
                                                                echo $nhanvien;

                                                            }
                                                        }
                                                    } 
                                                    
                                        echo'   </ul>
                                            </div>
                                        </div>
                                        <div class="invoice-table table-responsive mt-5">
                                        <table class="table table-bordered table-hover text-right">
                                            <thead>
                                                <tr class="text-capitalize">
                                                    <th class="text-center" style="width: 5%;">STT</th>
                                                    <th class="text-left" style="width: 45%; min-width: 130px;">Tên món</th>
                                                    <th>Số lượng</th>
                                                    <th style="min-width: 100px">Đơn giá</th>
                                                    <th>Tổng cộng</th>
                                                </tr>
                                            </thead>
                                            <tbody>';
                                                echo '<tr>';
                                                echo '<td class="text-center">1</td>';
                                                echo '<td class="text-left">'.$xuat['tenmon_1'].'</td>';
                                                echo '<td>'.$xuat['soluong_1'].'</td>';
                                                echo '<td>'.number_format($xuat['dongia_1']).'</td>';
                                                echo '<td>'.number_format($xuat['dongia_1']*$xuat['soluong_1']).'</td>';
                                                echo '</tr>';
                                                if ($xuat['tenmon_2']!=""){
                                                    echo '<tr>';
                                                    echo '<td class="text-center">2</td>';
                                                    echo '<td class="text-left">'.$xuat['tenmon_2'].'</td>';
                                                    echo '<td>'.$xuat['soluong_2'].'</td>';
                                                    echo '<td>'.number_format($xuat['dongia_2']).'</td>';
                                                    echo '<td>'.number_format($xuat['dongia_2']*$xuat['soluong_2']).'</td>';
                                                    echo '</tr>';
                                                }
                                                if ($xuat['tenmon_3']!=""){
                                                    echo '<tr>';
                                                    echo '<td class="text-center">3</td>';
                                                    echo '<td class="text-left">'.$xuat['tenmon_3'].'</td>';
                                                    echo '<td>'.$xuat['soluong_3'].'</td>';
                                                    echo '<td>'.number_format($xuat['dongia_3']).'</td>';
                                                    echo '<td>'.number_format($xuat['dongia_3']*$xuat['soluong_3']).'</td>';
                                                    echo '</tr>';
                                                }
                                                if ($xuat['tenmon_4']!=""){
                                                    echo '<tr>';
                                                    echo '<td class="text-center">4</td>';
                                                    echo '<td class="text-left">'.$xuat['tenmon_4'].'</td>';
                                                    echo '<td>'.$xuat['soluong_4'].'</td>';
                                                    echo '<td>'.number_format($xuat['dongia_4']).'</td>';
                                                    echo '<td>'.number_format($xuat['dongia_4']*$xuat['soluong_4']).'</td>';
                                                    echo '</tr>';
                                                }
                                                if ($xuat['tenmon_5']!=""){
                                                    echo '<tr>';
                                                    echo '<td class="text-center">5</td>';
                                                    echo '<td class="text-left">'.$xuat['tenmon_5'].'</td>';
                                                    echo '<td>'.$xuat['soluong_5'].'</td>';
                                                    echo '<td>'.number_format($xuat['dongia_5']).'</td>';
                                                    echo '<td>'.number_format($xuat['dongia_5']*$xuat['soluong_5']).'</td>';
                                                    echo '</tr>';
                                                }
                                                if ($xuat['tenmon_6']!=""){
                                                    echo '<tr>';
                                                    echo '<td class="text-center">6</td>';
                                                    echo '<td class="text-left">'.$xuat['tenmon_6'].'</td>';
                                                    echo '<td>'.$xuat['soluong_6'].'</td>';
                                                    echo '<td>'.number_format($xuat['dongia_6']).'</td>';
                                                    echo '<td>'.number_format($xuat['dongia_6']*$xuat['soluong_6']).'</td>';
                                                    echo '</tr>';
                                                }
                                                if ($xuat['tenmon_7']!=""){
                                                    echo '<tr>';
                                                    echo '<td class="text-center">7</td>';
                                                    echo '<td class="text-left">'.$xuat['tenmon_7'].'</td>';
                                                    echo '<td>'.$xuat['soluong_7'].'</td>';
                                                    echo '<td>'.number_format($xuat['dongia_7']).'</td>';
                                                    echo '<td>'.number_format($xuat['dongia_7']*$xuat['soluong_7']).'</td>';
                                                    echo '</tr>';
                                                }
                                                if ($xuat['tenmon_8']!=""){
                                                    echo '<tr>';
                                                    echo '<td class="text-center">8</td>';
                                                    echo '<td class="text-left">'.$xuat['tenmon_8'].'</td>';
                                                    echo '<td>'.$xuat['soluong_8'].'</td>';
                                                    echo '<td>'.number_format($xuat['dongia_8']).'</td>';
                                                    echo '<td>'.number_format($xuat['dongia_8']*$xuat['soluong_8']).'</td>';
                                                    echo '</tr>';
                                                }
                                                if ($xuat['tenmon_9']!=""){
                                                    echo '<tr>';
                                                    echo '<td class="text-center">9</td>';
                                                    echo '<td class="text-left">'.$xuat['tenmon_9'].'</td>';
                                                    echo '<td>'.$xuat['soluong_9'].'</td>';
                                                    echo '<td>'.number_format($xuat['dongia_9']).'</td>';
                                                    echo '<td>'.number_format($xuat['dongia_9']*$xuat['soluong_9']).'</td>';
                                                    echo '</tr>';
                                                }
                                                if ($xuat['tenmon_10']!=""){
                                                    echo '<tr>';
                                                    echo '<td class="text-center">10</td>';
                                                    echo '<td class="text-left">'.$xuat['tenmon_10'].'</td>';
                                                    echo '<td>'.$xuat['soluong_10'].'</td>';
                                                    echo '<td>'.number_format($xuat['dongia_10']).'</td>';
                                                    echo '<td>'.number_format($xuat['dongia_10']*$xuat['soluong_10']).'</td>';
                                                    echo '</tr>';
                                                }
                                            echo'</tbody>
                                                <tfoot>
                                                    <tr>
                                                        <td colspan="4">Thành tiền :</td>
                                                        <td>'.number_format($xuat['thanhtien']).'</td>
                                                    </tr>
                                                </tfoot>

                                            </table>

                                            <h4 class="header-title" id="tienbangchu"></h4>
                                            </div>
                                        </div>';$sotien=$xuat['thanhtien'];
                                        if ($xuat['trang_thai']==0){
                                            echo '<button class="btn btn-danger btn-lg btn-block"><h3>CHƯA THANH TOÁN</h3></button>';                                
                                        }
                                        else if ($xuat['trang_thai']==1){
                                            echo '<button class="btn btn-success btn-lg btn-block"><h3>ĐÃ THANH TOÁN</h3></a>';                                
                                        }
                                        else if ($xuat['trang_thai']==-1){
                                            echo '<button class="btn btn-danger btn-lg btn-block"><h3>Hoá đơn này đã bị huỷ, không còn giá trị</h3></a>';                                
                                        }
                                    }
                                }
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
<script>  
var Number=function(){var t=["không","một","hai","ba","bốn","năm","sáu","bảy","tám","chín"],r=function(r,n){var o="",a=Math.floor(r/10),e=r%10;return a>1?(o=" "+t[a]+" mươi",1==e&&(o+=" mốt")):1==a?(o=" mười",1==e&&(o+=" một")):n&&e>0&&(o=" lẻ"),5==e&&a>=1?o+=" lăm":4==e&&a>=1?o+=" tư":(e>1||1==e&&0==a)&&(o+=" "+t[e]),o},n=function(n,o){var a="",e=Math.floor(n/100),n=n%100;return o||e>0?(a=" "+t[e]+" trăm",a+=r(n,!0)):a=r(n,!1),a},o=function(t,r){var o="",a=Math.floor(t/1e6),t=t%1e6;a>0&&(o=n(a,r)+" triệu",r=!0);var e=Math.floor(t/1e3),t=t%1e3;return e>0&&(o+=n(e,r)+" nghìn",r=!0),t>0&&(o+=n(t,r)),o};return{doc:function(r){if(0==r)return t[0];var n="",a="";do ty=r%1e9,r=Math.floor(r/1e9),n=r>0?o(ty,!0)+a+n:o(ty,!1)+a+n,a=" tỷ";while(r>0);return n.trim()}}}();
document.getElementById("tienbangchu").innerHTML="Tiền bằng chữ: "+Number.doc(<?php echo $sotien;?>)+" đồng (VND)";
</script>  
        <!-- chèn footer.php ở đây-->
        <?php include("footer.php"); ?>
        <!-- chèn footer.php ở đây-->
    </div>
<!--Đặt dinhdang.php các css, js, jquery, plugin ở đây-->
<?php include_once("dinhdang.php");?>
<!--Đặt dinhdang.php các css, js, jquery, plugin ở đây-->
 
<?php         

?>            
</body>
</html>
