<!doctype html>
<?php include_once("cosodulieu.php");

//Kiểm tra xem, nếu đăng nhập rồi thì thôi, chưa thì quay về block.php
if (!isset($_SESSION['chuthe'])){
    header('Location: block.php');
} else {


    //Nếu không phải == admin thì không cho tuyển người mới
    if ($_SESSION['chuthe']!="admin"){
        header('Location: nhanvien.php');
    }
}
?>
<html class="no-js" lang="en">
<head>
    <!--Chèn meta.php vào-->
    <?php include("meta.php"); ?>
</head>
<body>
    <!-- Load trước khi tải xong trang-->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!-- Load trước khi tải xong trang-->
    <!-- thông tin nhân viên start -->
    <div class="login-area">
        <div class="container">
            <div class="login-box ptb--100">
                <form action="them-nhanvien.php" method="POST">
                    <div class="login-form-head">
                        <h4>THÊM NHÂN VIÊN MỚI</h4>
                    </div>
                    <div class="login-form-body">
                    <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                        <span class="input-group-text" id="hoten">Họ tên:</span>
                                </div>
                                <input data-toggle="popover" data-content="Nhập họ và tên của nhân viên mới, nhập có dấu để dễ quản lý" data-original-title="Hướng dẫn" aria-describedby="" required type="text" name="hoten" id="hoten" class="form-control" aria-describedby="hoten">
                        </div>
                        <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                        <span class="input-group-text" id="quequan">Quê quán:</span>
                                </div>
                                <input data-toggle="popover" data-content="Nhập quê quán nhân viên theo đăng ký thường trú của người đó, ví dụ: Cù Lao Dung, Sóc Trăng" data-original-title="Hướng dẫn" aria-describedby="" required type="text" name="quequan" id="quequan"  class="form-control" aria-describedby="quequan">
                        </div>
                        <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                        <span class="input-group-text" id="gioitinh">Giới tính:</span>
                                </div>
                                <select data-toggle="popover" data-content="Chọn nam hoặc nữ trong bảng này" data-original-title="Hướng dẫn" aria-describedby="" required name="gioitinh" id="gioitinh" class="form-control" aria-describedby="gioitinh">
                                                <option>Nam</option>
                                                <option>Nữ</option>
                                </select>
                        </div>
                        <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                        <span class="input-group-text" id="cmnd">CMND:</span>
                                </div>
                                <input data-toggle="popover" data-content="Nhập số CMND số, nhập kỹ để tránh phải sửa lại" data-original-title="Hướng dẫn" aria-describedby="" required type="number" name="cmnd" id="cmnd"  class="form-control" aria-describedby="cmnd">
                        </div>
                        <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                        <span class="input-group-text" id="ngayvao">Ngày vào:</span>
                                </div>
                                <input data-toggle="popover" data-content="Nhập ngày vào làm bằng mũi tên chỉ xuống kế bên, chọn ngày tháng năm bằng lịch hiện ra" data-original-title="Hướng dẫn" aria-describedby="" type="date" id="ngayvao" name="ngayvao" class="form-control" aria-describedby="ngayvao">
                        </div>
                        <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                        <span class="input-group-text" id="sdt">SĐT:</span>
                                </div>
                                <input data-toggle="popover" data-content="Nhập SĐT bằng số, nhập kỹ để tránh phải sửa lại" data-original-title="Hướng dẫn" aria-describedby="" required type="number" name="sdt" id="sdt" class="form-control" aria-describedby="sdt">
                        </div>
                        <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="mucluong">Mức lương: </span>
                                </div>                                
                                <input id="muc_luong" oninput="doc_luong()"  aria-describedby="" required type="number" name="mucluong" id="mucluong" class="form-control" aria-describedby="mucluong">
                        </div>
                        <div class="input-group mb-3">
                            <hr/><p id="tienbangchu"></p>
                        </div>
                        <div class="submit-btn-area">
                            <button id="form_submit" type="submit">Thêm vào quán<i class="ti-arrow-right"></i></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- thông tin nhân viên end -->
    <?php 
    ?>
    <!-- jquery latest version -->
    <script src="assets/js/vendor/jquery-2.2.4.min.js"></script>
    <!-- bootstrap 4 js -->
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/metisMenu.min.js"></script>
    <script src="assets/js/jquery.slimscroll.min.js"></script>
    <script src="assets/js/jquery.slicknav.min.js"></script>
    
    <!-- others plugins -->
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/scripts.js"></script>
<script>  
    //Chuyển số sang chữ by DNT
    function doc_luong(){
    var tienluong=document.getElementById("muc_luong").value;
	var Number=function(){var t=["không","một","hai","ba","bốn","năm","sáu","bảy","tám","chín"],r=function(r,n){var o="",a=Math.floor(r/10),e=r%10;return a>1?(o=" "+t[a]+" mươi",1==e&&(o+=" mốt")):1==a?(o=" mười",1==e&&(o+=" một")):n&&e>0&&(o=" lẻ"),5==e&&a>=1?o+=" lăm":4==e&&a>=1?o+=" tư":(e>1||1==e&&0==a)&&(o+=" "+t[e]),o},n=function(n,o){var a="",e=Math.floor(n/100),n=n%100;return o||e>0?(a=" "+t[e]+" trăm",a+=r(n,!0)):a=r(n,!1),a},o=function(t,r){var o="",a=Math.floor(t/1e6),t=t%1e6;a>0&&(o=n(a,r)+" triệu",r=!0);var e=Math.floor(t/1e3),t=t%1e3;return e>0&&(o+=n(e,r)+" ngàn",r=!0),t>0&&(o+=n(t,r)),o};return{doc:function(r){if(0==r)return t[0];var n="",a="";do ty=r%1e9,r=Math.floor(r/1e9),n=r>0?o(ty,!0)+a+n:o(ty,!1)+a+n,a=" tỷ";while(r>0);return n.trim()}}}();
    document.getElementById("tienbangchu").innerHTML=Number.doc(tienluong)+" đồng (VND)";}
</script>       

</body>

</html>