<?php
include_once("cosodulieu.php");
date_default_timezone_set('Asia/Ho_Chi_Minh');
$ngay_nay=date('Y-m-d');
$gio_nay=date('H:i:s');
//Kiểm tra xem, nếu đăng nhập rồi thì thôi, chưa thì quay về block.php
if (!isset($_SESSION['chuthe'])){
    header('Location: block.php');
} else {
    if (!isset($_GET['id']) || !isset($_GET['pass_nv'])){
        header('Location: danh-sach-hoa-don.php');
    } else {
        $id = $_GET['id'];
        $pass_nv = $_GET['pass_nv'];
        //Kiểm tra xem mã nhân viên có đúng với nhân viên không, nếu không thì không cho xác nhận hoá đơn
        $kt_pass_nv=$ketnoi->query("SELECT * FROM `nhanvien` WHERE `ma_nv`='$pass_nv'");
        $trang_thai_nhan_vien=0;//Trạng thái nhân viên phải ==1 mới cho xác nhận hoá đơn
        if($kt_pass_nv && $kt_pass_nv->num_rows>0){
            while($tt_nv=$kt_pass_nv->fetch_assoc()){
                $trang_thai_nhan_vien=$tt_nv['tinhtrang'];
            }
            if($trang_thai_nhan_vien==1){ //Nếu nhân viên ==1 là còn làm mới cho xác nhận
                if ($ketnoi->query("UPDATE `hoadon_vanchuyen` SET `ngay_thanhtoan`='$ngay_nay',`gio_thanhtoan`='$gio_nay',`nguoi_xac_nhan`='$pass_nv', `trang_thai`='1' WHERE `id_hoadon`='$id' ")){ 
                    //Trạng thái ==1 tức là đã xác nhận
                    $url = "hoa-don.php?id=".$id;
                    header('Location: '.$url);
                }  
            } else {
                $url = "hoa-don.php?id=".$id;
                header('Location: '.$url);
            }
      
        } else {
            $url = "hoa-don.php?id=".$id;
            header('Location: '.$url);
        }
    
    }
}


?>