<!doctype html>
<?php include_once("cosodulieu.php");

//Kiểm tra xem, nếu đăng nhập rồi thì thôi, chưa thì quay về block.php
if (!isset($_SESSION['chuthe'])){
    header('Location: block.php');
} else {

        if (!isset($_GET['id'])){    //Không có id hoá đơn thì quay về trang chủ
            header('Location: danh-sach-hoa-don.php');
        } else{    //Nếu có id hoá đơn thì duyệt
        $id=$_GET['id'];
        $nhanvien="Chưa thanh toán";
        $hoadon=$ketnoi->query("SELECT * FROM `hoadon_vanchuyen` WHERE `id_hoadon`='$id'");
        if ($hoadon && $hoadon->num_rows<=0){  //Nếu id hoá đơn không có trong csdl thì quay về trang chủ
            header('Location: danh-sach-hoa-don.php');
        }
        else if ($hoadon && $hoadon->num_rows>0){   //Nếu id hoá đơn có trong clsd thì duyệt
            while($xuat=$hoadon->fetch_assoc()){
                if($xuat['trang_thai']==1){ //Nếu trang_thai==1 có nghĩa là hoá đơn đã thanh toán, không sửa được
                        $url="hoa-don.php?id=".$id;
                        header('Location: '.$url);
                }

?>
<html class="no-js" lang="en">
<head>
    <!--Chèn meta.php vào-->
    <?php include("meta.php"); ?>
<script>
var i=2;
</script>
</head>
<body>
    <!-- Load trước khi tải xong trang-->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!-- Load trước khi tải xong trang-->
    <!-- thông tin nhân viên start -->
    <div class="login-area">
        <div class="container">
            <div class="login">
                <form action="sua-hoadon.php" method="POST">
                    <div class="login-form-head">
                        <h4>SỬA HOÁ ĐƠN</h4>
                        <h4>CHỈNH SỬA XONG BẤM NÚT XÁC NHẬN</h4>
                    </div>
   
                    <div class="login-form-body">
                    <div class="form-row"  id="danh-sach-mon">
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="diachi">Địa chỉ giao hàng:</span>
                                                </div>
                                                <input value="<?php echo $xuat['diachi'];?>" type="text" class="form-control" required="" name="diachi" aria-describedby="diachi">
                                                <input value="<?php echo $id;?>" type="text" name="id" style="display:none!important;">
                                            </div> 
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="cachlienhe">Cách thức liên hệ:</span>
                                                </div>
                                                <input value="<?php echo $xuat['cachlienhe'];?>"  type="text" class="form-control" name="cachlienhe" aria-describedby="cachlienhe">
                                            </div>   
                            <!--Món 1-->                
                            <div class="col-md-4 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                            <span class="input-group-text" id="tenmon_1">Tên món 1:</span>
                                    </div>
                                    <input type="text" value="<?php echo $xuat['tenmon_1'];?>" class="form-control" aria-describedby="tenmon_1" name="tenmon_1" >
                                </div>
                            </div>
                            <div class="col-md-4 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="soluong_1">Số lượng 1:</span>
                                    </div>
                                    <input type="number" value="<?php echo $xuat['soluong_1'];?>" class="form-control" aria-describedby="soluong_1" name="soluong_1" >
                                </div>
                            </div>
                            <div class="col-md-4 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="dongia_1">Đơn giá 1:</span>
                                    </div>
                                    <input type="number" value="<?php echo $xuat['dongia_1'];?>" class="form-control" aria-describedby="dongia_1" name="dongia_1" >
                                </div>
                            </div>
                            <hr/>
                            <!--Món 2-->                
                            <div class="col-md-4 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                            <span class="input-group-text" id="tenmon_2">Tên món 2:</span>
                                    </div>
                                    <input type="text" value="<?php echo $xuat['tenmon_2'];?>" class="form-control" aria-describedby="tenmon_2" name="tenmon_2" >
                                </div>
                            </div>
                            <div class="col-md-4 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="soluong_2">Số lượng 2:</span>
                                    </div>
                                    <input type="number" value="<?php echo $xuat['soluong_2'];?>" class="form-control" aria-describedby="soluong_2" name="soluong_2" >
                                </div>
                            </div>
                            <div class="col-md-4 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="dongia_2">Đơn giá 2:</span>
                                    </div>
                                    <input type="number" value="<?php echo $xuat['dongia_2'];?>" class="form-control" aria-describedby="dongia_2" name="dongia_2" >
                                </div>
                            </div>
                            <hr/>
                            <!--Món 3-->                
                            <div class="col-md-4 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                            <span class="input-group-text" id="tenmon_3">Tên món 3:</span>
                                    </div>
                                    <input type="text" value="<?php echo $xuat['tenmon_3'];?>" class="form-control" aria-describedby="tenmon_3" name="tenmon_3" >
                                </div>
                            </div>
                            <div class="col-md-4 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="soluong_3">Số lượng 3:</span>
                                    </div>
                                    <input type="number" value="<?php echo $xuat['soluong_3'];?>" class="form-control" aria-describedby="soluong_3" name="soluong_3" >
                                </div>
                            </div>
                            <div class="col-md-4 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="dongia_3">Đơn giá 3:</span>
                                    </div>
                                    <input type="number" value="<?php echo $xuat['dongia_3'];?>" class="form-control" aria-describedby="dongia_3" name="dongia_3" >
                                </div>
                            </div>
                            <hr/>
                            <!--Món 4-->                
                            <div class="col-md-4 mb-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                            <span class="input-group-text" id="tenmon_4">Tên món 4:</span>
                                    </div>
                                    <input type="text" value="<?php echo $xuat['tenmon_4'];?>" class="form-control" aria-describedby="tenmon_4" name="tenmon_4" >
                                </div>
                            </div>
                            <div class="col-md-4 mb-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="soluong_4">Số lượng 4:</span>
                                    </div>
                                    <input type="number" value="<?php echo $xuat['soluong_4'];?>" class="form-control" aria-describedby="soluong_4" name="soluong_4" >
                                </div>
                            </div>
                            <div class="col-md-4 mb-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="dongia_4">Đơn giá 4:</span>
                                    </div>
                                    <input type="number" value="<?php echo $xuat['dongia_4'];?>" class="form-control" aria-describedby="dongia_4" name="dongia_4" >
                                </div>
                            </div>
                            <hr/>
                            <!--Món 5-->                
                            <div class="col-md-4 mb-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                            <span class="input-group-text" id="tenmon_5">Tên món 5:</span>
                                    </div>
                                    <input type="text" value="<?php echo $xuat['tenmon_5'];?>" class="form-control" aria-describedby="tenmon_5" name="tenmon_5" >
                                </div>
                            </div>
                            <div class="col-md-4 mb-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="soluong_5">Số lượng 5:</span>
                                    </div>
                                    <input type="number" value="<?php echo $xuat['soluong_5'];?>" class="form-control" aria-describedby="soluong_5" name="soluong_5" >
                                </div>
                            </div>
                            <div class="col-md-4 mb-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="dongia_5">Đơn giá 5:</span>
                                    </div>
                                    <input type="number" value="<?php echo $xuat['dongia_5'];?>" class="form-control" aria-describedby="dongia_5" name="dongia_5" >
                                </div>
                            </div>
                            <hr/>
                            <!--Món 6-->                
                            <div class="col-md-4 mb-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                            <span class="input-group-text" id="tenmon_6">Tên món 6:</span>
                                    </div>
                                    <input type="text" value="<?php echo $xuat['tenmon_6'];?>" class="form-control" aria-describedby="tenmon_6" name="tenmon_6" >
                                </div>
                            </div>
                            <div class="col-md-4 mb-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="soluong_6">Số lượng 6:</span>
                                    </div>
                                    <input type="number" value="<?php echo $xuat['soluong_6'];?>" class="form-control" aria-describedby="soluong_6" name="soluong_6" >
                                </div>
                            </div>
                            <div class="col-md-4 mb-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="dongia_6">Đơn giá 6:</span>
                                    </div>
                                    <input type="number" value="<?php echo $xuat['dongia_6'];?>" class="form-control" aria-describedby="dongia_6" name="dongia_6" >
                                </div>
                            </div>
                            <hr/>
                            <!--Món 7-->                
                            <div class="col-md-4 mb-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                            <span class="input-group-text" id="tenmon_7">Tên món 7:</span>
                                    </div>
                                    <input type="text" value="<?php echo $xuat['tenmon_7'];?>" class="form-control" aria-describedby="tenmon_7" name="tenmon_7" >
                                </div>
                            </div>
                            <div class="col-md-4 mb-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="soluong_7">Số lượng 7:</span>
                                    </div>
                                    <input type="number" value="<?php echo $xuat['soluong_7'];?>" class="form-control" aria-describedby="soluong_7" name="soluong_7" >
                                </div>
                            </div>
                            <div class="col-md-4 mb-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="dongia_7">Đơn giá 7:</span>
                                    </div>
                                    <input type="number" value="<?php echo $xuat['dongia_7'];?>" class="form-control" aria-describedby="dongia_7" name="dongia_7" >
                                </div>
                            </div>
                            <hr/>
                            <!--Món 8-->                
                            <div class="col-md-4 mb-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                            <span class="input-group-text" id="tenmon_8">Tên món 8:</span>
                                    </div>
                                    <input type="text" value="<?php echo $xuat['tenmon_8'];?>" class="form-control" aria-describedby="tenmon_8" name="tenmon_8" >
                                </div>
                            </div>
                            <div class="col-md-4 mb-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="soluong_8">Số lượng 8:</span>
                                    </div>
                                    <input type="number" value="<?php echo $xuat['soluong_8'];?>" class="form-control" aria-describedby="soluong_8" name="soluong_8" >
                                </div>
                            </div>
                            <div class="col-md-4 mb-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="dongia_8">Đơn giá 8:</span>
                                    </div>
                                    <input type="number" value="<?php echo $xuat['dongia_8'];?>" class="form-control" aria-describedby="dongia_8" name="dongia_8" >
                                </div>
                            </div>
                            <hr/>
                            <!--Món 9-->                
                            <div class="col-md-4 mb-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                            <span class="input-group-text" id="tenmon_9">Tên món 9:</span>
                                    </div>
                                    <input type="text" value="<?php echo $xuat['tenmon_9'];?>" class="form-control" aria-describedby="tenmon_9" name="tenmon_9" >
                                </div>
                            </div>
                            <div class="col-md-4 mb-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="soluong_9">Số lượng 9:</span>
                                    </div>
                                    <input type="number" value="<?php echo $xuat['soluong_9'];?>" class="form-control" aria-describedby="soluong_9" name="soluong_9" >
                                </div>
                            </div>
                            <div class="col-md-4 mb-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="dongia_9">Đơn giá 9:</span>
                                    </div>
                                    <input type="number" value="<?php echo $xuat['dongia_9'];?>" class="form-control" aria-describedby="dongia_9" name="dongia_9" >
                                </div>
                            </div>
                            <hr/>
                            <!--Món 10-->                
                            <div class="col-md-4 mb-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                            <span class="input-group-text" id="tenmon_10">Tên món 10:</span>
                                    </div>
                                    <input type="text" value="<?php echo $xuat['tenmon_10'];?>" class="form-control" aria-describedby="tenmon_10" name="tenmon_10" >
                                </div>
                            </div>
                            <div class="col-md-4 mb-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="soluong_10">Số lượng 10:</span>
                                    </div>
                                    <input type="number" value="<?php echo $xuat['soluong_10'];?>" class="form-control" aria-describedby="soluong_10" name="soluong_10" >
                                </div>
                            </div>
                            <div class="col-md-4 mb-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="dongia_10">Đơn giá 10:</span>
                                    </div>
                                    <input type="number" value="<?php echo $xuat['dongia_10']; ?>" class="form-control" aria-describedby="dongia_10" name="dongia_10" >
                                </div>
                            </div>
                            <hr/>
                    </div>
                        <div class="submit-btn-area">
                            <button id="form_submit" type="submit">XÁC NHẬN SỬA<i class="ti-arrow-right"></i></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- thông tin nhân viên end -->
    <?php 
    ?>
    <!-- jquery latest version -->
    <script src="assets/js/vendor/jquery-2.2.4.min.js"></script>
    <!-- bootstrap 4 js -->
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/metisMenu.min.js"></script>
    <script src="assets/js/jquery.slimscroll.min.js"></script>
    <script src="assets/js/jquery.slicknav.min.js"></script>
    
    <!-- others plugins -->
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/scripts.js"></script>
<!--Hàm thêm danh sách món-->
</body>

</html>
<?php
        }
    }
}}
?>