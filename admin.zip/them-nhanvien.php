<?php 
include_once("cosodulieu.php");

//Kiểm tra xem, nếu đăng nhập rồi thì thôi, chưa thì quay về block.php     //Nếu không phải == admin thì không cho tuyển người mới
if (!isset($_SESSION['chuthe']) || $_SESSION['chuthe']!="admin"){
    header('Location: block.php');
} else {

    if (!isset($_POST['hoten']) || !isset($_POST['gioitinh']) || !isset($_POST['quequan']) || !isset($_POST['cmnd']) || !isset($_POST['ngayvao']) || !isset($_POST['sdt']) || !isset($_POST['mucluong'])){
        header('Location: nhap-nhanvien-moi.php');
    } else{
        // header('Location: thong-tin-nhan-vien.php?id=$id');
        $id=1;
        $duyet_csdl=$ketnoi->query("SELECT `id` FROM `nhanvien` ORDER BY `id` ASC");
        if ($duyet_csdl && $duyet_csdl->num_rows>0){
            while($in=$duyet_csdl->fetch_assoc()){
                $id=$in['id'];
            }
        }
        $id++;
        $hoten=$_POST['hoten'];
        $ma_nv=random_int(0,9).random_int(0,9).random_int(0,9).$id;
        $gioitinh=$_POST['gioitinh'];
        $quequan=$_POST['quequan'];
        $sdt=$_POST['sdt'];
        $cmnd=$_POST['cmnd'];
        $ngayvao=$_POST['ngayvao'];
        $mucluong=$_POST['mucluong'];
        if ($ketnoi->query("INSERT INTO `nhanvien`(`ma_nv`,`id`, `hoten`, `quequan`, `gioitinh`, `cmnd`, `ngayvao`, `sdt`, `mucluong`,`tinhtrang`) VALUES ('$ma_nv','$id','$hoten','$quequan','$gioitinh','$cmnd','$ngayvao','$sdt','$mucluong',1)")){
            header('Location: nhanvien.php');
        }
    }
}

?>