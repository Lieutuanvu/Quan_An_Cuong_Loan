<!doctype html>
<?php
include_once("cosodulieu.php"); 

//Kiểm tra xem, nếu đăng nhập rồi thì thôi, chưa thì quay về block.php
if (!isset($_SESSION['chuthe'])){
    header('Location: block.php');
}

if (!isset($_GET['id'])){    //Không có id hoá đơn thì quay về trang chủ
    header('Location: danh-sach-hoa-don.php');
} else{    //Nếu có id hoá đơn thì duyệt
$id=$_GET['id'];
$nhanvien="Chưa thanh toán";
$hoadon=$ketnoi->query("SELECT * FROM `hoadon_vanchuyen` WHERE `id_hoadon`='$id'");
if ($hoadon && $hoadon->num_rows<=0){  //Nếu id hoá đơn không có trong csdl thì quay về trang chủ
    header('Location: danh-sach-hoa-don.php');
}
else if ($hoadon && $hoadon->num_rows>0){   //Nếu id hoá đơn có trong clsd thì duyệt
    while($xuat=$hoadon->fetch_assoc()){

?>
<html class="no-js" lang="vi">
<head>
    <!--Chèn meta.php vào-->
    <?php include("meta.php"); ?>
</head>
<body class="body-bg">
    
    <!-- Load trước khi tải xong trang-->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    
    <!-- Load trước khi tải xong trang-->
    <!-- main wrapper start -->
    <div class="horizontal-main-wrapper">
        <!-- chèn mainhead.php vào đây -->
        <?php include("mainheader.php"); ?>
        <!-- chèn mainhead.php vào đây -->
        <!-- Đặt menu -->
        <?php include("menu.php");?>
        <!-- Đặt menu -->
            <div class="main-content-inner">
                <div class="row">
                    <div class="col-lg-12 mt-5">
                        <div class="card">
                            <div class="card-body">
                                <div class="invoice-area">
                                    <div class="invoice-head">
                                        <div class="row">
                                            <div class="iv-left col-6">
                                                <span>QUÁN ĂN</span> <h4><span>CƯỜNG LOAN</span></h4>
                                                <h6>Địa chỉ: 101/17 Hùng Vương, P6, TP-Sóc Trăng, Sóc Trăng</h6>
                                                <p>SĐT: 02993826498 - 02993622302 - 02993612056</p>
                                            </div>
                                            <div class="iv-right col-6 text-md-right">
                                                <span>Số hoá đơn: #<?php echo $id;?></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row align-items-center">
                                        <div class="col-md-6">
                                            <div class="invoice-address">
                                                <h4><span>Khách hàng: <?php echo $xuat['diachi'];?></span></h4>
                                                <h5>Cách liên hệ: <?php echo $xuat['cachlienhe'];?></h5>
                                            </div>
                                        </div>
                                        <div class="col-md-6 text-md-right">
                                            <ul class="invoice-date">
                                                <li><h6>Tạo lúc: <?php echo $xuat['gio_tao'].' ngày '.date_format(new DateTime($xuat['ngaytao']),'d-m-Y');?></h6></li>
                                                <?php
                                                                    if ($xuat['trang_thai']==1){
                                                                        $ng_xac_nhan=$xuat['nguoi_xac_nhan'];
                                                                        $layten_nv=$ketnoi->query("SELECT `hoten` FROM `nhanvien` WHERE `ma_nv`='$ng_xac_nhan'");
                                                                        if ($layten_nv && $layten_nv->num_rows>0){
                                                                            while($nv=$layten_nv->fetch_assoc()){
                                                                                $nhanvien=$nv['hoten'];
                                                                            }
                                                                        }
                                                                        $nhanvien="<li><h6>Nhân viên: ".$nhanvien.'</h6></li>'; 
                                                                    echo '<li><h6>Thanh toán lúc: '.$xuat['gio_thanhtoan'].' ngày '.date_format(new DateTime($xuat['ngay_thanhtoan']),'d-m-Y').'</h6></li>';       
                                                                    } 
                                                                    echo $nhanvien;?>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="invoice-table table-responsive mt-5">
                                        <table class="table table-bordered table-hover text-right" id="noi-dung-hoa-don">
                                            <!-- <thead>
                                                <tr class="text-capitalize">
                                                    <th class="text-center">STT</th>
                                                    <th class="text-left">Tên món</th>
                                                    <th class="text-center">Số lượng</th>
                                                    <th class="text-center">Đơn giá</th>
                                                    <th>Tổng cộng</th>
                                                </tr>
                                            </thead>
                                            <tbody id="noi-dung-hoa-don"> -->
                                                <!--- In món 1-->
                                                <?php
                                                // echo '<tr>';
                                                // echo '<td class="text-center">1</td>';
                                                // echo '<td class="text-left">'.$xuat['tenmon_1'].'</td>';
                                                // echo '<td class="text-center">'.$xuat['soluong_1'].'</td>';
                                                // echo '<td class="text-center">'.number_format($xuat['dongia_1']).'</td>';
                                                // echo '<td>'.number_format($xuat['dongia_1']*$xuat['soluong_1']).'</td>';
                                                // echo '</tr>';
                                                ?>
                                                <!--- In món 2-->
                                                <?php
                                                // if ($xuat['tenmon_2']!=""){
                                                //     echo '<tr>';
                                                //     echo '<td class="text-center">2</td>';
                                                //     echo '<td class="text-left">'.$xuat['tenmon_2'].'</td>';
                                                //     echo '<td class="text-center">'.$xuat['soluong_2'].'</td>';
                                                //     echo '<td class="text-center">'.number_format($xuat['dongia_2']).'</td>';
                                                //     echo '<td>'.number_format($xuat['dongia_2']*$xuat['soluong_2']).'</td>';
                                                //     echo '</tr>';
                                                // }
                                                ?>
                                                <!--- In món 3-->
                                                <?php
                                                // if ($xuat['tenmon_3']!=""){
                                                //     echo '<tr>';
                                                //     echo '<td class="text-center">3</td>';
                                                //     echo '<td class="text-left">'.$xuat['tenmon_3'].'</td>';
                                                //     echo '<td class="text-center">'.$xuat['soluong_3'].'</td>';
                                                //     echo '<td class="text-center">'.number_format($xuat['dongia_3']).'</td>';
                                                //     echo '<td>'.number_format($xuat['dongia_3']*$xuat['soluong_3']).'</td>';
                                                //     echo '</tr>';
                                                // }
                                                ?>
                                                <!--- In món 4-->
                                                <?php
                                                // if ($xuat['tenmon_4']!=""){
                                                //     echo '<tr>';
                                                //     echo '<td class="text-center">4</td>';
                                                //     echo '<td class="text-left">'.$xuat['tenmon_4'].'</td>';
                                                //     echo '<td class="text-center">'.$xuat['soluong_4'].'</td>';
                                                //     echo '<td class="text-center">'.number_format($xuat['dongia_4']).'</td>';
                                                //     echo '<td>'.number_format($xuat['dongia_4']*$xuat['soluong_4']).'</td>';
                                                //     echo '</tr>';
                                                // }
                                                ?>
                                                <!--- In món 5-->
                                                <?php
                                                // if ($xuat['tenmon_5']!=""){
                                                //     echo '<tr>';
                                                //     echo '<td class="text-center">5</td>';
                                                //     echo '<td class="text-left">'.$xuat['tenmon_5'].'</td>';
                                                //     echo '<td class="text-center">'.$xuat['soluong_5'].'</td>';
                                                //     echo '<td class="text-center">'.number_format($xuat['dongia_5']).'</td>';
                                                //     echo '<td>'.number_format($xuat['dongia_5']*$xuat['soluong_5']).'</td>';
                                                //     echo '</tr>';
                                                // }
                                                ?>
                                                <!--- In món 6-->
                                                <?php
                                                // if ($xuat['tenmon_6']!=""){
                                                //     echo '<tr>';
                                                //     echo '<td class="text-center">6</td>';
                                                //     echo '<td class="text-left">'.$xuat['tenmon_6'].'</td>';
                                                //     echo '<td class="text-center">'.$xuat['soluong_6'].'</td>';
                                                //     echo '<td class="text-center">'.number_format($xuat['dongia_6']).'</td>';
                                                //     echo '<td>'.number_format($xuat['dongia_6']*$xuat['soluong_6']).'</td>';
                                                //     echo '</tr>';
                                                // }
                                                ?>
                                                <!--- In món 7-->
                                                <?php
                                                // if ($xuat['tenmon_7']!=""){
                                                //     echo '<tr>';
                                                //     echo '<td class="text-center">7</td>';
                                                //     echo '<td class="text-left">'.$xuat['tenmon_7'].'</td>';
                                                //     echo '<td class="text-center">'.$xuat['soluong_7'].'</td>';
                                                //     echo '<td class="text-center">'.number_format($xuat['dongia_7']).'</td>';
                                                //     echo '<td>'.number_format($xuat['dongia_7']*$xuat['soluong_7']).'</td>';
                                                //     echo '</tr>';
                                                // }
                                                ?>
                                                <!--- In món 8-->
                                                <?php
                                                // if ($xuat['tenmon_8']!=""){
                                                //     echo '<tr>';
                                                //     echo '<td class="text-center">8</td>';
                                                //     echo '<td class="text-left">'.$xuat['tenmon_8'].'</td>';
                                                //     echo '<td class="text-center">'.$xuat['soluong_8'].'</td>';
                                                //     echo '<td class="text-center">'.number_format($xuat['dongia_8']).'</td>';
                                                //     echo '<td>'.number_format($xuat['dongia_8']*$xuat['soluong_8']).'</td>';
                                                //     echo '</tr>';
                                                // }
                                                ?>
                                                <!--- In món 9-->
                                                <?php
                                                // if ($xuat['tenmon_9']!=""){
                                                //     echo '<tr>';
                                                //     echo '<td class="text-center">9</td>';
                                                //     echo '<td class="text-left">'.$xuat['tenmon_9'].'</td>';
                                                //     echo '<td class="text-center">'.$xuat['soluong_9'].'</td>';
                                                //     echo '<td class="text-center">'.number_format($xuat['dongia_9']).'</td>';
                                                //     echo '<td>'.number_format($xuat['dongia_9']*$xuat['soluong_9']).'</td>';
                                                //     echo '</tr>';
                                                // }
                                                ?>
                                                <!--- In món 10-->
                                                <?php
                                                // if ($xuat['tenmon_10']!=""){
                                                //     echo '<tr>';
                                                //     echo '<td class="text-center">10</td>';
                                                //     echo '<td class="text-left">'.$xuat['tenmon_10'].'</td>';
                                                //     echo '<td class="text-center">'.$xuat['soluong_10'].'</td>';
                                                //     echo '<td class="text-center">'.number_format($xuat['dongia_10']).'</td>';
                                                //     echo '<td>'.number_format($xuat['dongia_10']*$xuat['soluong_10']).'</td>';
                                                //     echo '</tr>';
                                                // }
                                                ?>
                                                
                                            </tbody>
                                            <!-- <tbody>
                                                <tr>        
                                                    <td class="text-center">*</td>
                                                    <td class="text-left">Rau-bún-bánh tráng-nước chấm (nếu có)</td>
                                                    <td class="text-center">Kèm</td>
                                                    <td class="text-center"></td>
                                                    <td></td>
                                                </tr>
                                            </tbody> -->
                                            <!-- <tfoot>
                                                <tr>
                                                    <td colspan="4">Thành tiền :</td>
                                                    <td id="tong_so_tien" style="display:none!important;"><?php //echo $xuat['thanhtien'];?></td>
                                                    <td><?php //echo number_format($xuat['thanhtien']);?></td>
                                                </tr>
                                            </tfoot> -->

                                        </table>
                                        <h4 id="tong-tien-hoa-don"></h4>
                                    </div>
                                </div>
                                <?php 
                                if ($xuat['trang_thai']==0){
                                    echo '<button href="#" data-toggle="modal" data-target="#xacnhan-hoadon" class="btn btn-primary btn-lg btn-block"><h3>XÁC NHẬN THANH TOÁN</h3></button>';                                
                                    echo '<a href="sua-hoa-don.php?id='.$xuat['id_hoadon'].'" class="btn btn-secondary btn-lg btn-block"><h3>SỬA HOÁ ĐƠN</h3></a>';                                
                                    echo '<button href="#" data-toggle="modal" data-target="#huy-hoadon" class="btn btn-danger btn-lg btn-block"><h3>Huỷ hoá đơn</h3></button>';                                
                                }
                                else if ($xuat['trang_thai']==1){
                                    echo '<a href="danh-sach-hoa-don.php" class="btn btn-success btn-lg btn-block"><h3>ĐÃ THANH TOÁN</h3></a>';                                
                                }
                                else if ($xuat['trang_thai']==-1){
                                    echo '<a href="danh-sach-hoa-don.php" class="btn btn-danger btn-lg btn-block"><h3>Hoá đơn này đã bị huỷ, không còn giá trị</h3></a>';                                
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        <!-- chèn footer.php ở đây-->
        <?php include("footer.php"); ?>
        <!-- chèn footer.php ở đây-->
    </div>
<!--Đặt dinhdang.php các css, js, jquery, plugin ở đây-->
<?php include_once("dinhdang.php");?>
<!--Đặt dinhdang.php các css, js, jquery, plugin ở đây-->
<script>  
    //Chuyển số sang chữ by DNT
    var sotien=document.getElementById("tong_so_tien").innerHTML;
	var Number=function(){var t=["không","một","hai","ba","bốn","năm","sáu","bảy","tám","chín"],r=function(r,n){var o="",a=Math.floor(r/10),e=r%10;return a>1?(o=" "+t[a]+" mươi",1==e&&(o+=" mốt")):1==a?(o=" mười",1==e&&(o+=" một")):n&&e>0&&(o=" lẻ"),5==e&&a>=1?o+=" lăm":4==e&&a>=1?o+=" tư":(e>1||1==e&&0==a)&&(o+=" "+t[e]),o},n=function(n,o){var a="",e=Math.floor(n/100),n=n%100;return o||e>0?(a=" "+t[e]+" trăm",a+=r(n,!0)):a=r(n,!1),a},o=function(t,r){var o="",a=Math.floor(t/1e6),t=t%1e6;a>0&&(o=n(a,r)+" triệu",r=!0);var e=Math.floor(t/1e3),t=t%1e3;return e>0&&(o+=n(e,r)+" ngàn",r=!0),t>0&&(o+=n(t,r)),o};return{doc:function(r){if(0==r)return t[0];var n="",a="";do ty=r%1e9,r=Math.floor(r/1e9),n=r>0?o(ty,!0)+a+n:o(ty,!1)+a+n,a=" tỷ";while(r>0);return n.trim()}}}();
    document.getElementById("tienbangchu").innerHTML="Tiền bằng chữ: "+Number.doc(sotien)+" đồng (VND)";
</script>   
<?php         
    }
}
}
?>
                        <!-- Xác nhận hoá đơn hàng -->                    
                                <!-- Modal -->
                                <div class="modal fade" id="xacnhan-hoadon">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title">Xác nhận thanh toán hoá đơn này?</h5>
                                                <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                                            </div>
                                            <div class="modal-body">
                                            <p>Nhập mật khẩu cá nhân vào và nhấn vào nút Đồng ý để xác nhận thanh toán hoá đơn cho Khách hàng tại Quán ăn Cường Loan!</p><hr/>
                                            <div class="col-sm-6">
                                                <form action="xacnhan-hoadon.php" method="GET">
                                                <input name="id" value="<?php echo $id;?>" style="display:none!important;">
                                                <input type="text" name="pass_nv" required class="form-control" placeholder="Nhập MK vào ô này">
                                            </div><hr/>
                                            <p>Hành động này không thể hoàn tác, vui lòng xem xét kĩ!</p>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Huỷ</button>
                                                <button type="submit" class="btn btn-primary" >Đồng ý</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                    <!-- Xác nhận hoá đơn hàng -->                    
                    <!-- Xác nhận huỷ hoá đơn -->                    
                                <!-- Modal -->
                                <div class="modal fade" id="huy-hoadon">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title">Xác nhận huỷ bỏ hoá đơn này?</h5>
                                                <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                                            </div>
                                            <div class="modal-body">
                                            <p>Bấm vào nút Đồng ý để xác nhận huỷ hoá đơn cho Khách hàng tại Quán ăn Cường Loan!</p><hr/>
                                            <p>Hành động này không thể hoàn tác, vui lòng xem xét kĩ!</p>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Huỷ</button>
                                                <a href="huy-hoadon.php?id=<?php echo $id;?>"<button type="button" class="btn btn-primary">Đồng ý</button></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                    <!-- Xác nhận huỷ hoá đơn -->
                    
<script type="text/javascript">
//jquery lấy hoá đơn theo thời gian thực
 function get_hoa_Don() {
  setInterval(function(){
   var xhttp = new XMLHttpRequest();
   xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
     document.getElementById("noi-dung-hoa-don").innerHTML = this.responseText;
    }
   };
   xhttp.open("GET", "get-hoa-don.php?id=<?php echo $id;?>", true);
   xhttp.send();

  },1000); //Khai báo từ 1000 = 1 giây trở lên để tránh bị gọi liên tục chiếm cpu
 }
 get_hoa_Don();
</script>
<script type="text/javascript">

//jquery lấy số tiền hoá đơn theo thời gian thực
 function tong_tien_hoa_don() {
  setInterval(function(){
   var xhttp = new XMLHttpRequest();
   xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
    //  document.getElementById("tong-tien-hoa-don").innerHTML = this.responseText;
     var sotien=this.responseText;
    //  var sotien=document.getElementById("tong-tien-hoa-don").innerHTML;
	var Number=function(){var t=["không","một","hai","ba","bốn","năm","sáu","bảy","tám","chín"],r=function(r,n){var o="",a=Math.floor(r/10),e=r%10;return a>1?(o=" "+t[a]+" mươi",1==e&&(o+=" mốt")):1==a?(o=" mười",1==e&&(o+=" một")):n&&e>0&&(o=" lẻ"),5==e&&a>=1?o+=" lăm":4==e&&a>=1?o+=" tư":(e>1||1==e&&0==a)&&(o+=" "+t[e]),o},n=function(n,o){var a="",e=Math.floor(n/100),n=n%100;return o||e>0?(a=" "+t[e]+" trăm",a+=r(n,!0)):a=r(n,!1),a},o=function(t,r){var o="",a=Math.floor(t/1e6),t=t%1e6;a>0&&(o=n(a,r)+" triệu",r=!0);var e=Math.floor(t/1e3),t=t%1e3;return e>0&&(o+=n(e,r)+" ngàn",r=!0),t>0&&(o+=n(t,r)),o};return{doc:function(r){if(0==r)return t[0];var n="",a="";do ty=r%1e9,r=Math.floor(r/1e9),n=r>0?o(ty,!0)+a+n:o(ty,!1)+a+n,a=" tỷ";while(r>0);return n.trim()}}}();
    document.getElementById("tong-tien-hoa-don").innerHTML="Tiền bằng chữ: "+Number.doc(sotien)+" đồng (VND)";
    }
   };
   xhttp.open("GET", "tong-tien-hoa-don.php?id=<?php echo $id;?>", true);
   xhttp.send();

  },1000); //Khai báo từ 1000 = 1 giây trở lên để tránh bị gọi liên tục chiếm cpu
 }
 tong_tien_hoa_don();
</script>
</body>
</html>
