<?php
include_once("cosodulieu.php");
//Khai báo các biến để in ở đây
$html_nhap_mon='<form method="POST" action="nhap-mon-an.php?hanh_dong=nhapmon"><div class="form-group"> <label for="ten-mon">Tên món</label> <input type="text" class="form-control" name="tenmon" required id="ten-mon" placeholder="Tên món"> </div> <div class="form-group"> <label for="muc-gia">Mức giá (VD: 250.000-400.000)</label> <input type="text" class="form-control" name="mucgia" required id="muc-gia" placeholder="Mức giá"> </div> <div class="form-group"> <label for="mo-ta">Mô tả món ăn</label> <textarea type="text" class="form-control" name="mota" required id="mo-ta" placeholder="Mô tả món ăn"></textarea> </div> <div class="form-group"> <div class="row"> <div class="col-lg-2 col-md-4 col-sm-6"> <input type="url" class="form-control" name="urlanh1" required placeholder="Url ảnh 1"> </div> <div class="col-lg-2 col-md-4 col-sm-6"> <input type="url" class="form-control" name="urlanh2" placeholder="Url ảnh 2"> </div> <div class="col-lg-2 col-md-4 col-sm-6"> <input type="url" class="form-control" name="urlanh3" placeholder="Url ảnh 3"> </div> <div class="col-lg-2 col-md-4 col-sm-6"> <input type="url" class="form-control" name="urlanh4" placeholder="Url ảnh 4"> </div> <div class="col-lg-2 col-md-4 col-sm-6"> <input type="url" class="form-control" name="urlanh5" placeholder="Url ảnh 5"> </div> <div class="col-lg-2 col-md-4 col-sm-6"> <input type="url" class="form-control" name="urlanh6" placeholder="Url ảnh 6"> </div> </div> </div> <div class="form-group"> <div class="row"> <div class="col-lg-3 col-md-6"> <input type="url" class="form-control" name="urlanh7" placeholder="Url ảnh 7"> </div> <div class="col-lg-3 col-md-6"> <input type="url" class="form-control" name="urlanh8" placeholder="Url ảnh 8"> </div> <div class="col-lg-3 col-md-6"> <input type="url" class="form-control" name="urlanh9" placeholder="Url ảnh 9"> </div> <div class="col-lg-3 col-md-6"> <input type="url" class="form-control" name="urlanh10" placeholder="Url ảnh 10"> </div> </div> </div> <div class="form-check"> <input type="checkbox" name="c_dat_tiec" class="form-check-input" id="chi-dat-tiec"> <label class="form-check-label" for="chi-dat-tiec">Chỉ đặt tiệc?</label> </div> <button type="submit" class="btn btn-primary mt-4 pr-4 pl-4">Nhập</button></form>';
$html_error='
<style>
.list-group-item{
    font-size: 20px;
}   
</style>
<div class="card">
    <div class="card-body">
        <h4 class="header-title">Lựa chọn</h4>
        <div class="list-group">

            <a href="nhap-mon-an.php?hanh_dong=nhapmon" class="list-group-item list-group-item-action">Nhập món ăn</a>
            <a href="nhap-mon-an.php?hanh_dong=suamon" class="list-group-item list-group-item-action">Sửa món ăn</a>
        </div>
    </div>
</div>';
$html_popup='
<div class="modal fade bd-example-modal-lg" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Chỉnh sửa món ăn</h5>
                <button type="button" class="close" data-dismiss="modal"><span>×</span></button>
            </div>
            <div class="modal-body" id="noi-dung-mon">
                    
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
function get_ct_mon(id_mon){
    document.getElementById("noi-dung-mon").innerHTML="Xin chờ...";
    $("#noi-dung-mon").load("chinh-sua-mon.php?id="+id_mon);
}
function goi_bang_mon_an(id_mon){
    document.getElementById("nut-mon-"+id_mon).click();
}
</script>';
//Kiểm tra xem, nếu đăng nhập rồi thì thôi, chưa thì quay về block.php
if (!isset($_SESSION['chuthe'])){
    header('Location: block.php');
} else {

    date_default_timezone_set('Asia/Ho_Chi_Minh');
    $thang=date('m');
    $nam=date('Y');
    include_once("tao_phan_trang_ds_dat_mon.php");


    if (isset($_POST['tenmon']) && isset($_POST['mucgia']) && isset($_POST['mota']) && isset($_POST['urlanh1'])){
        $tenmon=$_POST['tenmon'];
        $mucgia=$_POST['mucgia'];
        $mota=$_POST['mota'];
        $urlanh1=$_POST['urlanh1'];
        $urlanh2=$_POST['urlanh2'];
        $urlanh3=$_POST['urlanh3'];
        $urlanh4=$_POST['urlanh4'];
        $urlanh5=$_POST['urlanh5'];
        // $urlanh6=$_POST['urlanh6'];
        // $urlanh7=$_POST['urlanh7'];
        // $urlanh8=$_POST['urlanh8'];
        // $urlanh9=$_POST['urlanh9'];
        // $urlanh10=$_POST['urlanh10'];
        $is_regale=0;
        if (isset($_POST['c_dat_tiec'])){
            $is_regale=1;
        }
        $lay_id=$ketnoi->query("SELECT * FROM `thucdon` ORDER BY `ma_mon_an` ASC");
        if ($lay_id && $lay_id->num_rows>0){
            while($xuat=$lay_id->fetch_assoc()){
                $id=$xuat['ma_mon_an'];
            }
        }
        $id++;
        $nhap=$ketnoi->query("INSERT INTO `thucdon`(`ma_mon_an`,`ten_mon_an`, `muc_gia`, `mo_ta`, `is_regale`, `url_anh_1`, `url_anh_2`, `url_anh_3`, `url_anh_4`, `url_anh_5`) VALUES ('$id','$tenmon','$mucgia','$mota','$is_regale','$urlanh1','$urlanh2','$urlanh3','$urlanh4','$urlanh5')");
        if ($nhap){
            header("Location: nhap-mon-an.php?hanh_dong=nhapmon&is_submited=yes");
            echo '
            <script>
                location.replace("nhap-mon-an.php?hanh_dong=nhapmon&is_submited=yes");
            </script>
            ';
        }
    }
?>
<html class="no-js" lang="vi">
<head>
    <!--Chèn meta.php vào-->
    <?php include("meta.php"); ?>
</head>
<body class="body-bg">
    <!-- Load trước khi tải xong trang-->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!-- Load trước khi tải xong trang-->
    <!-- main wrapper start -->
    <div class="horizontal-main-wrapper">
        <!-- chèn mainhead.php vào đây -->
        <?php include("mainheader.php"); ?>
        <!-- chèn mainhead.php vào đây -->
        <!-- Đặt menu -->
        <?php include("menu.php");?>
        <!-- Đặt menu -->
            <div class="main-content-inner">
                <div class="row">
                    <!-- danh sách hoá đơn -->
                    <div class="col-12 mt-5">
                                <div class="card">
                                    <div class="card-body">
                                        <?php 
                                        if(isset($_GET['hanh_dong'])){
                                            $hanh_dong=$_GET['hanh_dong'];
                                            if ($hanh_dong=="nhapmon"){
                                                if (isset($_GET['is_submited'])){
                                                    $status=$_GET['is_submited'];
                                                    if ($status=="yes"){
                                                        echo'
                                                        <div class="alert alert-success" role="alert">
                                                            <strong>Well done!</strong> Nhập thành công.
                                                        </div>';
                                                    }
                                                }
                                                echo $html_nhap_mon;
                                            }
                                            else if ($hanh_dong=="suamon"){
                                                if (isset($_GET['is_submited'])){
                                                    $status=$_GET['is_submited'];
                                                    if ($status=="yes"){
                                                        echo'
                                                        <div class="alert alert-success" role="alert">
                                                            <strong>Well done!</strong> Sửa thành công.
                                                        </div>';
                                                    }
                                                }
                                                echo $html_popup;
                                                if (isset($_GET['id_mon'])){
                                                    $id_mon=$_GET['id_mon'];
                                                    echo '
                                                    <script type="text/javascript">
                                                        goi_bang_mon_an('.$id_mon.');
                                                    </script>';
                                                }
                                                $lay_mon_an=$ketnoi->query("SELECT * FROM `thucdon`");
                                                if ($lay_mon_an && $lay_mon_an->num_rows>0){
                                                    echo'
                                                    <style>
                                                    .img-fluid{
                                                        max-width: 140px;
                                                        height: 100px;
                                                    }
                                                    </style>';
                                                    while($xuat=$lay_mon_an->fetch_assoc()){
                                                    echo '
                                                        <div class="card-body" id="mon-id-'.$xuat['ma_mon_an'].'">
                                                            <div class="media mb-5">
                                                                <img class="img-fluid mr-4" src="'.$xuat['url_anh_1'].'" alt="image">
                                                                <div class="media-body">
                                                                    <h4 class="mb-3">'.$xuat['ten_mon_an'].'</h4><p>'.$xuat['mo_ta'].'</p>
                                                                    <button id="nut-mon-'.$xuat['ma_mon_an'].'" onClick="get_ct_mon('.$xuat['ma_mon_an'].')" data-toggle="modal" data-target=".bd-example-modal-lg" type="button" class="btn btn-flat btn-primary mb-3">Chỉnh sửa</button>
                                                                </div>
                                                            </div>
                                                        </div>';
                                                    }
                                                }

                                            }
                                            else echo $html_error;
                                        }
                                        else echo $html_error;
                                    }
                                        ?>
                                    </div>
                                </div>
                    </div>
                    <!-- Danh sách hoá đơn end -->
                </div>
            </div>
        </div>      
        <!-- footer area start-->
        <!-- chèn footer.php ở đây-->
        <?php include("footer.php"); ?>
        <!-- chèn footer.php ở đây-->
    </div>
<!--Đặt dinhdang.php các css, js, jquery, plugin ở đây-->
<?php include_once("dinhdang.php");?>

</body>

</html>
