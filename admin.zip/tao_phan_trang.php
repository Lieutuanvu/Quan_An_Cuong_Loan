<?php
$so_hd=$ketnoi->query("SELECT `id_hoadon` FROM `hoadon_vanchuyen` WHERE `thang_tao`='$thang' AND `nam_tao`='$nam' ORDER BY `id_hoadon` DESC");
if ($so_hd){
    $tong_record=$so_hd->num_rows; //Lấy tổng sô hoá đơn
}
$hien_thi=5;//Hiển thị 1 trang là 5 hoá đơn
$so_trang=ceil($tong_record/$hien_thi);//Chia lấy số nguyên trang, tổng hoá đơn / 10 hoá đơn 1 trang

if(!isset($_GET['trang'])){
    $trang_hien_tai=1;

} else if (isset($_GET['trang'])){
    $trang_hien_tai=$_GET['trang'];
    if ($trang_hien_tai>$so_trang){ //Truy cập trang lớn hơn tổng số trang
        $trang_hien_tai=$so_trang;
    } else if ($trang_hien_tai<1){  //Truy cập trang nhỏ hơn 1 thì quá sai
        $trang_hien_tai=1;
    }

}
$bat_dau_hien_thi=($trang_hien_tai-1)*$hien_thi; // Hiển thị từ $bat_dau_hien_thi trang đến $hien_thi trang


?>