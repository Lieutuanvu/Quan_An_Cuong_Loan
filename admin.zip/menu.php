<div class="header-area header-bottom">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-9  d-none d-lg-block">
                        <div class="horizontal-menu">
                            <nav>
                                <ul id="nav_menu">
                                    <li>
                                        <a href="/"><i class="ti-dashboard"></i><span>Trang chủ</span></a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0)"><i class="ti-pie-chart"></i><span>Thống kê </span><span class="badge badge-danger" id="noti_dat_mon_1">0</span></a>
                                        <ul class="submenu">
                                        <li><a href="danh-sach-dat-mon.php">Khách đặt món <span class="badge badge-danger" id="noti_dat_mon_2">0</span></a></li>
                                        <li><a href="danh-sach-hoa-don.php">Danh sách hoá đơn</a></li>
                                        <li><a href="danh-sach-tiec.php">Danh sách tiệc sắp tới</a></li>
                                        <li><a href="danh-sach-tiec-da-qua.php">Danh sách tiệc đã qua</a></li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0)"><i class="ti-palette"></i><span>Nhập liệu</span></a>
                                        <ul class="submenu">
                                        <li><a href="goi-thuc-an.php">Nhập hoá đơn mới</a></li>
                                        <li><a href="dat-tiec.php">Nhập tiệc khách đặt</a></li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0)"><i class="ti-layers-alt"></i><span>Nhân viên</span></a>
                                        <ul class="submenu">
                                            <li><a href="nhanvien.php">Tổng quát nhân viên</a></li>
                                            <li><a href="nhap-nhanvien-moi.php">Nhân viên mới</a></li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0)"><i class="ti-pencil"></i><span>Xuất hoá đơn</span></a>
                                        <ul class="submenu">
                                            <li><a href="goi-thuc-an.php">Nhập hoá đơn mới</a></li>
                                            <li><a href="danh-sach-hoa-don.php">Danh sách hoá đơn</a></li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href="logout.php"><i class="fa fa-sign-out"></i></i><span>Thoát tài khoản</span></a>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    </div>

                    <!-- mobile_menu -->
                    <div class="col-12 d-block d-lg-none">
                        <div id="mobile_menu"></div>
                    </div>
                </div>
            </div>
        </div>
<script type="text/javascript">
//jquery lấy số đơn đặt món theo thời gian thực
 function get_don_dat_mon() {
  setInterval(function(){
   var xhttp = new XMLHttpRequest();
   xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
        document.getElementById("noti_dat_mon_1").innerHTML = this.responseText;
        document.getElementById("noti_dat_mon_2").innerHTML = this.responseText;
    }
   };
   xhttp.open("GET", "dem_don_dat_mon.php", true);
   xhttp.send();

  },30000); //Khai báo từ 1000 = 1 giây trở lên để tránh bị gọi liên tục chiếm cpu
 }
 get_don_dat_mon();
</script>        