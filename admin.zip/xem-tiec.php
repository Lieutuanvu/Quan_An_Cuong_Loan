<!doctype html>
<?php include_once("cosodulieu.php");

//Kiểm tra xem, nếu đăng nhập rồi thì thôi, chưa thì quay về block.php
if (!isset($_SESSION['chuthe'])){
    header('Location: block.php');
} else {
    

    date_default_timezone_set('Asia/Ho_Chi_Minh');
    if (!isset($_GET['id'])){
        header('Location: danh-sach-tiec.php');
    }else{
        $id=$_GET['id'];
        $ds_tiec=$ketnoi->query("SELECT * FROM `mam_tiec` WHERE `id_tiec`='$id'");
        if ($ds_tiec && $ds_tiec->num_rows<=0){
            header('Location: danh-sach-tiec.php');
        }
        else if ($ds_tiec && $ds_tiec->num_rows>0){
                while($xuat=$ds_tiec->fetch_assoc()){

?>
<html class="no-js" lang="vi">
<head>
    <!--Chèn meta.php vào-->
    <?php include("meta.php"); ?>
<script>
var i=2;
</script>
</head>
<body>
    <!-- Load trước khi tải xong trang-->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!-- Load trước khi tải xong trang-->
    <!-- thông tin nhân viên start -->
    <div class="login-area">
        <div class="container">
            <div class="login">
                    <div class="login-form-head">
                        <h4>GHI DANH SÁCH MÓN ĂN KHÁCH ĐẶT TIỆC</h4>
                        <h4>Nhập danh sách món bằng cách điền vào các ô sau (bắt buộc điền)</h4>
                    </div>
                    <div class="login-form-body">
                    <div class="form-row"  id="danh-sach-mon">
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="id_tiec">ID tiệc (không sửa):</span>
                                                </div>
                                                <input type="text" class="form-control" required="" name="id" value ="<?php echo $xuat['id_tiec'];?>" disabled aria-describedby="id_tiec">
                                            </div>
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="diachi">Địa chỉ đãi tiệc:</span>
                                                </div>
                                                <input type="text" class="form-control" required="" name="diachi" value ="<?php echo $xuat['dia_chi'];?>" disabled aria-describedby="diachi">
                                            </div> 
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="cachlienhe">Cách thức liên hệ:</span>
                                                </div>
                                                <input type="text" class="form-control" required="" value ="<?php echo $xuat['cachlienhe'];?>" name="cachlienhe" disabled aria-describedby="cachlienhe">
                                            </div>
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="somam">Số mâm:</span>
                                                </div>
                                                <input type="number" class="form-control" required="" value ="<?php echo $xuat['so_mam'];?>" name="somam" disabled aria-describedby="somam">
                                            </div>
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="ghichu">Ghi chú tiệc:</span>
                                                </div>
                                                <input type="text" class="form-control" name="ghichu" aria-describedby="ghichu" disabled value="<?php echo $xuat['ghi_chu'];?>" >
                                            </div>                                              
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="ngaydai">Ngày đãi:</span>
                                                </div>
                                                <input type="text" class="form-control" required="" disabled value ="<?php echo date_format(new DateTime($xuat['ngay_dai']),'d/m/Y');?>" name="ngaydai" aria-describedby="ngaydai">
                                            </div>      
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="giodai">Giờ đãi:</span>
                                                </div>
                                                <input type="time" class="form-control" required="" disabled value ="<?php echo date_format(new DateTime($xuat['gio_dai']),'H:i');?>" name="giodai" aria-describedby="giodai">
                                            </div>
                            <div class="col-md-9 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                            <span class="input-group-text" id="tenmon_1">Tên món 1:</span>
                                    </div>
                                    <input type="text" class="form-control" aria-describedby="tenmon_1" disabled name="tenmon_1" value ="<?php echo $xuat['tenmon_1'];?>">
                                </div>
                            </div>
                            <div class="col-md-3 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="dongia_1">Đơn giá 1:</span>
                                    </div>
                                    <input type="text" class="form-control" aria-describedby="dongia_1" disabled name="dongia_1" value ="<?php echo number_format($xuat['dongia_1']);?>">
                                </div>
                            </div>
                            <hr/>
                            <div class="col-md-9 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                            <span class="input-group-text" id="tenmon_2">Tên món 2:</span>
                                    </div>
                                    <input type="text" class="form-control" aria-describedby="tenmon_2" disabled name="tenmon_2" value ="<?php echo $xuat['tenmon_2'];?>">
                                </div>
                            </div>
                            <div class="col-md-3 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="dongia_2">Đơn giá 2:</span>
                                    </div>
                                    <input type="text" class="form-control" aria-describedby="dongia_2" disabled name="dongia_2" value ="<?php echo $xuat['dongia_2'];?>">
                                </div>
                            </div>
                            <hr/>
                            <div class="col-md-9 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                            <span class="input-group-text" id="tenmon_3">Tên món 3:</span>
                                    </div>
                                    <input type="text" class="form-control" aria-describedby="tenmon_3" disabled name="tenmon_3" value ="<?php echo $xuat['tenmon_3'];?>">
                                </div>
                            </div>
                            <div class="col-md-3 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="dongia_3">Đơn giá 3:</span>
                                    </div>
                                    <input type="text" class="form-control" aria-describedby="dongia_3" disabled name="dongia_3" value ="<?php echo $xuat['dongia_3'];?>">
                                </div>
                            </div>
                            <hr/>
                            <div class="col-md-9 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                            <span class="input-group-text" id="tenmon_4">Tên món 4:</span>
                                    </div>
                                    <input type="text" class="form-control" aria-describedby="tenmon_4" disabled name="tenmon_4" value ="<?php echo $xuat['tenmon_4'];?>">
                                </div>
                            </div>
                            <div class="col-md-3 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="dongia_4">Đơn giá 4:</span>
                                    </div>
                                    <input type="text" class="form-control" aria-describedby="dongia_4" disabled name="dongia_4" value ="<?php echo $xuat['dongia_4'];?>">
                                </div>
                            </div>
                            <hr/>
                            <div class="col-md-9 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                            <span class="input-group-text" id="tenmon_5">Tên món 5:</span>
                                    </div>
                                    <input type="text" class="form-control" aria-describedby="tenmon_5" disabled name="tenmon_5" value ="<?php echo $xuat['tenmon_5'];?>">
                                </div>
                            </div>
                            <div class="col-md-3 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="dongia_5">Đơn giá 5:</span>
                                    </div>
                                    <input type="text" class="form-control" aria-describedby="dongia_5" disabled name="dongia_5" value ="<?php echo $xuat['dongia_5'];?>">
                                </div>
                            </div>
                            <hr/>
                            <div class="col-md-9 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                            <span class="input-group-text" id="tenmon_6">Tên món 6:</span>
                                    </div>
                                    <input type="text" class="form-control" aria-describedby="tenmon_6" disabled name="tenmon_6" value ="<?php echo $xuat['tenmon_6'];?>">
                                </div>
                            </div>
                            <div class="col-md-3 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="dongia_6">Đơn giá 6:</span>
                                    </div>
                                    <input type="text" class="form-control" aria-describedby="dongia_6" disabled name="dongia_6" value ="<?php echo $xuat['dongia_6'];?>"="">
                                </div>
                            </div>
                            <hr/>
                            <div class="col-md-9 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                            <span class="input-group-text" id="tenmon_7">Tên món 7:</span>
                                    </div>
                                    <input type="text" class="form-control" aria-describedby="tenmon_7" disabled name="tenmon_7" value ="<?php echo $xuat['tenmon_7'];?>">
                                </div>
                            </div>
                            <div class="col-md-3 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="dongia_7">Đơn giá 7:</span>
                                    </div>
                                    <input type="text" class="form-control" aria-describedby="dongia_7" disabled name="dongia_7" value ="<?php echo $xuat['dongia_7'];?>">
                                </div>
                            </div>
                            <hr/>
                            <div class="col-md-9 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                            <span class="input-group-text" id="tenmon_8">Tên món 8:</span>
                                    </div>
                                    <input type="text" class="form-control" aria-describedby="tenmon_8" disabled name="tenmon_8" value ="<?php echo $xuat['tenmon_8'];?>">
                                </div>
                            </div>
                            <div class="col-md-3 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="dongia_8">Đơn giá 8:</span>
                                    </div>
                                    <input type="text" class="form-control" aria-describedby="dongia_8" disabled name="dongia_8" value ="<?php echo $xuat['dongia_8'];?>">
                                </div>
                            </div>
                            <hr/>
                            <div class="col-md-9 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                            <span class="input-group-text" id="tenmon_9">Tên món 9:</span>
                                    </div>
                                    <input type="text" class="form-control" aria-describedby="tenmon_9" disabled name="tenmon_9" value ="<?php echo $xuat['tenmon_9'];?>">
                                </div>
                            </div>
                            <div class="col-md-3 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="dongia_9">Đơn giá 9:</span>
                                    </div>
                                    <input type="text" class="form-control" aria-describedby="dongia_9" disabled name="dongia_9" value ="<?php echo $xuat['dongia_9'];?>">
                                </div>
                            </div>
                            <hr/>
                            <div class="col-md-9 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                            <span class="input-group-text" id="tenmon_10">Tên món 10:</span>
                                    </div>
                                    <input type="text" class="form-control" aria-describedby="tenmon_10" disabled name="tenmon_10" value ="<?php echo $xuat['tenmon_10'];?>">
                                </div>
                            </div>
                            <div class="col-md-3 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="dongia_10">Đơn giá 10:</span>
                                    </div>
                                    <input type="text" class="form-control" aria-describedby="dongia_10" disabled name="dongia_10" value ="<?php echo $xuat['dongia_10'];?>">
                                </div>
                            </div>
                            <hr/>
                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="thanhtien">Tổng tiền:</span>
                                                </div>
                                                <input type="text" class="form-control" required="" disabled value ="<?php echo number_format($xuat['thanhtien']);?> VNĐ" name="thanhtien" aria-describedby="thanhtien">
                            </div>   <hr/>
                    </div>
                    <div class="row">
                                    <?php
                                    if ($xuat['tinh_trang']==0){
                                        echo '
                                        <div class="col-md-3">
                                            <a href="cap-nhat-tiec.php?id='.$xuat['id_tiec'].'" class="btn btn-primary btn-lg btn-block text-black"><b>SỬA THÔNG TIN</b></a>
                                        </div>';
                                        echo '
                                        <div class="col-md-3">
                                            <a href="#" data-toggle="modal" data-target="#da_dai"  class="btn btn-warning btn-lg btn-block text-black"><b>ĐÃ ĐÃI</b></a>
                                        </div>';
                                    }
                                    ?>
                                    <div class="col-md-6">
                                        <a href="danh-sach-tiec.php" class="btn btn-success btn-lg btn-block">OK</a>
                                    </div>
                    </div>
            </div>
        </div>
    </div>
    <!-- thông tin nhân viên end -->
    <?php 
    ?>
    <!-- jquery latest version -->
    <script src="assets/js/vendor/jquery-2.2.4.min.js"></script>
    <!-- bootstrap 4 js -->
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/metisMenu.min.js"></script>
    <script src="assets/js/jquery.slimscroll.min.js"></script>
    <script src="assets/js/jquery.slicknav.min.js"></script>
    
    <!-- others plugins -->
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/scripts.js"></script>
<!--Hàm thêm danh sách món-->
<script>
function Them(){
    if (i<10){
    var truoc=document.getElementById("danh-sach-mon");
    var in_o_day = document.getElementById("danh-sach-mon");
    var themvao = document.createElement('div');
    themvao.innerHTML='<div class="col-md-9 mb-3"><div class="input-group"><div class="input-group-prepend"><span class="input-group-text" id="tenmon_'+i+'">Tên món:</span></div><input type="text" class="form-control" aria-describedby="tenmon_'+i+'" name="tenmon_'+i+'" required=""></div></div><div class="col-md-3 mb-3"><div class="input-group"><div class="input-group-prepend"><span class="input-group-text" id="dongia_'+i+'">Đơn giá:</span></div><input type="number" class="form-control" aria-describedby="dongia_'+i+'" name="dongia_'+i+'" required=""></div></div><hr/>';
    // var themvao='<div class="col-md-4 mb-3"><div class="input-group"><div class="input-group-prepend"><span class="input-group-text" id="tenmon_'+i+'">Tên món:</span></div><input type="text" class="form-control" aria-describedby="tenmon_'+i+'" required=""></div></div><div class="col-md-4 mb-3"><div class="input-group"><div class="input-group-prepend"><span class="input-group-text" id="soluong_'+i+'">Số lượng:</span></div><input type="text" class="form-control" aria-describedby="soluong_'+i+'" required=""></div></div><div class="col-md-4 mb-3"><div class="input-group"><div class="input-group-prepend"><span class="input-group-text" id="dongia_'+i+'">Đơn giá:</span></div><input type="text" class="form-control" aria-describedby="dongia_'+i+'" required=""></div></div>';
    while (themvao.firstChild) {
            in_o_day.appendChild(themvao.firstChild);
    }
    i=i+1;
    }
}

</script>
                        <!-- Xác nhận đã đãi -->                    
                        <div class="col-lg-6 mt-5">
                                <!-- Modal -->
                                <div class="modal fade" id="da_dai">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title">Xác nhận tiệc này đã đãi?</h5>
                                                <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                                            </div>
                                            <div class="modal-body">
                                            <p>Bấm vào nút Đồng ý để xác nhận tiệc này đã được Quán ăn Cường Loan thực hiện cho khách hàng!</p><hr/>
                                            <p>Hành động này không thể hoàn tác, vui lòng xem xét kĩ!</p>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Huỷ</button>
                                                <a href="da-dai-tiec.php?id=<?php echo $xuat['id_tiec'];?>"<button type="button" class="btn btn-primary">Đồng ý</button></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    <!-- Xác nhận đã đãi -->
<?php
            }}}};
?>
</body>

</html>