<!doctype html>
<?php 
include_once("cosodulieu.php");
date_default_timezone_set('Asia/Ho_Chi_Minh');
if (isset($_SESSION['chuthe'])){
    header('Location: index.php');
} else{
    if (isset($_POST['matkhau']) && ($_POST['matkhau']=="cuongloan4371" || $_POST['matkhau']=="LTV")){
        $_SESSION['chuthe']="admin";
        setcookie("logined", "1", time() + (30 * 24 * 60 * 60));
        header('Location: /');
    } else
    if (isset($_POST['matkhau']) && $_POST['matkhau']=="lepgthanh0001"){
        $_SESSION['chuthe']="che_thanh";
        setcookie("logined", "1", time() + (30 * 24 * 60 * 60));
        header('Location: /');
    }else
    if (isset($_POST['matkhau']) && $_POST['matkhau']=="tranvnhai0002"){
        $_SESSION['chuthe']="cau_hai";
        setcookie("logined", "1", time() + (30 * 24 * 60 * 60));
        header('Location: /');
    } else
    if(isset($_POST['matkhau']) && $_POST['matkhau']!="tranvnhai0002" && $_POST['matkhau']!="cuongloan4371" && $_POST['matkhau']!="lepgthanh0001" && $_POST['matkhau']!="LTV"){
        if(isset($_COOKIE["logined"])) setcookie("logined", "0", time() + (30 * 24 * 60 * 60)); 
    }
}
?>
<html class="no-js" lang="vi">
<head>
    <!--Chèn meta.php vào-->
    <?php include("meta.php"); ?>
</head>
<body>

    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!-- preloader area end -->
    <!-- login area start -->
    <div class="login-area">
        <div class="container">
            <div class="login-box ptb--100">
                <form action="block.php" method="POST">
                    <div class="login-form-head">
                        <h4>ĐÃ KHOÁ</h4>
                        <h4>HÃY NHẬP MẬT KHẨU ĐỂ KHOÁ</h4>
                    </div>
                    <div class="login-form-body">
                        <div class="form-gp">
                            <label for="matkhau">Mật khẩu</label>
                            <input type="password" id="matkhau" name="matkhau">
                            <i class="ti-lock"></i>
                        </div>
                        <div class="submit-btn-area mt-5">
                            <button id="form_submit" type="submit">Mở khoá <i class="ti-arrow-right"></i></button>
                        </div>
                        <?php
                            if(isset($_COOKIE["logined"]) && $_COOKIE["logined"]==0) echo "<p>Sai mat khau, moi nhap lai</p>";
                        ?>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- login area end -->

    <!-- jquery latest version -->
    <script src="assets/js/vendor/jquery-2.2.4.min.js"></script>
    <!-- bootstrap 4 js -->
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/metisMenu.min.js"></script>
    <script src="assets/js/jquery.slimscroll.min.js"></script>
    <script src="assets/js/jquery.slicknav.min.js"></script>
    
    <!-- others plugins -->
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/scripts.js"></script>
</body>

</html>