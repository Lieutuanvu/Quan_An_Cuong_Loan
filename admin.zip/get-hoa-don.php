<?php
include_once("cosodulieu.php");
if (!isset($_SESSION['chuthe'])){
    header('Location: block.php');
} else {

    if (!isset($_GET['id'])){
        header('Location: danh-sach-hoa-don.php');
    } else{
        $id=$_GET['id'];
        $lay_hoa_don=$ketnoi->query("SELECT * FROM `hoadon_vanchuyen` WHERE `id_hoadon`='$id'");
        if ($lay_hoa_don && $lay_hoa_don->num_rows>0){
            while($xuat=$lay_hoa_don->fetch_assoc()){
?>
                                                <!--- In món 1-->
                                                <?php
                                                echo '                                            
                                                <thead>
                                                    <tr class="text-capitalize">
                                                        <th class="text-center">STT</th>
                                                        <th class="text-left">Tên món</th>
                                                        <th class="text-center">Số lượng</th>
                                                        <th class="text-center">Đơn giá</th>
                                                        <th>Tổng cộng</th>
                                                    </tr>
                                                </thead>
                                                <tbody>';
                                                echo '<tr>';
                                                echo '<td class="text-center">1</td>';
                                                echo '<td class="text-left">'.$xuat['tenmon_1'].'</td>';
                                                echo '<td class="text-center">'.$xuat['soluong_1'].'</td>';
                                                echo '<td class="text-center">'.number_format($xuat['dongia_1']).'</td>';
                                                echo '<td>'.number_format($xuat['dongia_1']*$xuat['soluong_1']).'</td>';
                                                echo '</tr>';
                                                ?>
                                                <!--- In món 2-->
                                                <?php
                                                if ($xuat['tenmon_2']!=""){
                                                    echo '<tr>';
                                                    echo '<td class="text-center">2</td>';
                                                    echo '<td class="text-left">'.$xuat['tenmon_2'].'</td>';
                                                    echo '<td class="text-center">'.$xuat['soluong_2'].'</td>';
                                                    echo '<td class="text-center">'.number_format($xuat['dongia_2']).'</td>';
                                                    echo '<td>'.number_format($xuat['dongia_2']*$xuat['soluong_2']).'</td>';
                                                    echo '</tr>';
                                                }
                                                ?>
                                                <!--- In món 3-->
                                                <?php
                                                if ($xuat['tenmon_3']!=""){
                                                    echo '<tr>';
                                                    echo '<td class="text-center">3</td>';
                                                    echo '<td class="text-left">'.$xuat['tenmon_3'].'</td>';
                                                    echo '<td class="text-center">'.$xuat['soluong_3'].'</td>';
                                                    echo '<td class="text-center">'.number_format($xuat['dongia_3']).'</td>';
                                                    echo '<td>'.number_format($xuat['dongia_3']*$xuat['soluong_3']).'</td>';
                                                    echo '</tr>';
                                                }
                                                ?>
                                                <!--- In món 4-->
                                                <?php
                                                if ($xuat['tenmon_4']!=""){
                                                    echo '<tr>';
                                                    echo '<td class="text-center">4</td>';
                                                    echo '<td class="text-left">'.$xuat['tenmon_4'].'</td>';
                                                    echo '<td class="text-center">'.$xuat['soluong_4'].'</td>';
                                                    echo '<td class="text-center">'.number_format($xuat['dongia_4']).'</td>';
                                                    echo '<td>'.number_format($xuat['dongia_4']*$xuat['soluong_4']).'</td>';
                                                    echo '</tr>';
                                                }
                                                ?>
                                                <!--- In món 5-->
                                                <?php
                                                if ($xuat['tenmon_5']!=""){
                                                    echo '<tr>';
                                                    echo '<td class="text-center">5</td>';
                                                    echo '<td class="text-left">'.$xuat['tenmon_5'].'</td>';
                                                    echo '<td class="text-center">'.$xuat['soluong_5'].'</td>';
                                                    echo '<td class="text-center">'.number_format($xuat['dongia_5']).'</td>';
                                                    echo '<td>'.number_format($xuat['dongia_5']*$xuat['soluong_5']).'</td>';
                                                    echo '</tr>';
                                                }
                                                ?>
                                                <!--- In món 6-->
                                                <?php
                                                if ($xuat['tenmon_6']!=""){
                                                    echo '<tr>';
                                                    echo '<td class="text-center">6</td>';
                                                    echo '<td class="text-left">'.$xuat['tenmon_6'].'</td>';
                                                    echo '<td class="text-center">'.$xuat['soluong_6'].'</td>';
                                                    echo '<td class="text-center">'.number_format($xuat['dongia_6']).'</td>';
                                                    echo '<td>'.number_format($xuat['dongia_6']*$xuat['soluong_6']).'</td>';
                                                    echo '</tr>';
                                                }
                                                ?>
                                                <!--- In món 7-->
                                                <?php
                                                if ($xuat['tenmon_7']!=""){
                                                    echo '<tr>';
                                                    echo '<td class="text-center">7</td>';
                                                    echo '<td class="text-left">'.$xuat['tenmon_7'].'</td>';
                                                    echo '<td class="text-center">'.$xuat['soluong_7'].'</td>';
                                                    echo '<td class="text-center">'.number_format($xuat['dongia_7']).'</td>';
                                                    echo '<td>'.number_format($xuat['dongia_7']*$xuat['soluong_7']).'</td>';
                                                    echo '</tr>';
                                                }
                                                ?>
                                                <!--- In món 8-->
                                                <?php
                                                if ($xuat['tenmon_8']!=""){
                                                    echo '<tr>';
                                                    echo '<td class="text-center">8</td>';
                                                    echo '<td class="text-left">'.$xuat['tenmon_8'].'</td>';
                                                    echo '<td class="text-center">'.$xuat['soluong_8'].'</td>';
                                                    echo '<td class="text-center">'.number_format($xuat['dongia_8']).'</td>';
                                                    echo '<td>'.number_format($xuat['dongia_8']*$xuat['soluong_8']).'</td>';
                                                    echo '</tr>';
                                                }
                                                ?>
                                                <!--- In món 9-->
                                                <?php
                                                if ($xuat['tenmon_9']!=""){
                                                    echo '<tr>';
                                                    echo '<td class="text-center">9</td>';
                                                    echo '<td class="text-left">'.$xuat['tenmon_9'].'</td>';
                                                    echo '<td class="text-center">'.$xuat['soluong_9'].'</td>';
                                                    echo '<td class="text-center">'.number_format($xuat['dongia_9']).'</td>';
                                                    echo '<td>'.number_format($xuat['dongia_9']*$xuat['soluong_9']).'</td>';
                                                    echo '</tr>';
                                                }
                                                ?>
                                                <!--- In món 10-->
                                                <?php
                                                if ($xuat['tenmon_10']!=""){
                                                    echo '<tr>';
                                                    echo '<td class="text-center">10</td>';
                                                    echo '<td class="text-left">'.$xuat['tenmon_10'].'</td>';
                                                    echo '<td class="text-center">'.$xuat['soluong_10'].'</td>';
                                                    echo '<td class="text-center">'.number_format($xuat['dongia_10']).'</td>';
                                                    echo '<td>'.number_format($xuat['dongia_10']*$xuat['soluong_10']).'</td>';
                                                    echo '</tr>';
                                                }
                                                echo '
                                                    <tr>        
                                                        <td class="text-center">*</td>
                                                        <td class="text-left">Rau-bún-bánh tráng-nước chấm (nếu có)</td>
                                                        <td class="text-center">Kèm</td>
                                                        <td class="text-center"></td>
                                                        <td></td>
                                                    </tr>
                                                </tbody>';
                                                echo'
                                                <tfoot>
                                                    <tr>
                                                        <td colspan="4">Thành tiền :</td>
                                                        <td id="tong_so_tien" style="display:none!important;">'.$xuat['thanhtien'].'</td>
                                                        <td>'.number_format($xuat['thanhtien']).'</td>
                                                    </tr>
                                                </tfoot>';
                                                ?>


<?php
        }
    }

}}

?>
    <script src="assets/js/vendor/jquery-2.2.4.min.js" async></script>

<script>  
    //Chuyển số sang chữ by DNT
    var sotien=document.getElementById("tong_so_tien").innerHTML;
	var Number=function(){var t=["không","một","hai","ba","bốn","năm","sáu","bảy","tám","chín"],r=function(r,n){var o="",a=Math.floor(r/10),e=r%10;return a>1?(o=" "+t[a]+" mươi",1==e&&(o+=" mốt")):1==a?(o=" mười",1==e&&(o+=" một")):n&&e>0&&(o=" lẻ"),5==e&&a>=1?o+=" lăm":4==e&&a>=1?o+=" tư":(e>1||1==e&&0==a)&&(o+=" "+t[e]),o},n=function(n,o){var a="",e=Math.floor(n/100),n=n%100;return o||e>0?(a=" "+t[e]+" trăm",a+=r(n,!0)):a=r(n,!1),a},o=function(t,r){var o="",a=Math.floor(t/1e6),t=t%1e6;a>0&&(o=n(a,r)+" triệu",r=!0);var e=Math.floor(t/1e3),t=t%1e3;return e>0&&(o+=n(e,r)+" ngàn",r=!0),t>0&&(o+=n(t,r)),o};return{doc:function(r){if(0==r)return t[0];var n="",a="";do ty=r%1e9,r=Math.floor(r/1e9),n=r>0?o(ty,!0)+a+n:o(ty,!1)+a+n,a=" tỷ";while(r>0);return n.trim()}}}();
    document.getElementById("tienbangchu").innerHTML="Tiền bằng chữ: "+Number.doc(sotien)+" đồng (VND)";
</script>  