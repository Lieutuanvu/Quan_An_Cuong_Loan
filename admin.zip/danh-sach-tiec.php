<?php
include_once("cosodulieu.php");

//Kiểm tra xem, nếu đăng nhập rồi thì thôi, chưa thì quay về block.php
if (!isset($_SESSION['chuthe'])){
    header('Location: block.php');
}

date_default_timezone_set('Asia/Ho_Chi_Minh');
$homnay=date('Y-m-d');
$thang=date('m');
$nam=date('Y');

if (!isset($_GET['thang']) || !isset($_GET['nam'])){ //Nếu không get được tháng năm thì thôi, in tất cả
    include_once("tao_phan_trang_dstiec.php");
    $ds_tiec=$ketnoi->query("SELECT `id_tiec`,`ngay`,`thang`,`nam`, `tinh_trang`, `so_mam`, `ngay_dai`, `gio_dai`, `thanhtien` FROM `mam_tiec` WHERE `tinh_trang`=0 AND `thang`='$thang' AND `nam`='$nam' ORDER BY `ngay_dai` ASC, `gio_dai` ASC LIMIT $bat_dau_hien_thi,$hien_thi");
} else 
if (isset($_GET['thang']) && isset($_GET['nam'])){ //Nếu get được tháng với năm thì in tiệc theo điều kiện đó
    $nam=$_GET['nam'];
    $thang=$_GET['thang'];
    include_once("tao_phan_trang_dstiec.php");
    $ds_tiec=$ketnoi->query("SELECT `id_tiec`,`ngay`,`thang`,`nam`, `tinh_trang`, `so_mam`, `ngay_dai`, `gio_dai`, `thanhtien` FROM `mam_tiec` WHERE  `tinh_trang`=0 AND `thang`='$thang' AND `nam`='$nam'  ORDER BY `ngay_dai` ASC, `gio_dai` ASC LIMIT $bat_dau_hien_thi,$hien_thi");
}


?>
<html class="no-js" lang="vi">
<head>
    <!--Chèn meta.php vào-->
    <?php include("meta.php"); ?>
</head>
<body class="body-bg">
    <!-- Load trước khi tải xong trang-->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!-- Load trước khi tải xong trang-->
    <!-- main wrapper start -->
        <div class="horizontal-main-wrapper">
        <!-- chèn mainhead.php vào đây -->
        <?php include("mainheader.php"); ?>
        <!-- chèn mainhead.php vào đây -->
        <!-- Đặt menu -->
        <?php include("menu.php");?>
        <!-- Đặt menu -->
            <div class="main-content-inner">
                <div class="row">
                    <!-- danh sách tiệc -->
                    <div class="col-12 mt-5">
                        <div class="card">
                            <div class="card-body">
                                        <h4 class="header-title">Danh sách tiệc sắp tới trong tháng <?php echo $thang;?> năm <?php echo $nam;?></h4>
                                        <form action="danh-sach-tiec.php" method="GET">
                                                <div class="form-row align-items-center">
                                                    <div class="col-sm-3 my-1">
                                                        <select name="thang" class="form-control">
                                                            <option value="<?php echo $thang;?>">Tháng <?php echo $thang;?></option>
                                                            <?php
                                                            for ($i=1;$i<=12;$i++){
                                                                if ($i!=$thang){
                                                                    echo'<option value="'.$i.'">Tháng '.$i.'</option>';
                                                                }
                                                            } 
                                                            ?>
                                                        </select>
                                                    </div>                            
                                                    <div class="col-sm-3 my-1">
                                                        <select name="nam" class="form-control">
                                                            <option value="<?php echo $nam;?>">Năm <?php echo $nam;?></option>
                                                            <?php
                                                            $nam_hien_tai=date('Y');
                                                            for ($i=2020;$i<=$nam_hien_tai;$i++){
                                                                if ($i!=$nam){
                                                                echo'<option value="'.$i.'">Năm '.$i.'</option>';
                                                                }
                                                            } 
                                                            ?>
                                                        </select>                                            
                                                    </div>
                                                    <div class="col-auto my-1">
                                                        <button type="submit" class="btn btn-primary">XEM</button>
                                                    </div>
                                                </div>
                                            </form>
                                        <div class="single-table">
                                            <div class="table-responsive">
                                                <table class="table table-hover progress-table text-center">
                                                    <thead class="text-uppercase">
                                                        <tr>
                                                            <th scope="col">STT</th>
                                                            <th scope="col">Ngày đãi</th>
                                                            <th scope="col">Giờ đãi</th>
                                                            <th scope="col">Số mâm</th>
                                                            <th scope="col">Giá tiền (VND)</th>
                                                            <th scope="col">Trạng thái</th>
                                                            <th scope="col">Xem chi tiết</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                        $stt=0;
                                                        if ($ds_tiec && $ds_tiec->num_rows>0){
                                                            while($xuat=$ds_tiec->fetch_assoc()){
                                                        
                                                                    $chuyen_doi_ngay_dai=strtotime($xuat['ngay_dai']);//Chuyển ngày đãi về giây so với hiện tại;
                                                                    $chuyen_doi_ngay_hom_nay=strtotime($homnay);//Chuyển ngày hôm nay về giây so với hiện tại;
                                                                    $tru_ngay=$chuyen_doi_ngay_dai-$chuyen_doi_ngay_hom_nay; //Trừ 2 ngày cho nhau để kiểm tra còn bao nhiêu ngày tới tiệc
                                                                    $conlai="Còn lại ".floor($tru_ngay/(60*60*24))." ngày";
                                                                    $class='class="text-success"';
                                                                    if (floor($tru_ngay/(60*60*24))<=3){$class='class="text-danger"';} 
                                                                    if(floor($tru_ngay/(60*60*24))<0){
                                                                        $conlai="Đã qua";
                                                                    }
                                                                    echo '<tr>';$stt++;
                                                                    echo    '<th scope="row">'.$stt.'</th>';
                                                                    echo    '<th scope="row">'.date_format(new DateTime($xuat['ngay_dai']),'d-m-Y').'</th>';
                                                                    echo    '<th scope="row">'.date_format(new DateTime($xuat['gio_dai']),'H:i').'</th>';
                                                                    echo    '<th scope="row">'.$xuat['so_mam'].'</th>';
                                                                    echo    '<td>'.number_format($xuat['thanhtien']).'</td>';
                                                                    echo    '<td '.$class.'><b>'.$conlai.'</b></td>'; 
                                                                    echo    '<td><a href="xem-tiec.php?id='.$xuat['id_tiec'].'">XEM</a></td>'; 
                                                                    echo '</tr>';

                                                            }
                                                        }
                                                        ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        <?php
                                                //Tiếp tục của if ($ds_tiec->num_rows>0) ở trên
                                                if  ($ds_tiec && $ds_tiec->num_rows<=0) { //Tháng và năm này không có tiệc thì không hiển thị
                                                    echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                                                                <strong><h4>Tháng '.$thang.' năm '.$nam.' không có tiệc</h4></strong>
                                                            </div>';    
                                                        }
                                        ?>
                                        <!--Hiển thị phân trang-->
                                        <div class="col-lg-12 col-md-6 mt-5">
                                            <div class="card">
                                                <div class="card-body">
                                                        <ul class="pagination justify-content-center">          
                                                            <?php
                                                            //In phân trang
                                                            for($i=1;$i<=$so_trang;$i++){
                                                                $link='href="danh-sach-tiec.php?thang='.$thang.'&nam='.$nam.'&trang='.$i.'#sap-toi"';
                                                                if ($i==$trang_hien_tai){//Nếu đang ở trang đó thì vô hiệu pagination đó
                                                                echo '<li class="page-item active">';
                                                                $link="disabled";
                                                                } else{
                                                                echo '<li class="page-item">';
                                                                }
                                                                echo'<a tabindex="-1" '.$link.' class="page-link">'.$i.'</a></li>';
                                                            }
                                                            clearstatcache();                                                
                                                            ?>
                                                            
                                                        </ul>
                                                    </nav>
                                                </div>
                                            </div>
                                        </div>
                                        <!--Hiển thị phân trang--> 
                            </div>
                        </div>
                    </div>
                    <!-- Danh sách tiệc end -->
                </div>
            </div>
        </div>      
        <!-- footer area start-->
        <!-- chèn footer.php ở đây-->
        <?php include("footer.php"); ?>
        <!-- chèn footer.php ở đây-->
    </div>
<!--Đặt dinhdang.php các css, js, jquery, plugin ở đây-->
<?php include_once("dinhdang.php");?>
</body>

</html>
