<!doctype html>
<?php include_once("cosodulieu.php");
//Kiểm tra xem, nếu đăng nhập rồi thì thôi, chưa thì quay về block.php
if (!isset($_SESSION['chuthe'])){
    header('Location: block.php');
} else{

    date_default_timezone_set('Asia/Ho_Chi_Minh');
    if (!isset($_GET['id'])){
        header('Location: danh-sach-tiec.php');
    }else{
        $id=$_GET['id'];
        $ds_tiec=$ketnoi->query("SELECT * FROM `mam_tiec` WHERE `id_tiec`='$id'");
        if ($ds_tiec && $ds_tiec->num_rows<=0){
            header('Location: danh-sach-tiec.php');
        }
        else if ($ds_tiec && $ds_tiec->num_rows>0){
                while($xuat=$ds_tiec->fetch_assoc()){

?>
<html class="no-js" lang="vi">
<head>
    <!--Chèn meta.php vào-->
    <?php include("meta.php"); ?>
<script>
var i=2;
</script>
</head>
<body>
    <!-- Load trước khi tải xong trang-->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!-- Load trước khi tải xong trang-->
    <!-- thông tin nhân viên start -->
    <div class="login-area">
        <div class="container">
            <div class="login">
                <form action="capnhat-tiec.php" method="POST">
                    <div class="login-form-head">
                        <h4>GHI DANH SÁCH MÓN ĂN KHÁCH ĐẶT TIỆC</h4>
                        <h4>Nhập danh sách món bằng cách điền vào các ô sau (bắt buộc điền)</h4>
                    </div>
                    <div class="login-form-body">
                    <div class="form-row"  id="danh-sach-mon">
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="id_tiec">ID tiệc (không sửa):</span>
                                                </div>
                                                <input type="text" class="form-control" required="" name="id" value ="<?php echo $xuat['id_tiec'];?>" readonly aria-describedby="id_tiec">
                                            </div>
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="diachi">Địa chỉ đãi tiệc:</span>
                                                </div>
                                                <input type="text" class="form-control" required="" name="diachi" value ="<?php echo $xuat['dia_chi'];?>" aria-describedby="diachi">
                                            </div> 
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="cachlienhe">Cách thức liên hệ:</span>
                                                </div>
                                                <input type="text" class="form-control" required="" value ="<?php echo $xuat['cachlienhe'];?>" name="cachlienhe" aria-describedby="cachlienhe">
                                            </div>
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="somam">Số mâm:</span>
                                                </div>
                                                <input type="number" class="form-control" required="" value ="<?php echo $xuat['so_mam'];?>" name="somam" aria-describedby="somam">
                                            </div>
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="ghichu">Ghi chú tiệc:</span>
                                                </div>
                                                <input type="text" class="form-control" name="ghichu" aria-describedby="ghichu" value="<?php echo $xuat['ghi_chu'];?>" >
                                            </div>                                              
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="ngaydai">Ngày đãi:</span>
                                                </div>
                                                <input type="date" class="form-control" required="" value ="<?php echo date_format(new DateTime($xuat['ngay_dai']),'Y-m-d');?>" name="ngaydai" aria-describedby="ngaydai">
                                            </div>      
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="giodai">Giờ đãi:</span>
                                                </div>
                                                <input type="time" class="form-control" required="" value ="<?php echo date_format(new DateTime($xuat['gio_dai']),'H:i');?>" name="giodai" aria-describedby="giodai">
                                            </div>
                            <div class="col-md-9 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                            <span class="input-group-text" id="tenmon_1">Tên món 1:</span>
                                    </div>
                                    <input type="text" class="form-control" aria-describedby="tenmon_1" name="tenmon_1" value ="<?php echo $xuat['tenmon_1'];?>">
                                </div>
                            </div>
                            <div class="col-md-3 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="dongia_1">Đơn giá 1:</span>
                                    </div>
                                    <input type="number" class="form-control" aria-describedby="dongia_1" name="dongia_1" value ="<?php echo $xuat['dongia_1'];?>">
                                </div>
                            </div>
                            <hr/>
                            <div class="col-md-9 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                            <span class="input-group-text" id="tenmon_2">Tên món 2:</span>
                                    </div>
                                    <input type="text" class="form-control" aria-describedby="tenmon_2" name="tenmon_2" value ="<?php echo $xuat['tenmon_2'];?>">
                                </div>
                            </div>
                            <div class="col-md-3 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="dongia_2">Đơn giá 2:</span>
                                    </div>
                                    <input type="number" class="form-control" aria-describedby="dongia_2" name="dongia_2" value ="<?php echo $xuat['dongia_2'];?>">
                                </div>
                            </div>
                            <hr/>
                            <div class="col-md-9 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                            <span class="input-group-text" id="tenmon_3">Tên món 3:</span>
                                    </div>
                                    <input type="text" class="form-control" aria-describedby="tenmon_3" name="tenmon_3" value ="<?php echo $xuat['tenmon_3'];?>">
                                </div>
                            </div>
                            <div class="col-md-3 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="dongia_3">Đơn giá 3:</span>
                                    </div>
                                    <input type="number" class="form-control" aria-describedby="dongia_3" name="dongia_3" value ="<?php echo $xuat['dongia_3'];?>">
                                </div>
                            </div>
                            <hr/>
                            <div class="col-md-9 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                            <span class="input-group-text" id="tenmon_4">Tên món 4:</span>
                                    </div>
                                    <input type="text" class="form-control" aria-describedby="tenmon_4" name="tenmon_4" value ="<?php echo $xuat['tenmon_4'];?>">
                                </div>
                            </div>
                            <div class="col-md-3 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="dongia_4">Đơn giá 4:</span>
                                    </div>
                                    <input type="number" class="form-control" aria-describedby="dongia_4" name="dongia_4" value ="<?php echo $xuat['dongia_4'];?>">
                                </div>
                            </div>
                            <hr/>
                            <div class="col-md-9 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                            <span class="input-group-text" id="tenmon_5">Tên món 5:</span>
                                    </div>
                                    <input type="text" class="form-control" aria-describedby="tenmon_5" name="tenmon_5" value ="<?php echo $xuat['tenmon_5'];?>">
                                </div>
                            </div>
                            <div class="col-md-3 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="dongia_5">Đơn giá 5:</span>
                                    </div>
                                    <input type="number" class="form-control" aria-describedby="dongia_5" name="dongia_5" value ="<?php echo $xuat['dongia_5'];?>">
                                </div>
                            </div>
                            <hr/>
                            <div class="col-md-9 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                            <span class="input-group-text" id="tenmon_6">Tên món 6:</span>
                                    </div>
                                    <input type="text" class="form-control" aria-describedby="tenmon_6" name="tenmon_6" value ="<?php echo $xuat['tenmon_6'];?>">
                                </div>
                            </div>
                            <div class="col-md-3 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="dongia_6">Đơn giá 6:</span>
                                    </div>
                                    <input type="number" class="form-control" aria-describedby="dongia_6" name="dongia_6" value ="<?php echo $xuat['dongia_6'];?>"="">
                                </div>
                            </div>
                            <hr/>
                            <div class="col-md-9 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                            <span class="input-group-text" id="tenmon_7">Tên món 7:</span>
                                    </div>
                                    <input type="text" class="form-control" aria-describedby="tenmon_7" name="tenmon_7" value ="<?php echo $xuat['tenmon_7'];?>">
                                </div>
                            </div>
                            <div class="col-md-3 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="dongia_7">Đơn giá 7:</span>
                                    </div>
                                    <input type="number" class="form-control" aria-describedby="dongia_7" name="dongia_7" value ="<?php echo $xuat['dongia_7'];?>">
                                </div>
                            </div>
                            <hr/>
                            <div class="col-md-9 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                            <span class="input-group-text" id="tenmon_8">Tên món 8:</span>
                                    </div>
                                    <input type="text" class="form-control" aria-describedby="tenmon_8" name="tenmon_8" value ="<?php echo $xuat['tenmon_8'];?>">
                                </div>
                            </div>
                            <div class="col-md-3 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="dongia_8">Đơn giá 8:</span>
                                    </div>
                                    <input type="number" class="form-control" aria-describedby="dongia_8" name="dongia_8" value ="<?php echo $xuat['dongia_8'];?>">
                                </div>
                            </div>
                            <hr/>
                            <div class="col-md-9 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                            <span class="input-group-text" id="tenmon_9">Tên món 9:</span>
                                    </div>
                                    <input type="text" class="form-control" aria-describedby="tenmon_9" name="tenmon_9" value ="<?php echo $xuat['tenmon_9'];?>">
                                </div>
                            </div>
                            <div class="col-md-3 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="dongia_9">Đơn giá 9:</span>
                                    </div>
                                    <input type="number" class="form-control" aria-describedby="dongia_9" name="dongia_9" value ="<?php echo $xuat['dongia_9'];?>">
                                </div>
                            </div>
                            <hr/>
                            <div class="col-md-9 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                            <span class="input-group-text" id="tenmon_10">Tên món 10:</span>
                                    </div>
                                    <input type="text" class="form-control" aria-describedby="tenmon_10" name="tenmon_10" value ="<?php echo $xuat['tenmon_10'];?>">
                                </div>
                            </div>
                            <div class="col-md-3 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="dongia_10">Đơn giá 10:</span>
                                    </div>
                                    <input type="number" class="form-control" aria-describedby="dongia_10" name="dongia_10" value ="<?php echo $xuat['dongia_10'];?>">
                                </div>
                            </div>
                            <hr/>
                    </div>
                        <div class="submit-btn-area">
                            <button id="form_submit" type="submit">CẬP NHẬT TIỆC<i class="ti-arrow-right"></i></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- thông tin nhân viên end -->
    <?php 
    ?>
    <!-- jquery latest version -->
    <script src="assets/js/vendor/jquery-2.2.4.min.js"></script>
    <!-- bootstrap 4 js -->
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/metisMenu.min.js"></script>
    <script src="assets/js/jquery.slimscroll.min.js"></script>
    <script src="assets/js/jquery.slicknav.min.js"></script>
    
    <!-- others plugins -->
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/scripts.js"></script>
<!--Hàm thêm danh sách món-->
<script>
function Them(){
    if (i<10){
    var truoc=document.getElementById("danh-sach-mon");
    var in_o_day = document.getElementById("danh-sach-mon");
    var themvao = document.createElement('div');
    themvao.innerHTML='<div class="col-md-9 mb-3"><div class="input-group"><div class="input-group-prepend"><span class="input-group-text" id="tenmon_'+i+'">Tên món:</span></div><input type="text" class="form-control" aria-describedby="tenmon_'+i+'" name="tenmon_'+i+'" required=""></div></div><div class="col-md-3 mb-3"><div class="input-group"><div class="input-group-prepend"><span class="input-group-text" id="dongia_'+i+'">Đơn giá:</span></div><input type="number" class="form-control" aria-describedby="dongia_'+i+'" name="dongia_'+i+'" required=""></div></div><hr/>';
    // var themvao='<div class="col-md-4 mb-3"><div class="input-group"><div class="input-group-prepend"><span class="input-group-text" id="tenmon_'+i+'">Tên món:</span></div><input type="text" class="form-control" aria-describedby="tenmon_'+i+'" required=""></div></div><div class="col-md-4 mb-3"><div class="input-group"><div class="input-group-prepend"><span class="input-group-text" id="soluong_'+i+'">Số lượng:</span></div><input type="text" class="form-control" aria-describedby="soluong_'+i+'" required=""></div></div><div class="col-md-4 mb-3"><div class="input-group"><div class="input-group-prepend"><span class="input-group-text" id="dongia_'+i+'">Đơn giá:</span></div><input type="text" class="form-control" aria-describedby="dongia_'+i+'" required=""></div></div>';
    while (themvao.firstChild) {
            in_o_day.appendChild(themvao.firstChild);
    }
    i=i+1;
    }
}
</script>
<?php
            }}}};
?>
</body>

</html>