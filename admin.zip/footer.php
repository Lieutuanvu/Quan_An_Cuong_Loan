        <footer>
            <div class="footer-area">
                <p>© Quán Ăn Cường Loan - Bánh tráng phơi sương.</p>
            </div>
        </footer>