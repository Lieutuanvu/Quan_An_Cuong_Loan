<!doctype html>
<?php include_once("cosodulieu.php");

//Kiểm tra xem, nếu đăng nhập rồi thì thôi, chưa thì quay về block.php
    if (!isset($_SESSION['chuthe'])){
        header('Location: block.php');
    } 
    date_default_timezone_set('Asia/Ho_Chi_Minh');
    $thoi_gian_hientai=date('Y-m-d');
// $thoi_gian_hientai+='Y-m-d';
?>
<html class="no-js" lang="vi">
<head>
    <!--Chèn meta.php vào-->
    <?php include("meta.php"); ?>
<script>
var i=2;
</script>
</head>
<body>
    <!-- Load trước khi tải xong trang-->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!-- Load trước khi tải xong trang-->
    <!-- thông tin nhân viên start -->
    <div class="login-area">
        <div class="container">
            <div class="login">
                <form action="ghitiec.php" method="POST">
                    <div class="login-form-head">
                        <h4>GHI DANH SÁCH MÓN ĂN KHÁCH ĐẶT TIỆC</h4>
                        <h4>Nhập danh sách món bằng cách điền vào các ô sau (bắt buộc điền)</h4>
                    </div>
                    <div class="login-form-body">
                    <div class="form-row"  id="danh-sach-mon">
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="diachi">Địa chỉ đãi tiệc:</span>
                                                </div>
                                                <input type="text" class="form-control" required="" name="diachi" aria-describedby="diachi">
                                            </div> 
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="cachlienhe">Cách thức liên hệ:</span>
                                                </div>
                                                <input type="text" class="form-control" required="" name="cachlienhe" aria-describedby="cachlienhe">
                                            </div>
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="somam">Số mâm:</span>
                                                </div>
                                                <input type="number" class="form-control" required="" name="somam" aria-describedby="somam">
                                            </div>
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="ghichu">Ghi chú tiệc:</span>
                                                </div>
                                                <input type="text" class="form-control" name="ghichu" aria-describedby="ghichu">
                                            </div>                                              
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="ngaydai">Ngày đãi:</span>
                                                </div>
                                                <input type="date" class="form-control" required="" min="<?php echo $thoi_gian_hientai;?>" name="ngaydai" aria-describedby="ngaydai">
                                            </div>      
                                            <div class="input-group mb-3">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="giodai">Giờ đãi:</span>
                                                </div>
                                                <input type="time" class="form-control" required="" name="giodai" aria-describedby="giodai">
                                            </div>
                            <div class="col-md-9 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                            <span class="input-group-text" id="tenmon_1">Tên món:</span>
                                    </div>
                                    <input type="text" class="form-control" aria-describedby="tenmon_1" name="tenmon_1" required="">
                                </div>
                            </div>
                            <div class="col-md-3 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="dongia_1">Đơn giá:</span>
                                    </div>
                                    <input type="number" class="form-control" aria-describedby="dongia_1" name="dongia_1" required="">
                                </div>
                            </div>
                            <hr/>
                    </div>
                    <div class="col-md-6 mb-3">
                                <button type="button" onclick="Them()" class="btn btn-primary btn-lg btn-block">Thêm món +</button>
                    </div>
                        <div class="submit-btn-area">
                            <button id="form_submit" type="submit">GHI TIỆC<i class="ti-arrow-right"></i></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- thông tin nhân viên end -->
    <?php 
    ?>
    <!-- jquery latest version -->
    <script src="assets/js/vendor/jquery-2.2.4.min.js"></script>
    <!-- bootstrap 4 js -->
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/metisMenu.min.js"></script>
    <script src="assets/js/jquery.slimscroll.min.js"></script>
    <script src="assets/js/jquery.slicknav.min.js"></script>
    
    <!-- others plugins -->
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/scripts.js"></script>
<!--Hàm thêm danh sách món-->
<script>
function Them(){
    if (i<10){
    var truoc=document.getElementById("danh-sach-mon");
    var in_o_day = document.getElementById("danh-sach-mon");
    var themvao = document.createElement('div');
    themvao.innerHTML='<div class="col-md-9 mb-3"><div class="input-group"><div class="input-group-prepend"><span class="input-group-text" id="tenmon_'+i+'">Tên món:</span></div><input type="text" class="form-control" aria-describedby="tenmon_'+i+'" name="tenmon_'+i+'" required=""></div></div><div class="col-md-3 mb-3"><div class="input-group"><div class="input-group-prepend"><span class="input-group-text" id="dongia_'+i+'">Đơn giá:</span></div><input type="number" class="form-control" aria-describedby="dongia_'+i+'" name="dongia_'+i+'" required=""></div></div><hr/>';
    // var themvao='<div class="col-md-4 mb-3"><div class="input-group"><div class="input-group-prepend"><span class="input-group-text" id="tenmon_'+i+'">Tên món:</span></div><input type="text" class="form-control" aria-describedby="tenmon_'+i+'" required=""></div></div><div class="col-md-4 mb-3"><div class="input-group"><div class="input-group-prepend"><span class="input-group-text" id="soluong_'+i+'">Số lượng:</span></div><input type="text" class="form-control" aria-describedby="soluong_'+i+'" required=""></div></div><div class="col-md-4 mb-3"><div class="input-group"><div class="input-group-prepend"><span class="input-group-text" id="dongia_'+i+'">Đơn giá:</span></div><input type="text" class="form-control" aria-describedby="dongia_'+i+'" required=""></div></div>';
    while (themvao.firstChild) {
            in_o_day.appendChild(themvao.firstChild);
    }
    i=i+1;
    }
}
</script>
</body>

</html>