<?php
include_once("cosodulieu.php");

//Kiểm tra xem, nếu đăng nhập rồi thì thôi, chưa thì quay về block.php
if (!isset($_SESSION['chuthe'])){
    header('Location: block.php');
}

date_default_timezone_set('Asia/Ho_Chi_Minh');
$thang=date('m');
$nam=date('Y');
include_once("tao_phan_trang_ds_dat_mon.php");
$lay_du_lieu=$ketnoi->query("SELECT * FROM `dat_mon` ORDER BY `id_don` DESC LIMIT $bat_dau_hien_thi,$hien_thi");                                        

?>
<html class="no-js" lang="vi">
<head>
    <!--Chèn meta.php vào-->
    <?php include("meta.php"); ?>
</head>
<body class="body-bg">
    <!-- Load trước khi tải xong trang-->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!-- Load trước khi tải xong trang-->
    <!-- main wrapper start -->
    <div class="horizontal-main-wrapper">
        <!-- chèn mainhead.php vào đây -->
        <?php include("mainheader.php"); ?>
        <!-- chèn mainhead.php vào đây -->
        <!-- Đặt menu -->
        <?php include("menu.php");?>
        <!-- Đặt menu -->
            <div class="main-content-inner">
                <div class="row">
                    <!-- danh sách hoá đơn -->
                    <div class="col-12 mt-5">
                        <div class="card">
                            <div class="card-body">
                            <h4 class="header-title">Khách đặt món trên Website trang <?php echo $trang_hien_tai;?></h4>                            
                                <div class="single-table">
                                    <div class="table-responsive">
                                        <table class="table table-hover progress-table text-center">
                                            <thead class="text-uppercase">
                                                <tr>
                                                    <th scope="col">STT</th>
                                                    <th scope="col">Tên Khách</th>
                                                    <th scope="col">SĐT</th>
                                                    <th scope="col">Trạng thái</th>
                                                    <th scope="col">Hành động</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            <?php
                                            function trang_thai($int){
                                                if ($int == 1) return "Đã xem";
                                                if ($int == -1) return "Đã xoá";
                                                return "Chưa xem";
                                            }
                                            // $lay_du_lieu=$ketnoi->query("SELECT * FROM `dat_mon` ORDER BY `id_don` DESC");
                                            $i=0;
                                            if ($lay_du_lieu && $lay_du_lieu->num_rows>0){
                                                while($xuat=$lay_du_lieu->fetch_assoc()){
                                                    $i++;
                                                    echo '<tr id="don_'.$xuat['id_don'].'"><th scope="row">'.$i.'</th>';
                                                    echo '<th class="d-flex justify-content-center" scope="row">'.$xuat['ten_khach'].'</th>';
                                                    echo '<th scope="row">'.$xuat['sdt'].'</th>';
                                                    echo '<th scope="row" id="trang_thai_don_'.$xuat['id_don'].'">'.trang_thai($xuat['trang_thai']).'</th>';
                                                    echo '<th scope="row">                                                        
                                                            <ul class="d-flex justify-content-center">
                                                            <li class="mr-3"><button id="xem-'.$xuat['id_don'].'" data-toggle="modal" data-target="#xem-mon-khach-dat" onClick="get_ct_khach('.$xuat['id_don'].')" href="#" class="text-secondary">XEM <i class="fa fa-edit"></i></button></li>
                                                            <li><button onClick="xoa_don('.$xuat['id_don'].')" href="#" class="badge badge-danger" > XOÁ <i class="ti-trash"></i></button></li>
                                                            </ul>
                                                         </th></tr>';
                                                }
                                            }
                                            ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <!--Hiển thị phân trang-->
                            <div class="col-lg-12 col-md-6 mt-5">
                                <div class="card">
                                    <div class="card-body">
                                            <ul class="pagination justify-content-center">          
                                                <?php
                                                //In phân trang
                                                for($i=1;$i<=$so_trang;$i++){
                                                    if ($i==$trang_hien_tai){//Nếu đang ở trang đó thì vô hiệu pagination đó
                                                    echo '<li class="page-item active">';
                                                    } else{
                                                    echo '<li class="page-item">';
                                                    }
                                                    echo'<a tabindex="-1" class="page-link" href="danh-sach-dat-mon.php?trang='.$i.'">'.$i.'</a></li>';
                                                }
                                                ?>
                                            </ul>
                                        </nav>
                                    </div>
                                </div>
                            </div>
                            <!--Hiển thị phân trang-->                            
                        </div>
                        
                    </div>
                    <!-- Danh sách hoá đơn end -->
                </div>
            </div>
        </div>      
        <!-- footer area start-->
        <!-- chèn footer.php ở đây-->
        <?php include("footer.php"); ?>
        <!-- chèn footer.php ở đây-->
    </div>
<!--Đặt dinhdang.php các css, js, jquery, plugin ở đây-->
<?php include_once("dinhdang.php");?>
<div class="modal fade" id="xem-mon-khach-dat" aria-hidden="true" style="display: none;">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title">Các món Khách đặt</h5>
                                                <button type="button" class="close" data-dismiss="modal"><span>×</span></button>
                                            </div>
                                            <div class="modal-body" id="noi-dung-khach-dat">
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Đóng</button>
                                            </div>
                                        </div>
                                    </div>
</div>
<script>
//hàm lấy danh sách món ăn khách đặt
// function get_chi_tiet_khach_dat(id_don) {
//   setInterval(function(){
//    var xhttp = new XMLHttpRequest();
//    xhttp.onreadystatechange = function() {
//     if (this.readyState == 4 && this.status == 200) {
//      document.getElementById("noi-dung-khach-dat").innerHTML = id_don;//this.responseText;
//     }
//    };
//    xhttp.open("GET", "get-ds-mon-theo-don.php?id="+id_don, true);
//    xhttp.send();

//   },1000); //Khai báo từ 1000 = 1 giây trở lên để tránh bị gọi liên tục chiếm cpu
//  }
//Hàm xuất thông tin đơn
function get_ct_khach(id_don){
    document.getElementById("noi-dung-khach-dat").innerHTML="Xin chờ...";
    $("#noi-dung-khach-dat").load("get-chi-tiet-khach-dat.php?id="+id_don);
    document.getElementById("trang_thai_don_"+id_don).innerHTML="Đã xem";
    // $(document).ready(function(){
    //     $("#xem-"+id_don).click(function(){
    //         $("#noi-dung-khach-dat").load("get-chi-tiet-khach-dat.php?id="+id_don);
    //     });
    // });
    // document.getElementById("noi-dung-khach-dat").innerHTML="Xin chờ...";
    // $("#noi-dung-khach-dat").load("get-chi-tiet-khach-dat.php?id="+id_don);
}

//Hàm xoá đơn
function xoa_don(id_don){
    if(confirm("Xoá đơn này? Kiểm tra xem đã liên hệ với khách hàng chưa?") == true){
            document.getElementById("don_"+id_don).innerHTML="";
            $.get("get-chi-tiet-khach-dat.php?action=xoa&id="+id_don);
    }  
}
</script>

</body>

</html>
