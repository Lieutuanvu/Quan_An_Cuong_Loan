<!doctype html>
<?php include_once("cosodulieu.php");

//Kiểm tra xem, nếu đăng nhập rồi thì thôi, chưa thì quay về block.php
if (!isset($_SESSION['chuthe'])){
    header('Location: block.php');
} else {
 
?>
<html class="no-js" lang="en">
<head>
    <!--Chèn meta.php vào-->
    <?php include("meta.php"); ?>
</head>
<body>
    <!-- Load trước khi tải xong trang-->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!-- Load trước khi tải xong trang-->
    <!-- main wrapper start -->
    <div class="horizontal-main-wrapper">
        <!-- chèn mainhead.php vào đây -->
        <?php include("mainheader.php"); ?>
        <!-- chèn mainhead.php vào đây -->
        <!-- Đặt menu -->
        <?php include("menu.php");?>
        <!-- Đặt menu -->
            <div class="main-content-inner">
                <div class="row">
                    <!-- Danh sách nhân viên -->
                    <div class="col-12 mt-5">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="header-title">Danh sách nhân viên</h4>
                                <div class="single-table">
                                    <div class="table-responsive">
                                        <table class="table table-hover progress-table text-center">
                                            <thead class="text-uppercase">
                                                <tr>
                                                    <th scope="col">STT</th>
                                                    <th scope="col">Họ tên</th>
                                                    <th scope="col">Quê quán</th>
                                                    <!-- <th scope="col">Ngày vào</th> -->
                                                    <th scope="col">GTính</th>
                                                    <!-- <th scope="col">CMND</th>
                                                    <th scope="col">SĐT</th>
                                                    <th scope="col">Mức lương</th> -->
                                                    <th scope="col">Chi tiết</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                <?php 
                                                    $laynhanvien=$ketnoi->query("SELECT * FROM `nhanvien` WHERE `tinhtrang`='1'");
                                                    $dem=1;
                                                    if ($laynhanvien && $laynhanvien->num_rows>0){
                                                        while($in=$laynhanvien->fetch_assoc()){
                                                                echo '<tr>';
                                                                echo '<th scope="row">'.$dem.'</th>';$dem++;                                                        
                                                                echo '<td>'.$in['hoten'].'</td>';
                                                                echo '<td>'.$in['quequan'].'</td>';
                                                                // echo '<td>'.date_format(new DateTime($in['ngayvao']),'d-m-Y').'</td>';
                                                                echo '<td>'.$in['gioitinh'].'</td>';
                                                                // echo '<td>'.$in['cmnd'].'</td>';
                                                                // echo '<td>'.$in['sdt'].'</td>';
                                                                // echo '<td>'.number_format($in['mucluong']).'</td>';

                                                                // if ($_SESSION['chuthe']=="admin"){
                                                                echo '  <td>
                                                                            <ul class="d-flex justify-content-center">
                                                                               <li class="mr-3"><a href="thong-tin-nhan-vien.php?id='.$in['id'].'" class="text-secondary">Chi tiết</a></li>
                                                                            </ul>
                                                                        </td>';
                                                                // } else{
                                                                // echo '  <td>
                                                                //             <ul class="d-flex justify-content-center">
                                                                //                 <li class="mr-3">KHÔNG ĐƯỢC SỬA</li>
                                                                //             </ul>
                                                                //         </td>';
                                                                // }

                                                                echo '</tr>';
                                                        }
                                                    }
                                                ?>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <!--Ở trên là nhân viên còn làm, ở dưới là nhân viên đã nghỉ-->
                                <hr/>
                                <h4 class="header-title">Nhân viên đã nghỉ</h4>
                                <div class="single-table">
                                    <div class="table-responsive">
                                        <table class="table table-hover progress-table text-center">
                                            <thead class="text-uppercase">
                                                <tr>
                                                    <th scope="col">Họ tên</th>
                                                    <th scope="col">Quê quán</th>
                                                    <th scope="col">Giới tính</th>
                                                    <th scope="col">Chi tiết</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                <?php 
                                                    $laynhanvien=$ketnoi->query("SELECT * FROM `nhanvien` WHERE `tinhtrang`='0'");
                                                    $dem=1;
                                                    if ($laynhanvien && $laynhanvien->num_rows>0){
                                                        while($in=$laynhanvien->fetch_assoc()){
                                                                echo '<tr>';
                                                                echo '<td>'.$in['hoten'].'</td>';
                                                                echo '<td>'.$in['quequan'].'</td>';
                                                                echo '<td>'.$in['gioitinh'].'</td>';
                                                                echo '  <td>
                                                                            <ul class="d-flex justify-content-center">
                                                                               <li class="mr-3"><a href="thong-tin-nhan-vien.php?id='.$in['id'].'" class="text-secondary">Chi tiết</a></li>
                                                                            </ul>
                                                                        </td>';                                                                echo '</tr>';
                                                        }
                                                    }
                                                }
                                                ?>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Dánh sách nhân viên -->
                </div>
            </div>
        </div>
        <!-- main content area end -->
        <!-- chèn footer.php ở đây-->
        <?php include("footer.php"); ?>
        <!-- chèn footer.php ở đây-->
    </div>
    <!-- jquery latest version -->
    <script src="assets/js/vendor/jquery-2.2.4.min.js"></script>
    <!-- bootstrap 4 js -->
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/metisMenu.min.js"></script>
    <script src="assets/js/jquery.slimscroll.min.js"></script>
    <script src="assets/js/jquery.slicknav.min.js"></script>

    <!-- others plugins -->
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/scripts.js"></script>
</body>

</html>
