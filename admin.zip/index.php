<!doctype html>
<?php 
include_once("cosodulieu.php");
//Kiểm tra xem, nếu đăng nhập rồi thì thôi, chưa thì quay về block.php
if (!isset($_SESSION['chuthe'])){
    header('Location: block.php');
}

date_default_timezone_set('Asia/Ho_Chi_Minh');
$thang_nay=date('m');
$nam_nay=date('Y');
$ngay_nay=date('d');
//Lấy tổng số nhân viên
$tong_so_nv=$ketnoi->query("SELECT * FROM `nhanvien` WHERE `tinhtrang`='1'");
$tong_nv=0;$luong=0;
if ($tong_so_nv && $tong_so_nv->num_rows>0){
    $tong_nv=$tong_so_nv->num_rows;
    while($xuat=$tong_so_nv->fetch_assoc()){
        $luong+=$xuat['mucluong'];
    }
}

//Lấy tổng số hoá đơn
$tong_so_hoa_don=$ketnoi->query("SELECT * FROM `hoadon_vanchuyen` WHERE  `thang_tao`='$thang_nay' AND `nam_tao`='$nam_nay'");
$tong_hoa_don=0;
if ($tong_so_hoa_don && $tong_so_hoa_don->num_rows>0){
    $tong_hoa_don=$tong_so_hoa_don->num_rows;
}
//Lấy tổng số hoá đơn đã trả tiền    
$tong_so_hoa_don_da_tra=$ketnoi->query("SELECT * FROM `hoadon_vanchuyen` WHERE  `trang_thai`='1' AND `thang_tao`='$thang_nay' AND `nam_tao`='$nam_nay'");
$tong_hoa_don_da_tra=0;
if ($tong_so_hoa_don_da_tra && $tong_so_hoa_don_da_tra->num_rows>0){
    $tong_hoa_don_da_tra=$tong_so_hoa_don_da_tra->num_rows;
}

//Lấy tổng số tiền từ hoá đơn
$tong_so_tien_hoa_don=$ketnoi->query("SELECT `thanhtien` FROM `hoadon_vanchuyen` WHERE `trang_thai`='1' AND `thang_tao`='$thang_nay' AND `nam_tao`='$nam_nay'");
$tong_tien_hoa_don=0;
if ($tong_so_tien_hoa_don && $tong_so_tien_hoa_don->num_rows>0){
    while($tien=$tong_so_tien_hoa_don->fetch_assoc()){
        $tong_tien_hoa_don+=$tien['thanhtien'];
    }
}


//Lấy tổng số tiền từ tiệc
$tong_so_tien_tiec=$ketnoi->query("SELECT `thanhtien` FROM `mam_tiec` WHERE `tinh_trang`=1 AND `thang`='$thang_nay' AND `nam`='$nam_nay'");
$tong_tien_tiec=0;
if ($tong_so_tien_tiec && $tong_so_tien_tiec->num_rows>0){
    while($tien=$tong_so_tien_tiec->fetch_assoc()){
            $tong_tien_tiec+=$tien['thanhtien'];
    }
}

//Lấy tổng số mâm
$so_mam=0;
$tong_so_mam=$ketnoi->query("SELECT `so_mam` FROM `mam_tiec` WHERE `thang`='$thang_nay' AND `nam`='$nam_nay'");
if ($tong_so_mam && $tong_so_mam->num_rows){
    while($ts_mam=$tong_so_mam->fetch_assoc()){
        $so_mam+=$ts_mam['so_mam'];
    }
}
?>
<html class="no-js" lang="vi">
<head>
    <!--Chèn meta.php vào-->
    <?php include("meta.php"); ?>
</head>
<body class="body-bg">
    <!-- Load trước khi tải xong trang-->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!-- Load trước khi tải xong trang-->
    <!-- main wrapper start -->
    <div class="horizontal-main-wrapper">
        <!-- chèn mainhead.php vào đây -->
        <?php include("mainheader.php"); ?>
        <!-- chèn mainhead.php vào đây -->
        <!-- Đặt menu -->
        <?php include("menu.php");?>
        <!-- Đặt menu -->
        <div class="main-content-inner">
            <div class="container">
                <div class="row">
                    <!-- seo fact area start -->
                    <div class="col-lg-8">
                        <div class="row">
                            <div class="col-md-6 mt-md-5 mb-3">
                                <div class="card">
                                    <div class="seo-fact sbg4">
                                        <div class="p-4 d-flex justify-content-between align-items-center">
                                            <div class="seofct-icon">Tổng số nhân viên hiện tại</div>
                                            <h2><?php echo $tong_nv;?></h2>
                                        </div>
                                    </div>
                                </div>
                            </div>                            
                            <div class="col-md-6 mt-5 mb-3">
                                <div class="card">
                                    <div class="seo-fact sbg1">
                                        <div class="p-4 d-flex justify-content-between align-items-center">
                                            <div class="seofct-icon">Tổng mâm trong tháng</div>
                                            <h2><?php echo $so_mam;?></h2>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 mb-3 mb-lg-3">
                                <div class="card">
                                    <div class="seo-fact sbg2">
                                        <div class="p-4 d-flex justify-content-between align-items-center">
                                            <div class="seofct-icon">Tổng số hoá đơn trong tháng</div>
                                            <h2><?php echo $tong_hoa_don;?></h2>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 mb-3 mb-lg-3">
                                <div class="card">
                                    <div class="seo-fact sbg3">
                                        <div class="p-4 d-flex justify-content-between align-items-center">
                                            <div class="seofct-icon">Số hoá đơn trong tháng chưa thanh toán</div>
                                            <h2><?php echo $tong_hoa_don-$tong_hoa_don_da_tra;?></h2>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php // Nếu là admin thì hiện tổng số tiền trong tháng
                            if ($_SESSION['chuthe']=="admin"){
                            echo'
                            <div class="col-md-6 mb-3 mb-lg-0">
                                <div class="card">
                                    <div class="seo-fact sbg1">
                                        <div class="p-4 d-flex justify-content-between align-items-center">
                                            <div class="seofct-icon">Tiền từ hoá đơn trong tháng</div>
                                            <h2>'.number_format($tong_tien_hoa_don).'</h2>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 mb-3 mb-lg-0">
                                <div class="card">
                                    <div class="seo-fact sbg2">
                                        <div class="p-4 d-flex justify-content-between align-items-center">
                                            <div class="seofct-icon">Tiền từ tiệc trong tháng</div>
                                            <h2>'.number_format($tong_tien_tiec).'</h2>
                                        </div>
                                    </div>
                                </div>
                            </div>';
                            }
                            ?>

                        </div>
                    </div>
                    <!-- seo fact area end -->

                    <!-- Thống kê cửa hàng start -->
                    <?php
                    if ($_SESSION['chuthe']=="admin"){
                    echo'
                    <div class="col-lg-4 mt-5">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="header-title">Thống kê cửa hàng tháng '.$thang_nay.' năm '.$nam_nay.'</h4>
                                <canvas id="chart-thong-ke" height="233"></canvas>
                            </div>
                        </div>
                    </div>';
                    }
                    ?>
                    <!-- Thống kê cửa hàng end -->
                </div>
            </div>
        </div>
        <!-- chèn footer.php ở đây-->
        <?php include("footer.php"); ?>
        <!-- chèn footer.php ở đây-->
    </div>
<!--Đặt dinhdang.php các css, js, jquery, plugin ở đây-->
<?php include_once("dinhdang.php");?>
<!--Đặt dinhdang.php các css, js, jquery, plugin ở đây-->
    <script>
        if ($('#chart-thong-ke').length) {
            var ctx = document.getElementById("chart-thong-ke").getContext('2d');
            var chart = new Chart(ctx, {
                // The type of chart we want to create
                type: 'doughnut',
                // The data for our dataset
                data: {
                    labels: ["Trả lương", "Thu nhập"],
                    datasets: [{
                        backgroundColor: [
                            "#8919FE",
                            "#12C498",
                        ],
                        borderColor: '#fff',
                        data: [<?php echo ($luong);?>, <?php echo ($tong_tien_hoa_don+$tong_tien_tiec);?>],
                    }]
                },
                // Configuration options go here

            });
        }
    </script>
</body>

</html>
