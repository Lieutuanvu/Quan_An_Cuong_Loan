<?php
include_once("cosodulieu.php");

//Kiểm tra xem, nếu đăng nhập rồi thì thôi, chưa thì quay về block.php
if (!isset($_SESSION['chuthe'])){
    header('Location: block.php');
} else {
    if (!isset($_GET['id'])){
        header('Location: nhanvien.php');
    } else{
            // header('Location: thong-tin-nhan-vien.php?id=$id');
        $id=$_GET['id'];
        if ($ketnoi->query("DELETE FROM `nhanvien` WHERE `id`='$id'")){
            header('Location: nhanvien.php');
        }
    }
}


?>