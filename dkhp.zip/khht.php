<?php 
$trave="";
$tinchi=0;
include_once("cosodulieu.php");
$ketnoi= new mysqli($db_host,$db_user,$db_pass,$db_name);
mysqli_set_charset($ketnoi, 'UTF8');
$timkiem="";
if (isset($_SESSION['user']))
{
    $tai_khoan=$_SESSION['user'];
    $lay_id=$ketnoi->query("SELECT `ID` FROM `sinhvien` WHERE `user` ='$tai_khoan'");
    if ($lay_id && $lay_id->num_rows>0){
        while($lay_id_array=$lay_id->fetch_assoc())
        {
            $id=$lay_id_array['ID'];
        }
    } else $id="DKHP00";
        $result = $ketnoi->query("SELECT * FROM `dmhocphan`");
        if ($result && $result ->num_rows >0 )
        {   
            while ($row = $result->fetch_assoc()) {
                $mahp_timkiem=$row['mahp'];
                $lay_tai_khoan_sosanh=$ketnoi->query("SELECT * FROM `kehoachhoctap` WHERE `mahp`='$mahp_timkiem' && `ID`='$id'");
                if (mysqli_num_rows($lay_tai_khoan_sosanh)>0)
                {
                    $dangky='<th class="text-center"><button onClick="xacnhan('."'".$row['mahp']."'".')" class="btn btn-danger btn-xs" href="#"><span class="glyphicon glyphicon-edit"></span> Xoá</button></th>';
                    $trave=$trave.'<tr><th class="text-center">'.$row['mahp'].'</th><th>'.$row['tenhocphan'].'</th><th class="text-center">'.$row['tinchi'].'</th>'.$dangky.'</tr>';
                    $tinchi=$tinchi + (int)$row['tinchi'];
                } 
            }
        }
}

?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="Trang web giả lập đăng ký học phần CTU">
        <link rel="shortcut icon" href="assets/images/favicon.ico">
        <title>Danh sách - Đăng ký học phần</title>
                <!-- DataTables -->
        <link href="datatables/jquery.dataTables.min.css" rel="stylesheet" type="text/css"/>
        <link href="datatables/buttons.bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="datatables/fixedHeader.bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="datatables/responsive.bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="datatables/scroller.bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="datatables/dataTables.colVis.css" rel="stylesheet" type="text/css"/>
        <link href="datatables/dataTables.bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="datatables/fixedColumns.dataTables.min.css" rel="stylesheet" type="text/css"/>
        <link href="responsive-table/css/rwd-table.min.css" rel="stylesheet" type="text/css" media="screen">
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/core.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/components.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/pages.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/menu.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/responsive.css" rel="stylesheet" type="text/css" />
        <link href="assets/sweetalert/sweet-alert.css" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="../plugins/switchery/switchery.min.css">
        <script src="assets/js/modernizr.min.js"></script>

    </head>
    <body>


        <!-- Navigation Bar-->
        <?php include_once("menu.php") ?>

        <div class="wrapper">
            <div class="container">

                <!-- Page-Title -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-title-box">
                            <h4 class="page-title">Kế hoạch học tập</h4>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="card-box table-responsive">
                            </br></hr>
                            <div class="container">
                            <?php if (isset($_SESSION['user']))
                                    {   
                                        echo'                                
                                        <div>
                                        <table class="table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <th class="text-center">Mã học phần</th>
                                                <th class="text-center">Tên học phần</th>
                                                <th class="text-center">Số tín chỉ</th>
                                                <th class="text-center">Thực hiện</th>
                                            </tr>
                                        </thead>';
                                        echo $trave;
                                        echo'
                                        </table>
                                        </div>';
                                    }
                                    else echo '
                                    <div class="alert alert-danger alert-dismissible fade in text-center" role="alert"> Vui lòng đăng nhập để tiếp tục bạn nhé!
                                    </div>';
                                    ?>
                            </div>
                        </div>
                    </div>
                    
                </div>
                <!-- Footer -->
                <footer class="footer text-right">
                    <div class="container">
                        <div class="row">
                            <div class="col-xs-12 text-center">
                                © 2020. Lieu Tuan Vu B1906810. Có sử dụng nội dung từ trang Quản lí đào tạo CTU
                            </div>
                        </div>
                    </div>
                </footer>
                <!-- End Footer -->

            </div> <!-- end container -->
        </div>
        <!-- end wrapper -->


        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/detect.js"></script>
        <script src="assets/js/fastclick.js"></script>
        <script src="assets/js/jquery.blockUI.js"></script>
        <script src="assets/js/waves.js"></script>
        <script src="assets/js/jquery.slimscroll.js"></script>
        <script src="assets/js/jquery.scrollTo.min.js"></script>
        <script src="assets/sweetalert/sweet-alert.min.js"></script>
        <script src="switchery/switchery.min.js"></script>

        <script src="datatables/jquery.dataTables.min.js"></script>
        <script src="datatables/dataTables.bootstrap.js"></script>

        <script src="plugins/datatables/dataTables.buttons.min.js"></script>
        <script src="datatables/buttons.bootstrap.min.js"></script>
        <script src="datatables/jszip.min.js"></script>
        <script src="datatables/pdfmake.min.js"></script>
        <script src="datatables/vfs_fonts.js"></script>
        <script src="datatables/buttons.html5.min.js"></script>
        <script src="datatables/buttons.print.min.js"></script>
        <script src="datatables/dataTables.fixedHeader.min.js"></script>
        <script src="datatables/dataTables.keyTable.min.js"></script>
        <script src="datatables/dataTables.responsive.min.js"></script>
        <script src="datatables/responsive.bootstrap.min.js"></script>
        <script src="datatables/dataTables.scroller.min.js"></script>
        <script src="datatables/dataTables.colVis.js"></script>
        <script src="datatables/dataTables.fixedColumns.min.js"></script>

        <!-- init -->
        <script src="assets/pages/jquery.datatables.init.js"></script>

        <!-- App js -->
        <script src="assets/js/jquery.core.js"></script>
        <script src="assets/js/jquery.app.js"></script>

        <script type="text/javascript">
            $(document).ready(function () {
                $('#datatable').dataTable();
                $('#datatable-keytable').DataTable({keys: true});
                $('#datatable-responsive').DataTable();
                $('#datatable-colvid').DataTable({
                    "dom": 'C<"clear">lfrtip',
                    "colVis": {
                        "buttonText": "Change columns"
                    }
                });
                $('#datatable-scroller').DataTable({
                    ajax: "../plugins/datatables/json/scroller-demo.json",
                    deferRender: true,
                    scrollY: 380,
                    scrollCollapse: true,
                    scroller: true
                });
                var table = $('#datatable-fixed-header').DataTable({fixedHeader: true});
                var table = $('#datatable-fixed-col').DataTable({
                    scrollY: "300px",
                    scrollX: true,
                    scrollCollapse: true,
                    paging: false,
                    fixedColumns: {
                        leftColumns: 1,
                        rightColumns: 1
                    }
                });
            });
            TableManageButtons.init();

        </script>
    <script>
        function xacnhan(x){
            
            if(confirm("Bạn muốn xoá học phần này ra khỏi kế hoạch học tập?") == true){
                location.replace("xoamon.php?maph="+x);
            }
        }
    </script>
    </body>
</html>