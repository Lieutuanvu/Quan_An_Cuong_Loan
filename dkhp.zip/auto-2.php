<?php 
$ds_hp=[];
$tkb_lop=[];
$kyhieu_mon=[];
$mang_tong=[];///Mảng tổng để kt có bị trùng môn hay không
$mang=[];////Mảng tổng quát cho toàn bộ mỗi lớp học phần
$trich_xuat=[];///Lấy dữ liệu mỗi lớp từ csdl
$sl_lop=[];
$kyhieu=[];///Mảng lưu các ký hiệu của mỗi môn, vd: nhóm j của môn i $kyhieu[$i][$j]
$tuanhoc_lop=[];///Mảng lưu các tuần học của mỗi môn, vd: tuần học j của môn i $tuanhoc_lop[$i][$j]
$tuanhoc=[];///Mảng lưu các số loại tuần học, vd: Có $tuanhoc[$j] tuần học loại $j;
$tenhp=[];///Mảng lưu các tên của mỗi môn, vd: tên của môn i $tenhp[$i]
$lhp=[];///Ký hiệu mỗi lớp học phần
$luu_lai_tao_url=[];/// mảng lưu lại kết quả để post qua trang tạo kết quả
$mon_trung_nhieu_nhat=[];////Tìm ra môn trùng nhiều nhất để đưa ra cảnh báo		


///Hàm in bảng ////
function in_bang($mang){

					for ($i=0;$i<=8;$i++){ 
								for ($j=0;$j<=5;$j++) // biển $j là thứ trong tuần thứ 2 => j=0, thứ 3 => j=1, thứ 4 => j=2,...
								{       
									if ($mang[$i][$j]==1)
									echo $mang[$i][$j]; else echo '0';
								}
								echo '<br/>';
						}
					}

function tao_bang_hoc_phan($mang,$mahp,$kyhieu,$thu,$tietbd,$sotiet){
                $tietbd_sosanh=$tietbd-1;
				if ($thu == 2){$thu_sosanh	= 0+($tietbd_sosanh*6);}
				if ($thu == 3){$thu_sosanh	= 1+($tietbd_sosanh*6);}
				if ($thu == 4){$thu_sosanh	= 2+($tietbd_sosanh*6);}
				if ($thu == 5){$thu_sosanh	= 3+($tietbd_sosanh*6);}
				if ($thu == 6){$thu_sosanh	= 4+($tietbd_sosanh*6);}
				if ($thu == 7){$thu_sosanh	= 5+($tietbd_sosanh*6);}
				$dem=0;
				for ($i=0;$i<=53;$i++){
					if ($mang[$mahp][$kyhieu][$i]!=1) $mang[$mahp][$kyhieu][$i]=0;
					if ($i==$thu_sosanh || ($i-$thu_sosanh)==($dem*6)){
						if ($sotiet>0) 
						{
							$mang[$mahp][$kyhieu][$i]=1;
							$sotiet--;
							$dem++;
						}
					}
				}
	return $mang;
}
////////
$trave="";
$tinchi=0;
include_once("cosodulieu.php");
$ketnoi= new mysqli($db_host,$db_user,$db_pass,$db_name);
mysqli_set_charset($ketnoi, 'UTF8');
$timkiem="";
if (isset($_SESSION['user']))
{
    $tai_khoan=$_SESSION['user'];
    $lay_id=$ketnoi->query("SELECT `ID` FROM `sinhvien` WHERE `user` ='$tai_khoan'");
    if ($lay_id && $lay_id->num_rows>0){
        while($lay_id_array=$lay_id->fetch_assoc())
        {
            $id=$lay_id_array['ID'];
        }
    } else $id="DKHP00";
    //Tạo cookie để đánh dấu xem là người dùng có muốn tạo tkb với các lớp clc và ở HA hay không
    $checked="";
    if (!isset($_COOKIE['no_clc_ha'])){
        setcookie("no_clc_ha", "0", time() + (30 * 24 * 60 * 60));
    }
    if (isset($_POST['no_clc_ha'])){
        $no_clc_ha=$_POST['no_clc_ha'];
        if ($no_clc_ha==0){
            $_COOKIE['no_clc_ha']=0;
            setcookie("no_clc_ha", "0", time() + (30 * 24 * 60 * 60));
            header('Location: auto-2.php');
        } else if ($no_clc_ha==1){  ////1 là chỉ các lớp ở cơ sở 2
            if ($_COOKIE['no_clc_ha']==1){
                $_COOKIE['no_clc_ha']=0;
                setcookie("no_clc_ha", "0", time() + (30 * 24 * 60 * 60));
                header('Location: auto-2.php');
            } else {
                $_COOKIE['no_clc_ha']=1;
                setcookie("no_clc_ha", "1", time() + (30 * 24 * 60 * 60));
                header('Location: auto-2.php');
            }
        } else if ($no_clc_ha==2){  ////2 là chỉ các lớp ở HA
            if ($_COOKIE['no_clc_ha']==2){
                $_COOKIE['no_clc_ha']=0;
                setcookie("no_clc_ha", "0", time() + (30 * 24 * 60 * 60));
                header('Location: auto-2.php');
            } else {
                $_COOKIE['no_clc_ha']=2;
                setcookie("no_clc_ha", "2", time() + (30 * 24 * 60 * 60));
                header('Location: auto-2.php');
            }
        } else if ($no_clc_ha==3){  ////3 là chỉ các lớp CLC
            if ($_COOKIE['no_clc_ha']==3){
                $_COOKIE['no_clc_ha']=0;
                setcookie("no_clc_ha", "0", time() + (30 * 24 * 60 * 60));
                header('Location: auto-2.php');
            } else {
                $_COOKIE['no_clc_ha']=3;
                setcookie("no_clc_ha", "3", time() + (30 * 24 * 60 * 60));
                header('Location: auto-2.php');
            }
        }
    }
    //Tạo cookie để đánh dấu xem là người dùng có muốn tạo tkb với các lớp clc và ở HA hay không
	$trave="";
        $result = $ketnoi->query("SELECT * FROM `kehoachhoctap` WHERE `ID`='$id' ORDER BY `kehoachhoctap`.`mahp` DESC ");
     	if ($result && $result ->num_rows >0 )
        {   
			while( $in = $result->fetch_assoc()){
                $ds_hp[]=$in['mahp'];
                $hp=$in['mahp'];
                if (isset($_POST[$hp])){
                    $nhom=$_POST[$hp];
                    if ($nhom=="0"){
                        setcookie($hp, $nhom, time() - 100);
                        header('Location: auto-2.php');
                    } else {
                        setcookie($hp, $nhom, time() + (30 * 24 * 60 * 60));
                        $_COOKIE[$hp]=$nhom;
                        header('Location: auto-2.php');
                    }

                }
                if(isset($_POST["huy_ck_nhom"])){
                    setcookie($hp, "0", time() - 100);
                }
			}
        }
        if(isset($_POST["huy_ck_nhom"])){
            setcookie("no_clc_ha", "0", time() - 100);
            header('Location: auto-2.php');
        }
        $so_luong=count($ds_hp); 
}
				  
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="Trang web giả lập đăng ký học phần - Liêu Tuấn Vũ CTU">
        <link rel="shortcut icon" href="assets/images/favicon.ico">
        <title>Tự xếp thời khoá biểu</title>
                
        <link href="responsive-table/css/rwd-table.min.css" rel="stylesheet" type="text/css" media="screen">
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/core.css" rel="stylesheet" type="text/css" />
        <style type="text/css">
       .card-box {
                all: none;
                }
        .card-box {
            padding: 0px;
            border: 2px solid #f3f3f3;
            -webkit-border-radius: 5px;
            border-radius: 5px;
            -moz-border-radius: 5px;
            background-clip: padding-box;
            margin-bottom: 20px;
            background-color: #ffffff;}
        </style>
        <link href="assets/css/components.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/pages.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/menu.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/responsive.css" rel="stylesheet" type="text/css" />
        <link href="assets/sweetalert/sweet-alert.css" rel="stylesheet" type="text/css" />
        <script src="assets/js/modernizr.min.js"></script>
        

    </head>
    <body>


        <!-- Navigation Bar-->
        <?php include_once("menu.php") ?>

        <div class="wrapper">
            <div class="container">

                <!-- Page-Title -->
                
                <div class="row">
                    <div class="col-sm-12">
                        <div class="card-box table-responsive">
                            </br></hr>
                            <div class="container">
                            <?php if (isset($_SESSION['user']))
                                    {   	
											//////////////////Phần xử lí các lớp
											$n=1;
											///Đếm số lượng môn học có trong khht
                                            $so_luong=count($ds_hp);
                                            $dem_tinchi=0;
                                            for ($i=0;$i<=$so_luong-1;$i++) {
                                                $mon_trung_nhieu_nhat[$ds_hp[$i]]=0;///Khởi tạo để kiểm tra lớp bị trùng nhiều nhất ở dưới
                                                $trich_xuat[$i]=$ketnoi->query("SELECT `mahocphan`, `tenhocphan`,  `kyhieu`,`tinchi`, `thu`, `tietbd`, `sotiet`,`tuanhoc` FROM `hocphan` WHERE `mahocphan`='$ds_hp[$i]'");
                                                $lay_so_tc=$ketnoi->query("SELECT `tinchi` FROM `dmhocphan` WHERE `mahp`='$ds_hp[$i]'");
                                                if ($lay_so_tc && $lay_so_tc){
                                                    while($xuat=$lay_so_tc->fetch_assoc()){
                                                        $dem_tinchi=$dem_tinchi+$xuat['tinchi'];
                                                    }
                                                }
                                                if ($trich_xuat[$i] && $trich_xuat[$i]->num_rows>0){
                                                    $dem=-1;
                                                    while($hienthi=$trich_xuat[$i]->fetch_assoc()){
														if ($kyhieu[$i][$dem]!=$hienthi['kyhieu']){
                                                            $dem++;
                                                            $kyhieu[$i][$dem]=$hienthi['kyhieu'];
                                                            $tuanhoc_lop[$i][$dem]=$hienthi['tuanhoc'];
                                                            $tuanhoc[$hienthi['tuanhoc']]++;
                                                        }
                                                        $tenhp[$i]=$hienthi['tenhocphan'];
														$mang=tao_bang_hoc_phan($mang,$hienthi['mahocphan'],$hienthi['kyhieu'],$hienthi['thu'],$hienthi['tietbd'],$hienthi['sotiet']);
                                                        $tkb_lop[$i][$kyhieu[$i][$dem]]=$mang[$hienthi['mahocphan']][$hienthi['kyhieu']];
													}
													$sl_lop[$i]=count($kyhieu[$i]); /// Số lượng lớp của mỗi lớp học phần
                                                }
                                            }
                                            ////////
                                            //////
                                            if ($_COOKIE['no_clc_ha']==0){
                                                $solan=0;///đếm số lần gọi hàm	
                                                $so_mau=0;
                                                while($so_mau<1){
                                                    $solan++;///Tăng số lần chạy vòng while
                                                    if ($dem_tinchi>25) {
                                                            echo '
                                                            <div class="alert alert-danger alert-dismissible fade in text-center" role="alert">
                                                                Số lượng môn trong khht của bạn vượt quá 25 tín chỉ roiii, xoá bớt nha!
                                                                <br/>
                                                                '.$dem_tinchi.' tc.
                                                            </div>';
                                                        break;
                                                    }
                                                    $mang_tong[$so_mau]=[];	
                                                    $check=0;
                                                    $in_tkb=[];
                                                    $danhdau[$so_mau]=[];
                                                    if ($solan>=40000){
                                                        $trung_nhieu_nhat=$mon_trung_nhieu_nhat[$ds_hp[0]];
                                                        $in_canh_bao_mon="";
                                                        for ($i=0;$i<=$so_luong-1;$i++) {
                                                            if ($mon_trung_nhieu_nhat[$ds_hp[$i]]>$trung_nhieu_nhat){
                                                                $trung_nhieu_nhat=$mon_trung_nhieu_nhat[$ds_hp[$i]];
                                                                $in_canh_bao_mon=$ds_hp[$i];
                                                            }
                                                        }
                                                        echo '
                                                        <div class="alert alert-danger alert-dismissible fade in text-center" role="alert">
                                                            Có vẻ kế hoạch học tập của bạn rất khó xếp, bạn có thể xoá bớt một vài môn để dễ xếp hơn nhé
                                                            <br/>
                                                            Môn bị khó xếp nhất là <b>'.$in_canh_bao_mon.'</b>, bạn có thể bỏ môn này ra khỏi khht để thử lại xem sao nhé
                                                            <br/>
                                                            Hoặc bạn chỉnh sửa phần cố định nhóm lại nhé, có thể vì đó mà khó xếp tkb á
                                                            <form method="post" action="auto-2.php">
                                                                <input type="hidden" name="huy_ck_nhom" value="0">
                                                                <button onClick="this.form.submit()" type="button" class="btn btn-orange btn-rounded waves-light waves-effect w-md m-b-5">Huỷ các nhóm cố định</button>
                                                            </form>
                                                            Hoặc nhấn f5 để thử lại bạn nhe
                                                        </div>';
                                                        break;
                                                    }
                                                    for ($i=0;$i<=$so_luong-1;$i++) {
                                                        $lhp[$i]=rand(0, $sl_lop[$i]-1);
                                                        if (!isset($_COOKIE[$ds_hp[$i]]) || $_COOKIE[$ds_hp[$i]]=="0"){
                                                            $kyhieu[$i][$lhp[$i]];
                                                        } else {
                                                            //$kyhieu[$i][$lhp[$i]]=$_COOKIE[$ds_hp[$i]];
                                                            // while($kyhieu[$i][$lhp[$i]]!=$_COOKIE[$ds_hp[$i]]){
                                                            //     $lhp[$i]=rand(0, $sl_lop[$i]-1);
                                                            // }
                                                            if ($kyhieu[$i][$lhp[$i]]!=$_COOKIE[$ds_hp[$i]]){
                                                                for($t=0;$t<=$sl_lop[$i]-1;$t++){
                                                                    if ($kyhieu[$i][$t]==$_COOKIE[$ds_hp[$i]]){
                                                                        $lhp[$i]=$t;
                                                                        break;
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        for ($k=0;$k<=53;$k++){
                                                            //if ($in_tkb[$k]=="") $in_tkb[$k]='-';
                                                            $mang_tong[$so_mau][$k]=$mang_tong[$so_mau][$k]+$tkb_lop[$i][$kyhieu[$i][$lhp[$i]]][$k];
                                                            if ($tkb_lop[$i][$kyhieu[$i][$lhp[$i]]][$k]==1) $in_tkb[$k]=$ds_hp[$i];
                                                            if ($mang_tong[$so_mau][$k]>1) {
                                                                $mon_trung_nhieu_nhat[$ds_hp[$i]]++;
                                                                $check=1;
                                                                goto ketthuc0;
                                                            }
                                                        }
                                                    }
                                                    ///Nếu đã tìm ra các lớp phù hợp
                                                    if ($check==0){
                                                        $kt=0;
                                                        echo'
                                                        <div id="co-dinh-nhom" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="co-dinh-nhom" aria-hidden="true" style="display: none;">
                                                            <div class="modal-dialog">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                                        <h4 class="modal-title">Cố định nhóm các môn học</h4>
                                                                    </div>
                                                                    <div class="modal-body">';
                                                                    $checked_codinh=[];
                                                                    for ($i=0;$i<=$so_luong-1;$i++) {
                                                                        echo'
                                                                        <div class="row">
                                                                        <span class="label label-teal">Môn: '.$ds_hp[$i].' - '.$tenhp[$i].'</span>';
                                                                        if (isset($_COOKIE[$ds_hp[$i]]) && $_COOKIE[$ds_hp[$i]]!="0"){
                                                                            echo '
                                                                            <form method="post" action="auto-2.php">
                                                                                <input type="hidden" name="'.$ds_hp[$i].'" value="0">
                                                                                <button type="button" onClick="this.form.submit()" class="btn btn-xs btn-purple waves-effect waves-light">Huỷ cố định '.$ds_hp[$i].'</button>
                                                                            </form>';
                                                                        }
                                                                        echo'
                                                                            <div class="radio">';
                                                                        for ($j=0;$j<=$sl_lop[$i]-1;$j++){
                                                                            $checked_codinh[$i][$j]="";
                                                                            if ($_COOKIE[$ds_hp[$i]]==$kyhieu[$i][$j]){
                                                                                $checked_codinh[$i][$j]="checked";
                                                                                $hien_form=0;
                                                                            } else {
                                                                                $hien_form=$kyhieu[$i][$j];
                                                                            }
                                                                            echo'
                                                                            <div class="col-md-3">
                                                                                <form method="post" action="auto-2.php">
                                                                                    <input onChange="this.form.submit()" type="radio" '.$checked_codinh[$i][$j].' name="'.$ds_hp[$i].'" id="'.$i.$j.'" value="'.$hien_form.'">
                                                                                    <label for="'.$i.$j.'">
                                                                                        Nhóm '.$kyhieu[$i][$j].'
                                                                                    </label>
                                                                                </form>
                                                                            </div>';
                                                                            //echo '<span class="label label-purple">'.$ds_hp[$i].' nhóm '.$kyhieu[$i][$j].'</span><br/>';
                                                                        }
                                                                        echo'
                                                                            </div>
                                                                        </div>';
                                                                    }
                                                        echo'
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="button" class="btn btn-default waves-effect" data-dismiss="modal">Đóng</button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>';
                                                        for ($i=0;$i<=$so_luong-1;$i++) {
                                                            $tao_url_tenhp[$i]=($ds_hp[$i]);
                                                            $tao_url_kyhieuhp[$i]=($kyhieu[$i][$lhp[$i]]);
                                                            echo '<span class="label label-purple">'.$ds_hp[$i].' nhóm '.$kyhieu[$i][$lhp[$i]].'</span>';
                                                        }
                                                        $data_post1=serialize($tao_url_tenhp);
                                                        $data_post2=serialize($tao_url_kyhieuhp);
                                                        echo'
                                                        <table class="table table-bordered m-0">
                                                            <thead>
                                                                <tr>
                                                                    <th class="text-center">Tiết</th>
                                                                    <th class="text-center">Thứ 2</th>
                                                                    <th class="text-center">Thứ 3</th>
                                                                    <th class="text-center">Thứ 4</th>
                                                                    <th class="text-center">Thứ 5</th>
                                                                    <th class="text-center">Thứ 6</th>
                                                                    <th class="text-center">Thứ 7</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <tr>
                                                                    <th class="text-center" scope="row">1</th>';
                                                                    for ($k=0;$k<=5;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                                                    }
                                                        echo   '</tr>
                                                                <tr>
                                                                    <th class="text-center" scope="row">2</th>';
                                                                    for ($k=6;$k<=11;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                                                    }
                                                        echo   '</tr>
                                                                <tr>
                                                                    <th class="text-center" scope="row">3</th>';
                                                                    for ($k=12;$k<=17;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                                                    }
                                                        echo   '</tr>
                                                                <tr>
                                                                    <th class="text-center" scope="row">4</th>';
                                                                    for ($k=18;$k<=23;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                                                    }
                                                        echo   '</tr>
                                                                <tr>
                                                                    <th class="text-center" scope="row">5</th>';       
                                                                    for ($k=24;$k<=29;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                                                    }  
                                                        echo   '</tr>
                                                                <tr>
                                                                    <th class="text-center" scope="row">6</th>';
                                                                    for ($k=30;$k<=35;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                                                    }
                                                        echo   '</tr>
                                                                <tr>
                                                                    <th class="text-center" scope="row">7</th>';    
                                                                    for ($k=36;$k<=41;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                                                    }   
                                                        echo   '</tr>
                                                                <tr>
                                                                    <th class="text-center" scope="row">8</th>';    
                                                                    for ($k=42;$k<=47;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                                                    }    
                                                        echo   '</tr>
                                                                <tr>
                                                                    <th class="text-center" scope="row">9</th>';  
                                                                    for ($k=48;$k<=53;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                                                    } 
                                                        echo   '</tr>                                       
                                                            </tbody>
                                                        </table>';
                                                        echo '<hr/>';
                                                        $data_post1=str_replace('"',"'",$data_post1);
                                                        $data_post2=str_replace('"',"'",$data_post2);
                                                        //echo'
                                                    // <a href="auto-2.php" type="button" class="btn btn-success btn-rounded w-md waves-effect waves-light m-b-5">Xếp lại</a>';                                                    
                                                        echo'
                                                        <div class="row">
                                                            <div class="col-md-4">
                                                                <div class="checkbox checkbox-danger checkbox-circle">
                                                                    <form method="post" action="auto-2.php">
                                                                        <input type="hidden" name="no_clc_ha" value="1" >
                                                                        <input id="no_clc_ha1" type="checkbox" onChange="this.form.submit()">
                                                                        <label for="no_clc_ha1">
                                                                            Không xếp vào lớp CLC, Hoà An và Khoá dưới
                                                                        </label>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-3">
                                                                <div class="checkbox checkbox-danger checkbox-circle">
                                                                <form method="post" action="auto-2.php">
                                                                    <input type="hidden" name="no_clc_ha" value="2" >
                                                                    <input id="no_clc_ha2" type="checkbox" onChange="this.form.submit()">
                                                                    <label for="no_clc_ha2">
                                                                        Chỉ xếp các lớp ở Hoà An
                                                                    </label>
                                                                </form>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-3">
                                                                <div class="checkbox checkbox-danger checkbox-circle">
                                                                <form method="post" action="auto-2.php">
                                                                    <input type="hidden" name="no_clc_ha" value="3" >
                                                                    <input id="no_clc_ha3" type="checkbox" onChange="this.form.submit()">
                                                                    <label for="no_clc_ha3">
                                                                        Chỉ xếp các lớp CLC
                                                                    </label>
                                                                </form>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <form method="post" action="luu-tkb.php">
                                                        <input type="hidden" name="ten" value="'.$data_post1.'">
                                                        <input type="hidden" name="kyhieu" value="'.$data_post2.'">
                                                        <button type="button" onClick="window.location.reload()" class="btn btn-success btn-rounded w-md waves-effect waves-light m-b-5">Xếp lại</button>
                                                        <button type="submit" value="submit" class="btn btn-primary btn-rounded w-md waves-effect waves-light m-b-5">Lưu lại</button>
                                                        <button type="button" data-toggle="modal" data-target="#co-dinh-nhom" class="btn btn-orange btn-rounded waves-light waves-effect w-md m-b-5">Cố định nhóm</button>
                                                        </form>
                                                        <form method="post" action="auto-2.php">
                                                            <input type="hidden" name="huy_ck_nhom" value="0">
                                                            <button onClick="this.form.submit()" type="button" class="btn btn-danger btn-rounded waves-light waves-effect w-md m-b-5">Huỷ các nhóm cố định</button>
                                                        </form>    
                                                        ';
                                                        
                                                        
                                                        $so_mau=1;
                                                    }
                                                    ketthuc0: if ($check==1){
                                                        $so_mau=0;
                                                    }
                                                }
                                                
                                            }
                                            if ($_COOKIE['no_clc_ha']==1){
                                                $solan=0;///đếm số lần gọi hàm	
                                                $so_mau=0;
                                                while($so_mau<1){
                                                    $solan++;///Tăng số lần chạy vòng while
                                                    if ($dem_tinchi>25) {
                                                            echo '
                                                            <div class="alert alert-danger alert-dismissible fade in text-center" role="alert">
                                                                Số lượng môn trong khht của bạn vượt quá 25 tín chỉ roiii, xoá bớt nha!
                                                                <br/>
                                                                '.$dem_tinchi.' tc.
                                                            </div>';
                                                        break;
                                                    }
                                                    $mang_tong[$so_mau]=[];	
                                                    $check=0;
                                                    $in_tkb=[];
                                                    $danhdau[$so_mau]=[];
                                                    if ($solan>=40000){
                                                        $trung_nhieu_nhat=$mon_trung_nhieu_nhat[$ds_hp[0]];
                                                        $in_canh_bao_mon="";
                                                        for ($i=0;$i<=$so_luong-1;$i++) {
                                                            if ($mon_trung_nhieu_nhat[$ds_hp[$i]]>$trung_nhieu_nhat){
                                                                $trung_nhieu_nhat=$mon_trung_nhieu_nhat[$ds_hp[$i]];
                                                                $in_canh_bao_mon=$ds_hp[$i];
                                                            }
                                                        }
                                                        echo '
                                                        <div class="alert alert-danger alert-dismissible fade in text-center" role="alert">
                                                            Có vẻ kế hoạch học tập của bạn rất khó xếp, bạn có thể xoá bớt một vài môn để dễ xếp hơn nhé
                                                            <br/>
                                                            Môn bị khó xếp nhất là <b>'.$in_canh_bao_mon.'</b>, bạn có thể bỏ môn này ra khỏi khht để thử lại xem sao nhé
                                                            <br/>
                                                            Hoặc bạn chỉnh sửa phần cố định nhóm lại nhé, có thể vì đó mà khó xếp tkb á
                                                            <form method="post" action="auto-2.php">
                                                                <input type="hidden" name="huy_ck_nhom" value="0">
                                                                <button onClick="this.form.submit()" type="button" class="btn btn-orange btn-rounded waves-light waves-effect w-md m-b-5">Huỷ các nhóm cố định</button>
                                                            </form>
                                                            Hoặc nhấn f5 để thử lại bạn nhe
                                                        </div>';
                                                        break;
                                                    }
                                                    for ($i=0;$i<=$so_luong-1;$i++) {
                                                        $lhp[$i]=rand(0, $sl_lop[$i]-1);
                                                        if (!isset($_COOKIE[$ds_hp[$i]]) || $_COOKIE[$ds_hp[$i]]=="0"){
                                                            $kyhieu[$i][$lhp[$i]];
                                                        } else {
                                                            //$kyhieu[$i][$lhp[$i]]=$_COOKIE[$ds_hp[$i]];
                                                            // while($kyhieu[$i][$lhp[$i]]!=$_COOKIE[$ds_hp[$i]]){
                                                            //     $lhp[$i]=rand(0, $sl_lop[$i]-1);
                                                            // }
                                                            if ($kyhieu[$i][$lhp[$i]]!=$_COOKIE[$ds_hp[$i]]){
                                                                for($t=0;$t<=$sl_lop[$i]-1;$t++){
                                                                    if ($kyhieu[$i][$t]==$_COOKIE[$ds_hp[$i]]){
                                                                        $lhp[$i]=$t;
                                                                        break;
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        if (strlen($kyhieu[$i][$lhp[$i]])>=3 || $ds_hp[$i][strlen($ds_hp[$i])-1]=="H"){
                                                            $check=1;
                                                            goto ketthuc1;
                                                        }
                                                        for ($k=0;$k<=53;$k++){
                                                            $mang_tong[$so_mau][$k]=$mang_tong[$so_mau][$k]+$tkb_lop[$i][$kyhieu[$i][$lhp[$i]]][$k];
                                                            if ($tkb_lop[$i][$kyhieu[$i][$lhp[$i]]][$k]==1) $in_tkb[$k]=$ds_hp[$i];
                                                            if ($mang_tong[$so_mau][$k]>1) {
                                                                $mon_trung_nhieu_nhat[$ds_hp[$i]]++;
                                                                $check=1;
                                                                goto ketthuc1;
                                                            }
                                                        }
                                                    }
                                                    ///Nếu đã tìm ra các lớp phù hợp
                                                    if ($check==0){
                                                        $kt=0;
                                                        echo'
                                                        <div id="co-dinh-nhom" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="co-dinh-nhom" aria-hidden="true" style="display: none;">
                                                            <div class="modal-dialog">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                                        <h4 class="modal-title">Cố định nhóm các môn học</h4>
                                                                    </div>
                                                                    <div class="modal-body">';
                                                                    $checked_codinh=[];
                                                                    for ($i=0;$i<=$so_luong-1;$i++) {
                                                                        echo'
                                                                        <div class="row">
                                                                        <span class="label label-teal">Môn: '.$ds_hp[$i].' - '.$tenhp[$i].'</span>';
                                                                        if (isset($_COOKIE[$ds_hp[$i]]) && $_COOKIE[$ds_hp[$i]]!="0"){
                                                                            echo '
                                                                            <form method="post" action="auto-2.php">
                                                                                <input type="hidden" name="'.$ds_hp[$i].'" value="0">
                                                                                <button type="button" onClick="this.form.submit()" class="btn btn-xs btn-purple waves-effect waves-light">Huỷ cố định '.$ds_hp[$i].'</button>
                                                                            </form>';
                                                                        }
                                                                        echo'
                                                                            <div class="radio">';
                                                                        for ($j=0;$j<=$sl_lop[$i]-1;$j++){
                                                                            $checked_codinh[$i][$j]="";
                                                                            if ($_COOKIE[$ds_hp[$i]]==$kyhieu[$i][$j]){
                                                                                $checked_codinh[$i][$j]="checked";
                                                                                $hien_form=0;
                                                                            } else {
                                                                                $hien_form=$kyhieu[$i][$j];
                                                                            }
                                                                            echo'
                                                                            <div class="col-md-3">
                                                                                <form method="post" action="auto-2.php">
                                                                                    <input onChange="this.form.submit()" type="radio" '.$checked_codinh[$i][$j].' name="'.$ds_hp[$i].'" id="'.$i.$j.'" value="'.$hien_form.'">
                                                                                    <label for="'.$i.$j.'">
                                                                                        Nhóm '.$kyhieu[$i][$j].'
                                                                                    </label>
                                                                                </form>
                                                                            </div>';
                                                                            //echo '<span class="label label-purple">'.$ds_hp[$i].' nhóm '.$kyhieu[$i][$j].'</span><br/>';
                                                                        }
                                                                        echo'
                                                                            </div>
                                                                        </div>';
                                                                    }
                                                        echo'
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="button" class="btn btn-default waves-effect" data-dismiss="modal">Đóng</button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>';
                                                        for ($i=0;$i<=$so_luong-1;$i++) {
                                                            $tao_url_tenhp[$i]=($ds_hp[$i]);
                                                            $tao_url_kyhieuhp[$i]=($kyhieu[$i][$lhp[$i]]);
                                                            echo '<span class="label label-purple">'.$ds_hp[$i].' nhóm '.$kyhieu[$i][$lhp[$i]].'</span>';
                                                        }
                                                        $data_post1=serialize($tao_url_tenhp);
                                                        $data_post2=serialize($tao_url_kyhieuhp);
                                                        echo'
                                                        <table class="table table-bordered m-0">
                                                            <thead>
                                                                <tr>
                                                                    <th class="text-center">Tiết</th>
                                                                    <th class="text-center">Thứ 2</th>
                                                                    <th class="text-center">Thứ 3</th>
                                                                    <th class="text-center">Thứ 4</th>
                                                                    <th class="text-center">Thứ 5</th>
                                                                    <th class="text-center">Thứ 6</th>
                                                                    <th class="text-center">Thứ 7</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <tr>
                                                                    <th class="text-center" scope="row">1</th>';
                                                                    for ($k=0;$k<=5;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                                                    }
                                                        echo   '</tr>
                                                                <tr>
                                                                    <th class="text-center" scope="row">2</th>';
                                                                    for ($k=6;$k<=11;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                                                    }
                                                        echo   '</tr>
                                                                <tr>
                                                                    <th class="text-center" scope="row">3</th>';
                                                                    for ($k=12;$k<=17;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                                                    }
                                                        echo   '</tr>
                                                                <tr>
                                                                    <th class="text-center" scope="row">4</th>';
                                                                    for ($k=18;$k<=23;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                                                    }
                                                        echo   '</tr>
                                                                <tr>
                                                                    <th class="text-center" scope="row">5</th>';       
                                                                    for ($k=24;$k<=29;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                                                    }  
                                                        echo   '</tr>
                                                                <tr>
                                                                    <th class="text-center" scope="row">6</th>';
                                                                    for ($k=30;$k<=35;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                                                    }
                                                        echo   '</tr>
                                                                <tr>
                                                                    <th class="text-center" scope="row">7</th>';    
                                                                    for ($k=36;$k<=41;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                                                    }   
                                                        echo   '</tr>
                                                                <tr>
                                                                    <th class="text-center" scope="row">8</th>';    
                                                                    for ($k=42;$k<=47;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                                                    }    
                                                        echo   '</tr>
                                                                <tr>
                                                                    <th class="text-center" scope="row">9</th>';  
                                                                    for ($k=48;$k<=53;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                                                    } 
                                                        echo   '</tr>                                       
                                                            </tbody>
                                                        </table>';
                                                        echo '<hr/>';
                                                        $data_post1=str_replace('"',"'",$data_post1);
                                                        $data_post2=str_replace('"',"'",$data_post2);
                                                        //echo'
                                                    // <a href="auto-2.php" type="button" class="btn btn-success btn-rounded w-md waves-effect waves-light m-b-5">Xếp lại</a>';                                                    
                                                        echo'
                                                        <div class="row">
                                                            <div class="col-md-4">
                                                                <div class="checkbox checkbox-danger checkbox-circle">
                                                                    <form method="post" action="auto-2.php">
                                                                        <input type="hidden" name="no_clc_ha" value="1" >
                                                                        <input id="no_clc_ha1" type="checkbox" onChange="this.form.submit()" checked >
                                                                        <label for="no_clc_ha1">
                                                                            Không xếp vào lớp CLC, Hoà An và Khoá dưới
                                                                        </label>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-3">
                                                                <div class="checkbox checkbox-danger checkbox-circle">
                                                                <form method="post" action="auto-2.php">
                                                                    <input type="hidden" name="no_clc_ha" value="2" >
                                                                    <input id="no_clc_ha2" type="checkbox" onChange="this.form.submit()">
                                                                    <label for="no_clc_ha2">
                                                                        Chỉ xếp các lớp ở Hoà An
                                                                    </label>
                                                                </form>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-3">
                                                                <div class="checkbox checkbox-danger checkbox-circle">
                                                                <form method="post" action="auto-2.php">
                                                                    <input type="hidden" name="no_clc_ha" value="3" >
                                                                    <input id="no_clc_ha3" type="checkbox" onChange="this.form.submit()">
                                                                    <label for="no_clc_ha3">
                                                                        Chỉ xếp các lớp CLC
                                                                    </label>
                                                                </form>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <form method="post" action="luu-tkb.php">
                                                        <input type="hidden" name="ten" value="'.$data_post1.'">
                                                        <input type="hidden" name="kyhieu" value="'.$data_post2.'">
                                                        <button type="button" onClick="window.location.reload()" class="btn btn-success btn-rounded w-md waves-effect waves-light m-b-5">Xếp lại</button>
                                                        <button type="submit" value="submit" class="btn btn-primary btn-rounded w-md waves-effect waves-light m-b-5">Lưu lại</button>
                                                        <button type="button" data-toggle="modal" data-target="#co-dinh-nhom" class="btn btn-orange btn-rounded waves-light waves-effect w-md m-b-5">Cố định nhóm</button>
                                                        </form>
                                                        <form method="post" action="auto-2.php">
                                                            <input type="hidden" name="huy_ck_nhom" value="0">
                                                            <button onClick="this.form.submit()" type="button" class="btn btn-danger btn-rounded waves-light waves-effect w-md m-b-5">Huỷ các nhóm cố định</button>
                                                        </form>    
                                                        ';
                                                        
                                                        
                                                        $so_mau=1;
                                                    }
                                                    ketthuc1: if ($check==1){
                                                        $so_mau=0;
                                                    }
                                                }
                                                
                                            }
                                            if ($_COOKIE['no_clc_ha']==2){
                                                $solan=0;///đếm số lần gọi hàm	
                                                $so_mau=0;
                                                while($so_mau<1){
                                                    $solan++;///Tăng số lần chạy vòng while
                                                    if ($dem_tinchi>25) {
                                                            echo '
                                                            <div class="alert alert-danger alert-dismissible fade in text-center" role="alert">
                                                                Số lượng môn trong khht của bạn vượt quá 25 tín chỉ roiii, xoá bớt nha!
                                                                <br/>
                                                                '.$dem_tinchi.' tc.
                                                            </div>';
                                                        break;
                                                    }
                                                    $mang_tong1[$so_mau]=[];	
                                                    $mang_tong2[$so_mau]=[];	
                                                    $mang_tong3[$so_mau]=[];	
                                                    $check=0;
                                                    $in_tkb1=[];
                                                    $in_tkb2=[];
                                                    $in_tkb3=[];
                                                    $danhdau[$so_mau]=[];
                                                    if ($solan>=40000){
                                                        $trung_nhieu_nhat=$mon_trung_nhieu_nhat[$ds_hp[0]];
                                                        $in_canh_bao_mon="";
                                                        for ($i=0;$i<=$so_luong-1;$i++) {
                                                            if ($mon_trung_nhieu_nhat[$ds_hp[$i]]>$trung_nhieu_nhat){
                                                                $trung_nhieu_nhat=$mon_trung_nhieu_nhat[$ds_hp[$i]];
                                                                $in_canh_bao_mon=$ds_hp[$i];
                                                            }
                                                        }
                                                        echo '
                                                        <div class="alert alert-danger alert-dismissible fade in text-center" role="alert">
                                                            Có vẻ kế hoạch học tập của bạn rất khó xếp, bạn có thể xoá bớt một vài môn để dễ xếp hơn nhé
                                                            <br/>
                                                            Môn bị khó xếp nhất là <b>'.$in_canh_bao_mon.'</b>, bạn có thể bỏ môn này ra khỏi khht để thử lại xem sao nhé
                                                            <br/>
                                                            Hoặc bạn chỉnh sửa phần cố định nhóm lại nhé, có thể vì đó mà khó xếp tkb á
                                                            <form method="post" action="auto-2.php">
                                                                <input type="hidden" name="huy_ck_nhom" value="0">
                                                                <button onClick="this.form.submit()" type="button" class="btn btn-orange btn-rounded waves-light waves-effect w-md m-b-5">Huỷ các nhóm cố định</button>
                                                            </form>
                                                            Hoặc nhấn f5 để thử lại bạn nhe
                                                        </div>';
                                                        break;
                                                    }
                                                    for ($i=0;$i<=$so_luong-1;$i++) {
                                                        $lhp[$i]=rand(0, $sl_lop[$i]-1);
                                                        ///Kiểm tra xem có lớp nào ở HA hay không, nếu không thì break, đưa ra thông báo
                                                        $kt_co_lop_HA=0;
                                                        $kt_lop_cuoi_HA=0;
                                                        for ($t=0;$t<=$sl_lop[$i]-1;$t++){
                                                            $len=strlen($kyhieu[$i][$t]);
                                                            $pos=strpos($kyhieu[$i][$t],'H');
                                                            if(($pos!==FALSE) && $len>=3){
                                                                $kt_lop_cuoi_HA=$t;
                                                                $kt_co_lop_HA++;
                                                            }
                                                        }
                                                        if ($kt_co_lop_HA==0){
                                                                        echo '
                                                                        <div class="alert alert-danger alert-dismissible fade in text-center" role="alert">
                                                                            Có vẻ kế hoạch học tập của bạn rất khó xếp, bạn có thể xoá bớt một vài môn để dễ xếp hơn nhé
                                                                            <br/>
                                                                            Môn bị khó xếp nhất là <b>'.$ds_hp[$i].'</b>, vì ở Hoà An hông có lịch môn này á, bạn có thể bỏ môn này ra khỏi khht để thử lại xem sao nhé
                                                                            <br/>
                                                                            Hoặc bạn chỉnh sửa phần cố định nhóm lại nhé, có thể vì đó mà khó xếp tkb á
                                                                            <form method="post" action="auto-2.php">
                                                                                <input type="hidden" name="huy_ck_nhom" value="0">
                                                                                <button onClick="this.form.submit()" type="button" class="btn btn-orange btn-rounded waves-light waves-effect w-md m-b-5">Huỷ các nhóm cố định</button>
                                                                            </form>
                                                                            Hoặc nhấn f5 để thử lại bạn nhe
                                                                        </div>';
                                                                        goto khongcolop;
                                                                        break;
                                                        }
                                                        ///Kiểm tra xem có cố định nhóm hay không
                                                        if (!isset($_COOKIE[$ds_hp[$i]]) || $_COOKIE[$ds_hp[$i]]=="0"){
                                                            $kyhieu[$i][$lhp[$i]];
                                                        } else {
                                                            if ($kyhieu[$i][$lhp[$i]]!=$_COOKIE[$ds_hp[$i]]){
                                                                for($t=0;$t<=$sl_lop[$i]-1;$t++){
                                                                    if ($kyhieu[$i][$t]==$_COOKIE[$ds_hp[$i]]){
                                                                        $lhp[$i]=$t;
                                                                        break;
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        ////Kiểm tra xem nhóm đã random có phải là nhóm ở HA hay không
                                                         $pos=strpos($kyhieu[$i][$lhp[$i]],'H');
                                                        if ($pos===FALSE){
                                                                $timra=0;
                                                                while($timra==0){
                                                                    $lhp[$i]=rand($kt_lop_cuoi_HA-$kt_co_lop_HA, $kt_lop_cuoi_HA);
                                                                    $pos=strpos($kyhieu[$i][$lhp[$i]],'H');
                                                                    if ($pos!==FALSE){
                                                                        $timra=1;
                                                                        break;
                                                                    }
                                                                }
                                                        }
                                                        ///Tạo thời khoá biểu
                                                        if ($tuanhoc_lop[$i][$lhp[$i]]=="12345678************"){
                                                            for ($k=0;$k<=53;$k++){
                                                                $mang_tong1[$so_mau][$k]=$mang_tong1[$so_mau][$k]+$tkb_lop[$i][$kyhieu[$i][$lhp[$i]]][$k];
                                                                if ($tkb_lop[$i][$kyhieu[$i][$lhp[$i]]][$k]==1) $in_tkb1[$k]=$ds_hp[$i];
                                                                if ($mang_tong1[$so_mau][$k]>1) {
                                                                    $mon_trung_nhieu_nhat[$ds_hp[$i]]++;
                                                                    $check=1;
                                                                    goto ketthuc2;
                                                                }
                                                            }
                                                        }
                                                        if ($tuanhoc_lop[$i][$lhp[$i]]=="********9012345*****"){
                                                            for ($k=0;$k<=53;$k++){
                                                                $mang_tong2[$so_mau][$k]=$mang_tong2[$so_mau][$k]+$tkb_lop[$i][$kyhieu[$i][$lhp[$i]]][$k];
                                                                if ($tkb_lop[$i][$kyhieu[$i][$lhp[$i]]][$k]==1) $in_tkb2[$k]=$ds_hp[$i];
                                                                if ($mang_tong2[$so_mau][$k]>1) {
                                                                    $mon_trung_nhieu_nhat[$ds_hp[$i]]++;
                                                                    $check=1;
                                                                    goto ketthuc2;
                                                                }
                                                            }
                                                        }
                                                        if ($tuanhoc_lop[$i][$lhp[$i]]=="123456789012345*****"){
                                                            for ($k=0;$k<=53;$k++){
                                                                $mang_tong3[$so_mau][$k]=$mang_tong3[$so_mau][$k]+$tkb_lop[$i][$kyhieu[$i][$lhp[$i]]][$k];
                                                                if ($tkb_lop[$i][$kyhieu[$i][$lhp[$i]]][$k]==1) $in_tkb3[$k]=$ds_hp[$i];
                                                                if ($mang_tong3[$so_mau][$k]>1) {
                                                                    $mon_trung_nhieu_nhat[$ds_hp[$i]]++;
                                                                    $check=1;
                                                                    goto ketthuc2;
                                                                }
                                                                if (($mang_tong3[$so_mau][$k]+$mang_tong1[$so_mau][$k])>1) {
                                                                    $mon_trung_nhieu_nhat[$ds_hp[$i]]++;
                                                                    $check=1;
                                                                    goto ketthuc2;
                                                                }
                                                                if (($mang_tong3[$so_mau][$k]+$mang_tong2[$so_mau][$k])>1) {
                                                                    $mon_trung_nhieu_nhat[$ds_hp[$i]]++;
                                                                    $check=1;
                                                                    goto ketthuc2;
                                                                }
                                                                
                                                            }
                                                        }
                                                        
                                                    }
                                                    ///Nếu đã tìm ra các lớp phù hợp
                                                    if ($check==0){
                                                        $kt=0;
                                                        echo'
                                                        <div id="co-dinh-nhom" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="co-dinh-nhom" aria-hidden="true" style="display: none;">
                                                            <div class="modal-dialog">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                                        <h4 class="modal-title">Cố định nhóm các môn học</h4>
                                                                    </div>
                                                                    <div class="modal-body">';
                                                                    $checked_codinh=[];
                                                                    for ($i=0;$i<=$so_luong-1;$i++) {
                                                                        echo'
                                                                        <div class="row">
                                                                        <span class="label label-teal">Môn: '.$ds_hp[$i].' - '.$tenhp[$i].'</span>';
                                                                        if (isset($_COOKIE[$ds_hp[$i]]) && $_COOKIE[$ds_hp[$i]]!="0"){
                                                                            echo '
                                                                            <form method="post" action="auto-2.php">
                                                                                <input type="hidden" name="'.$ds_hp[$i].'" value="0">
                                                                                <button type="button" onClick="this.form.submit()" class="btn btn-xs btn-purple waves-effect waves-light">Huỷ cố định '.$ds_hp[$i].'</button>
                                                                            </form>';
                                                                        }
                                                                        echo'
                                                                            <div class="radio">';
                                                                        for ($j=0;$j<=$sl_lop[$i]-1;$j++){
                                                                            $checked_codinh[$i][$j]="";
                                                                            if ($_COOKIE[$ds_hp[$i]]==$kyhieu[$i][$j]){
                                                                                $checked_codinh[$i][$j]="checked";
                                                                                $hien_form=0;
                                                                            } else {
                                                                                $hien_form=$kyhieu[$i][$j];
                                                                            }
                                                                            echo'
                                                                            <div class="col-md-3">
                                                                                <form method="post" action="auto-2.php">
                                                                                    <input onChange="this.form.submit()" type="radio" '.$checked_codinh[$i][$j].' name="'.$ds_hp[$i].'" id="'.$i.$j.'" value="'.$hien_form.'">
                                                                                    <label for="'.$i.$j.'">
                                                                                        Nhóm '.$kyhieu[$i][$j].'
                                                                                    </label>
                                                                                </form>
                                                                            </div>';
                                                                            //echo '<span class="label label-purple">'.$ds_hp[$i].' nhóm '.$kyhieu[$i][$j].'</span><br/>';
                                                                        }
                                                                        echo'
                                                                            </div>
                                                                        </div>';
                                                                    }
                                                        echo'
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="button" class="btn btn-default waves-effect" data-dismiss="modal">Đóng</button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>';
                                                        for ($i=0;$i<=$so_luong-1;$i++) {
                                                            $tao_url_tenhp[$i]=($ds_hp[$i]);
                                                            $tao_url_kyhieuhp[$i]=($kyhieu[$i][$lhp[$i]]);
                                                            echo '<span class="label label-purple">'.$ds_hp[$i].' nhóm '.$kyhieu[$i][$lhp[$i]].'</span>';
                                                        }
                                                        $data_post1=serialize($tao_url_tenhp);
                                                        $data_post2=serialize($tao_url_kyhieuhp);
                                                        ///Tuần học loại 1
                                                        echo'
                                                        <span class="label label-orange">Tuần học 12345678************</span>
                                                        <table class="table table-bordered m-0">
                                                            <thead>
                                                                <tr>
                                                                    <th class="text-center">Tiết</th>
                                                                    <th class="text-center">Thứ 2</th>
                                                                    <th class="text-center">Thứ 3</th>
                                                                    <th class="text-center">Thứ 4</th>
                                                                    <th class="text-center">Thứ 5</th>
                                                                    <th class="text-center">Thứ 6</th>
                                                                    <th class="text-center">Thứ 7</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <tr>
                                                                    <th class="text-center" scope="row">1</th>';
                                                                    for ($k=0;$k<=5;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb1[$k].'</td>';
                                                                    }
                                                        echo   '</tr>
                                                                <tr>
                                                                    <th class="text-center" scope="row">2</th>';
                                                                    for ($k=6;$k<=11;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb1[$k].'</td>';
                                                                    }
                                                        echo   '</tr>
                                                                <tr>
                                                                    <th class="text-center" scope="row">3</th>';
                                                                    for ($k=12;$k<=17;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb1[$k].'</td>';
                                                                    }
                                                        echo   '</tr>
                                                                <tr>
                                                                    <th class="text-center" scope="row">4</th>';
                                                                    for ($k=18;$k<=23;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb1[$k].'</td>';
                                                                    }
                                                        echo   '</tr>
                                                                <tr>
                                                                    <th class="text-center" scope="row">5</th>';       
                                                                    for ($k=24;$k<=29;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb1[$k].'</td>';
                                                                    }  
                                                        echo   '</tr>
                                                                <tr>
                                                                    <th class="text-center" scope="row">6</th>';
                                                                    for ($k=30;$k<=35;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb1[$k].'</td>';
                                                                    }
                                                        echo   '</tr>
                                                                <tr>
                                                                    <th class="text-center" scope="row">7</th>';    
                                                                    for ($k=36;$k<=41;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb1[$k].'</td>';
                                                                    }   
                                                        echo   '</tr>
                                                                <tr>
                                                                    <th class="text-center" scope="row">8</th>';    
                                                                    for ($k=42;$k<=47;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb1[$k].'</td>';
                                                                    }    
                                                        echo   '</tr>
                                                                <tr>
                                                                    <th class="text-center" scope="row">9</th>';  
                                                                    for ($k=48;$k<=53;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb1[$k].'</td>';
                                                                    } 
                                                        echo   '</tr>                                       
                                                            </tbody>
                                                        </table><hr/>';
                                                        ///Tuần học loại 2
                                                        echo'
                                                        <span class="label label-orange">Tuần học ********9012345*****</span>
                                                        <table class="table table-bordered m-0">
                                                            <thead>
                                                                <tr>
                                                                    <th class="text-center">Tiết</th>
                                                                    <th class="text-center">Thứ 2</th>
                                                                    <th class="text-center">Thứ 3</th>
                                                                    <th class="text-center">Thứ 4</th>
                                                                    <th class="text-center">Thứ 5</th>
                                                                    <th class="text-center">Thứ 6</th>
                                                                    <th class="text-center">Thứ 7</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <tr>
                                                                    <th class="text-center" scope="row">1</th>';
                                                                    for ($k=0;$k<=5;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb2[$k].'</td>';
                                                                    }
                                                        echo   '</tr>
                                                                <tr>
                                                                    <th class="text-center" scope="row">2</th>';
                                                                    for ($k=6;$k<=11;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb2[$k].'</td>';
                                                                    }
                                                        echo   '</tr>
                                                                <tr>
                                                                    <th class="text-center" scope="row">3</th>';
                                                                    for ($k=12;$k<=17;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb2[$k].'</td>';
                                                                    }
                                                        echo   '</tr>
                                                                <tr>
                                                                    <th class="text-center" scope="row">4</th>';
                                                                    for ($k=18;$k<=23;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb2[$k].'</td>';
                                                                    }
                                                        echo   '</tr>
                                                                <tr>
                                                                    <th class="text-center" scope="row">5</th>';       
                                                                    for ($k=24;$k<=29;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb2[$k].'</td>';
                                                                    }  
                                                        echo   '</tr>
                                                                <tr>
                                                                    <th class="text-center" scope="row">6</th>';
                                                                    for ($k=30;$k<=35;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb2[$k].'</td>';
                                                                    }
                                                        echo   '</tr>
                                                                <tr>
                                                                    <th class="text-center" scope="row">7</th>';    
                                                                    for ($k=36;$k<=41;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb2[$k].'</td>';
                                                                    }   
                                                        echo   '</tr>
                                                                <tr>
                                                                    <th class="text-center" scope="row">8</th>';    
                                                                    for ($k=42;$k<=47;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb2[$k].'</td>';
                                                                    }    
                                                        echo   '</tr>
                                                                <tr>
                                                                    <th class="text-center" scope="row">9</th>';  
                                                                    for ($k=48;$k<=53;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb2[$k].'</td>';
                                                                    } 
                                                        echo   '</tr>                                       
                                                            </tbody>
                                                        </table><hr/>';
                                                        ///Tuần học loại 3
                                                        echo'
                                                        <span class="label label-orange">Tuần học 123456789012345*****</span>
                                                        <table class="table table-bordered m-0">
                                                            <thead>
                                                                <tr>
                                                                    <th class="text-center">Tiết</th>
                                                                    <th class="text-center">Thứ 2</th>
                                                                    <th class="text-center">Thứ 3</th>
                                                                    <th class="text-center">Thứ 4</th>
                                                                    <th class="text-center">Thứ 5</th>
                                                                    <th class="text-center">Thứ 6</th>
                                                                    <th class="text-center">Thứ 7</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <tr>
                                                                    <th class="text-center" scope="row">1</th>';
                                                                    for ($k=0;$k<=5;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb3[$k].'</td>';
                                                                    }
                                                        echo   '</tr>
                                                                <tr>
                                                                    <th class="text-center" scope="row">2</th>';
                                                                    for ($k=6;$k<=11;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb3[$k].'</td>';
                                                                    }
                                                        echo   '</tr>
                                                                <tr>
                                                                    <th class="text-center" scope="row">3</th>';
                                                                    for ($k=12;$k<=17;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb3[$k].'</td>';
                                                                    }
                                                        echo   '</tr>
                                                                <tr>
                                                                    <th class="text-center" scope="row">4</th>';
                                                                    for ($k=18;$k<=23;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb3[$k].'</td>';
                                                                    }
                                                        echo   '</tr>
                                                                <tr>
                                                                    <th class="text-center" scope="row">5</th>';       
                                                                    for ($k=24;$k<=29;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb3[$k].'</td>';
                                                                    }  
                                                        echo   '</tr>
                                                                <tr>
                                                                    <th class="text-center" scope="row">6</th>';
                                                                    for ($k=30;$k<=35;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb3[$k].'</td>';
                                                                    }
                                                        echo   '</tr>
                                                                <tr>
                                                                    <th class="text-center" scope="row">7</th>';    
                                                                    for ($k=36;$k<=41;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb3[$k].'</td>';
                                                                    }   
                                                        echo   '</tr>
                                                                <tr>
                                                                    <th class="text-center" scope="row">8</th>';    
                                                                    for ($k=42;$k<=47;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb3[$k].'</td>';
                                                                    }    
                                                        echo   '</tr>
                                                                <tr>
                                                                    <th class="text-center" scope="row">9</th>';  
                                                                    for ($k=48;$k<=53;$k++){ 
                                                                                    echo '<td class="text-center">'.$in_tkb3[$k].'</td>';
                                                                    } 
                                                        echo   '</tr>                                       
                                                            </tbody>
                                                        </table>';
                                                        echo '<hr/>';
                                                        $data_post1=str_replace('"',"'",$data_post1);
                                                        $data_post2=str_replace('"',"'",$data_post2);
                                                        echo'
                                                        <div class="row">
                                                            <div class="col-md-4">
                                                                <div class="checkbox checkbox-danger checkbox-circle">
                                                                    <form method="post" action="auto-2.php">
                                                                        <input type="hidden" name="no_clc_ha" value="1" >
                                                                        <input id="no_clc_ha1" type="checkbox" onChange="this.form.submit()">
                                                                        <label for="no_clc_ha1">
                                                                            Không xếp vào lớp CLC, Hoà An và Khoá dưới
                                                                        </label>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-3">
                                                                <div class="checkbox checkbox-danger checkbox-circle">
                                                                <form method="post" action="auto-2.php">
                                                                    <input type="hidden" name="no_clc_ha" value="2" >
                                                                    <input id="no_clc_ha2" type="checkbox" onChange="this.form.submit()" checked>
                                                                    <label for="no_clc_ha2">
                                                                        Chỉ xếp các lớp ở Hoà An
                                                                    </label>
                                                                </form>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-3">
                                                                <div class="checkbox checkbox-danger checkbox-circle">
                                                                <form method="post" action="auto-2.php">
                                                                    <input type="hidden" name="no_clc_ha" value="3" >
                                                                    <input id="no_clc_ha3" type="checkbox" onChange="this.form.submit()">
                                                                    <label for="no_clc_ha3">
                                                                        Chỉ xếp các lớp CLC
                                                                    </label>
                                                                </form>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <form method="post" action="luu-tkb.php">
                                                        <input type="hidden" name="ten" value="'.$data_post1.'">
                                                        <input type="hidden" name="kyhieu" value="'.$data_post2.'">
                                                        <button type="button" onClick="window.location.reload()" class="btn btn-success btn-rounded w-md waves-effect waves-light m-b-5">Xếp lại</button>
                                                        <button type="submit" value="submit" class="btn btn-primary btn-rounded w-md waves-effect waves-light m-b-5">Lưu lại</button>
                                                        <button type="button" data-toggle="modal" data-target="#co-dinh-nhom" class="btn btn-orange btn-rounded waves-light waves-effect w-md m-b-5">Cố định nhóm</button>
                                                        </form>
                                                        <form method="post" action="auto-2.php">
                                                            <input type="hidden" name="huy_ck_nhom" value="0">
                                                            <button onClick="this.form.submit()" type="button" class="btn btn-danger btn-rounded waves-light waves-effect w-md m-b-5">Huỷ các nhóm cố định</button>
                                                        </form>    
                                                        ';
                                                        
                                                        
                                                        $so_mau=1;
                                                    }
                                                    ketthuc2: if ($check==1){
                                                        $so_mau=0;
                                                    }
                                                    khongcolop: {
                                                        $so_mau=0;
                                                        break;
                                                    }
                                                }
                                                
                                            }
                                    }
                                    else echo '
                                    <div class="alert alert-danger alert-dismissible fade in text-center" role="alert"> Vui lòng đăng nhập để tiếp tục bạn nhé!
                                    </div>';
                                    ?>
                            </div>
                        </div>
                    </div>
                    
                </div>
                <!-- Footer -->
                <footer class="footer text-right">
                    <div class="container">
                        <div class="row">
                            <div class="col-xs-12 text-center">
                                © 2020. Lieu Tuan Vu B1906810. Có sử dụng nội dung từ trang Quản lí đào tạo CTU
                            </div>
                        </div>
                    </div>
                </footer>
                <!-- End Footer -->

            </div> <!-- end container -->
        </div>
        <!-- end wrapper -->


        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/detect.js"></script>
        <script src="assets/js/fastclick.js"></script>
        <script src="assets/js/jquery.blockUI.js"></script>
        <script src="assets/js/waves.js"></script>
        <script src="assets/js/jquery.slimscroll.js"></script>
        <script src="assets/js/jquery.scrollTo.min.js"></script>
        <script src="assets/sweetalert/sweet-alert.min.js"></script>


        <!-- init -->

        <!-- App js -->
        <script src="assets/js/jquery.core.js"></script>
        <script src="assets/js/jquery.app.js"></script>

    </body>
</html>