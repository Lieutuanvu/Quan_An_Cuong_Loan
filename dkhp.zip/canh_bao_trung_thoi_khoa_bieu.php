<?php 
$inra="";
include_once("cosodulieu.php");
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="Trang web giả lập đăng ký học phần CTU">
        <link rel="shortcut icon" href="assets/images/favicon.ico">
        <title>Cảnh báo Lớp bạn đăng ký đã trùng thời khoá biểu với lớp khác</title>
                <!-- DataTables -->
        <link href="datatables/jquery.dataTables.min.css" rel="stylesheet" type="text/css"/>
        <link href="datatables/buttons.bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="datatables/fixedHeader.bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="datatables/responsive.bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="datatables/scroller.bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="datatables/dataTables.colVis.css" rel="stylesheet" type="text/css"/>
        <link href="datatables/dataTables.bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="datatables/fixedColumns.dataTables.min.css" rel="stylesheet" type="text/css"/>
        <link href="responsive-table/css/rwd-table.min.css" rel="stylesheet" type="text/css" media="screen">
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/core.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/components.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/pages.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/menu.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/responsive.css" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="../plugins/switchery/switchery.min.css">
        <script src="assets/js/modernizr.min.js"></script>

    </head>
    <body>
        <div class="wrapper">
            <div class="container">

                <!-- Page-Title -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-title-box">
                            <h4 class="page-title">Cảnh báo</h4>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                    <div class="alert alert-icon alert-danger alert-dismissible fade in" role="alert">
                                        <button onclick="dongcanhbao()" type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span onclick="dongcanhbao()" aria-hidden="false">Đóng cảnh báo</span>
                                        </button>
                            <i class="mdi mdi-block-helper"></i>
                            <strong>Cảnh báo!</strong> Lớp bạn đăng ký đã trùng thời khoá biểu với lớp khác, vui lòng đổi sang lớp khác bạn nhé, hoặc bạn có thể chỉnh sửa lại kế hoạch học tập cho phù hợp!
                    </div>
                    </div>
                </div>
                <!-- Footer -->
                <footer class="footer text-right">
                    <div class="container">
                        <div class="row">
                            <div class="col-xs-12 text-center">
                                © 2020. All rights reserved.
                            </div>
                        </div>
                    </div>
                </footer>
                <!-- End Footer -->

            </div> <!-- end container -->
        </div>
        <!-- end wrapper -->


        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/detect.js"></script>
        <script src="assets/js/fastclick.js"></script>
        <script src="assets/js/jquery.blockUI.js"></script>
        <script src="assets/js/waves.js"></script>
        <script src="assets/js/jquery.slimscroll.js"></script>
        <script src="assets/js/jquery.scrollTo.min.js"></script>
        <script src="switchery/switchery.min.js"></script>

        <script src="datatables/jquery.dataTables.min.js"></script>
        <script src="datatables/dataTables.bootstrap.js"></script>

        <script src="datatables/dataTables.buttons.min.js"></script>
        <script src="datatables/buttons.bootstrap.min.js"></script>
        <script src="datatables/jszip.min.js"></script>
        <script src="datatables/pdfmake.min.js"></script>
        <script src="datatables/vfs_fonts.js"></script>
        <script src="datatables/buttons.html5.min.js"></script>
        <script src="datatables/buttons.print.min.js"></script>
        <script src="datatables/dataTables.fixedHeader.min.js"></script>
        <script src="datatables/dataTables.keyTable.min.js"></script>
        <script src="datatables/dataTables.responsive.min.js"></script>
        <script src="datatables/responsive.bootstrap.min.js"></script>
        <script src="datatables/dataTables.scroller.min.js"></script>
        <script src="datatables/dataTables.colVis.js"></script>
        <script src="datatables/dataTables.fixedColumns.min.js"></script>

        <!-- init -->
        <script src="assets/pages/jquery.datatables.init.js"></script>

        <!-- App js -->
        <script src="assets/js/jquery.core.js"></script>
        <script src="assets/js/jquery.app.js"></script>

        <script type="text/javascript">
function dongcanhbao() {
    close();
}
        </script>
    </body>
</html>