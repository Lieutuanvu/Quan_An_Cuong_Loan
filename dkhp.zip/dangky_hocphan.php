<?php 
$inra="";
include_once("cosodulieu.php");
$trave="";
$noidau='
<div class="card-box table-responsive">
<table class="table table-striped table-bordered">
<thead>
<tr>
    <th class="text-center">STT</th>
    <th class="text-center">Ký hiệu	</th>
    <th class="text-center">Thứ</th>
    <th class="text-center">Tiết BĐ	</th>
    <th class="text-center">Số tiết	</th>
    <th class="text-center">Phòng</th>
    <th class="text-center">Sỉ số</th>
    <th class="text-center">Sỉ số còn lại</th>
    <th>Tuần học</th>
    <th class="text-center">Lớp học phần</th>
</tr>
</thead>
<tbody>';
$kyhieu_truocdo="";
$ketnoi= new mysqli($db_host,$db_user,$db_pass,$db_name);
mysqli_set_charset($ketnoi, 'UTF8');
if (isset($_SESSION['user'])){
                // Phần này lấy ID của user
                $tai_khoan=$_SESSION['user'];
                $lay_id=$ketnoi->query("SELECT `ID` FROM `sinhvien` WHERE `user` ='$tai_khoan'");
                if ($lay_id && $lay_id->num_rows>0){
                    while($lay_id_array=$lay_id->fetch_assoc())
                    {
                        $id=$lay_id_array['ID'];
                    }
                }
                $tim_hp_trong_kehoachhoctap=$ketnoi->query("SELECT * FROM `kehoachhoctap` WHERE `ID`='$id'");
                // Hết phần lấy ID user
    if (!isset($_GET['mahp']) && !isset($_GET['kyhieu'])){
        $inra=   'Bạn hông thể truy cập trang này đâu :(';
        $mahp="";
    }
    else 
    {   $mahp=$_GET['mahp'];
        $kiemtra_dkchua=$ketnoi->query("SELECT * FROM `dkhocphan` WHERE `mahp`='$mahp' WHERE `ID`='$id'");
        if ($kiemtra_dkchua && $kiemtra_dkchua->num_rows!=0){
            $inra="Bạn đã đăng ký học phần này, vui lòng đóng cửa sổ này để tiếp tục!";
        }
        else
        {
        $search_lophocphan=$ketnoi->query("SELECT * FROM `hocphan` WHERE `mahocphan`='$mahp' ORDER BY `stt` ASC");
        if ($search_lophocphan && $search_lophocphan->num_rows>0)
            {   
                while ($row = $search_lophocphan->fetch_assoc()) {
                    if ($kyhieu_truocdo==$row['kyhieu']){
                        $trave=$trave.'<tr><th class="text-center">'.$row['stt'].'</th>
                                            <th class="text-center">'.$row['kyhieu'].'</th>
                                            <th class="text-center">'.$row['thu'].'</th>
                                            <th class="text-center">'.$row['tietbd'].'</th>
                                            <th class="text-center">'.$row['sotiet'].'</th>
                                            <th class="text-center">'.$row['phong'].'</th>
                                            <th class="text-center">'.$row['siso'].'</th>
                                            <th class="text-center">'.$row['sisoconlai'].'</th>
                                            <th>'.$row['tuanhoc'].'</th>
                                            <th class="text-center">'.$row['lophp'].'</th></tr>';
                        $noiduoi='</tbody><button type="button" onClick="dklopnay('."'".$mahp."',"."'".$row['kyhieu']."',"."'".$row['tinchi']."'".')" class="btn btn-purple waves-effect w-md waves-light m-b-5">Đăng ký lớp '.$row['kyhieu'].'</button></table>                        </div>';
    
                    }
                    else 
                    {   
                        if ($kyhieu_truocdo!="")
                        {   
                            $inra=$inra.$noidau.$trave.$noiduoi;
                            $trave='<tr><th class="text-center">'.$row['stt'].'</th>
                                        <th class="text-center">'.$row['kyhieu'].'</th>
                                        <th class="text-center">'.$row['thu'].'</th>
                                        <th class="text-center">'.$row['tietbd'].'</th>
                                        <th class="text-center">'.$row['sotiet'].'</th>
                                        <th class="text-center">'.$row['phong'].'</th>
                                        <th class="text-center">'.$row['siso'].'</th>
                                        <th class="text-center">'.$row['sisoconlai'].'</th>
                                        <th>'.$row['tuanhoc'].'</th>
                                        <th class="text-center">'.$row['lophp'].'</th></tr>';
                            $siso_conlai=$row['sisoconlai'];
                            if ((int)$siso_conlai>0){
                                $noiduoi='</tbody><button type="button" onClick="dklopnay('."'".$mahp."',"."'".$row['kyhieu']."',"."'".$row['tinchi']."'".')" class="btn btn-purple waves-effect w-md waves-light m-b-5">Đăng ký lớp '.$row['kyhieu'].'</button></table>                        </div>';
                            } else {
                                $noiduoi='</tbody><button type="button" class="btn btn-danger waves-effect w-md waves-light m-b-5">Lớp '.$row['kyhieu'].' đã đủ sỉ số</button></table>                        </div>';
                            }
                                    }
                        else if ($kyhieu_truocdo=="")
                        {
                            $trave='<tr><th class="text-center">'.$row['stt'].'</th>
                                        <th class="text-center">'.$row['kyhieu'].'</th>
                                        <th class="text-center">'.$row['thu'].'</th>
                                        <th class="text-center">'.$row['tietbd'].'</th>
                                        <th class="text-center">'.$row['sotiet'].'</th>
                                        <th class="text-center">'.$row['phong'].'</th>
                                        <th class="text-center">'.$row['siso'].'</th>
                                        <th class="text-center">'.$row['sisoconlai'].'</th>
                                        <th>'.$row['tuanhoc'].'</th>
                                        <th class="text-center">'.$row['lophp'].'</th></tr>';
                                        $siso_conlai=$row['sisoconlai'];
                                        if ((int)$siso_conlai>0){
                                            $noiduoi='</tbody><button type="button" onClick="dklopnay('."'".$mahp."',"."'".$row['kyhieu']."',"."'".$row['tinchi']."'".')" class="btn btn-purple waves-effect w-md waves-light m-b-5">Đăng ký lớp '.$row['kyhieu'].'</button></table>                        </div>';
                                        } else {
                                            $noiduoi='</tbody><button type="button" class="btn btn-danger waves-effect w-md waves-light m-b-5">Lớp '.$row['kyhieu'].' đã đủ sỉ số</button></table>                        </div>';
                                        }            
                        }
                    }
                    $kyhieu_truocdo=$row['kyhieu'];
                }
                $inra=$inra.$noidau.$trave.$noiduoi;
            }
            else {
                $inra="Học phần này không mở lớp vào học kì này, bạn vui lòng thay đổi kế hoạch học tập hoặc bỏ qua học phần này!";
            }
        }
    }
} else {
    $inra="Vui lòng đăng nhập để thực hành đăng ký học phần bạn nhé ^^";
    $mahp="";
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="Trang web giả lập đăng ký học phần CTU">
        <link rel="shortcut icon" href="assets/images/favicon.ico">
        <title>Đăng ký học phần <?php echo $mahp; ?></title>
                <!-- DataTables -->
        <link href="datatables/jquery.dataTables.min.css" rel="stylesheet" type="text/css"/>
        <link href="datatables/buttons.bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="datatables/fixedHeader.bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="datatables/responsive.bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="datatables/scroller.bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="datatables/dataTables.colVis.css" rel="stylesheet" type="text/css"/>
        <link href="datatables/dataTables.bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="datatables/fixedColumns.dataTables.min.css" rel="stylesheet" type="text/css"/>
        <link href="responsive-table/css/rwd-table.min.css" rel="stylesheet" type="text/css" media="screen">
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/core.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/components.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/pages.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/menu.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/responsive.css" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="../plugins/switchery/switchery.min.css">
        <script src="assets/js/modernizr.min.js"></script>

    </head>
    <body>
        <div class="wrapper">
            <div class="container">

                <!-- Page-Title -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-title-box">
                            <h4 class="page-title">Đăng ký lớp học phần</h4>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                            
                                    <?php echo $inra;?>

                    </div>
                </div>
                <!-- Footer -->
                <footer class="footer text-right">
                    <div class="container">
                        <div class="row">
                            <div class="col-xs-12 text-center">
                                © 2020. Lieu Tuan Vu B1906810. Có sử dụng nội dung từ trang Quản lí đào tạo CTU
                            </div>
                        </div>
                    </div>
                </footer>
                <!-- End Footer -->

            </div> <!-- end container -->
        </div>
        <!-- end wrapper -->


        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/detect.js"></script>
        <script src="assets/js/fastclick.js"></script>
        <script src="assets/js/jquery.blockUI.js"></script>
        <script src="assets/js/waves.js"></script>
        <script src="assets/js/jquery.slimscroll.js"></script>
        <script src="assets/js/jquery.scrollTo.min.js"></script>
        <script src="switchery/switchery.min.js"></script>

        <script src="datatables/jquery.dataTables.min.js"></script>
        <script src="datatables/dataTables.bootstrap.js"></script>

        <script src="datatables/dataTables.buttons.min.js"></script>
        <script src="datatables/buttons.bootstrap.min.js"></script>
        <script src="datatables/jszip.min.js"></script>
        <script src="datatables/pdfmake.min.js"></script>
        <script src="datatables/vfs_fonts.js"></script>
        <script src="datatables/buttons.html5.min.js"></script>
        <script src="datatables/buttons.print.min.js"></script>
        <script src="datatables/dataTables.fixedHeader.min.js"></script>
        <script src="datatables/dataTables.keyTable.min.js"></script>
        <script src="datatables/dataTables.responsive.min.js"></script>
        <script src="datatables/responsive.bootstrap.min.js"></script>
        <script src="datatables/dataTables.scroller.min.js"></script>
        <script src="datatables/dataTables.colVis.js"></script>
        <script src="datatables/dataTables.fixedColumns.min.js"></script>

        <!-- init -->
        <script src="assets/pages/jquery.datatables.init.js"></script>

        <!-- App js -->
        <script src="assets/js/jquery.core.js"></script>
        <script src="assets/js/jquery.app.js"></script>

        <script type="text/javascript">
function dklopnay(x,y,z) {
  if (confirm("Đăng ký lớp học này?")) {
    location.replace("dkhp.php?maph="+x+"&kyhieu="+y+"&stc="+z);
  }
}
        </script>
    </body>
</html>