<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta charset="UTF-8">
	 <meta http-equiv="refresh" content="0 url=khht.php" >
	<title></title>
</head>
<body>
	<?php 
	include_once("cosodulieu.php");
	$ketnoi = new mysqli($db_host, $db_user, $db_pass, $db_name);
	mysqli_set_charset($ketnoi, 'UTF8');
	$sql="";
	if (!isset($_SESSION['user']))
	{
		echo "Bạn không có quyền truy cập vào trang này bạn nhé ^^";
	}else{
		if (isset($_GET['maph'])){
			$mahp=$_GET['maph'];
			$kiemtra="SELECT `dangky` FROM `dmhocphan` WHERE mahp='$mahp'";
			$tai_khoan=$_SESSION['user'];
			$lay_id=$ketnoi->query("SELECT `ID` FROM `sinhvien` WHERE `user` ='$tai_khoan'");
			if ($lay_id && $lay_id->num_rows>0){
				while($lay_id_array=$lay_id->fetch_assoc())
				{
					$id=$lay_id_array['ID'];
				}
			}
			$sql="DELETE FROM `kehoachhoctap` WHERE `ID`='$id' AND `mahp`='$mahp'";
			$kq=mysqli_query($ketnoi,$sql);
			if ($kq) {
				header("khht.php");
			}
		} else 	{
				echo "Bạn không có quyền truy cập vào trang này bạn nhé ^^";
				$mahp="";
		}

	}
	 ?>
</body>
</html>