    <?php 
    include_once("cosodulieu.php");
    $ketnoi= new mysqli($db_host,$db_user,$db_pass,$db_name);
    mysqli_set_charset($ketnoi, 'UTF8');
    $trave="";
    $timkiem="";
    $so_trang=0;
    if (isset($_SESSION['user']))
    {
        $tai_khoan=$_SESSION['user'];
        $lay_id=$ketnoi->query("SELECT `ID` FROM `sinhvien` WHERE `user` ='$tai_khoan'");
        if ($lay_id && $lay_id->num_rows>0){
            while($lay_id_array=$lay_id->fetch_assoc())
            {
                $id=$lay_id_array['ID'];
            }
        } else $id="DKHP00";
        if(!isset($_POST['mahp']) || !isset($_POST['bamtim'])){
            $trave="";
            $result = $ketnoi->query("SELECT * FROM `dmhocphan`");
            if ($result && $result->num_rows>0){
                $sl_hocphan=$result->num_rows; ////Lấy số lượng học phần
            }
            $hienthi_hp=15;///số lượng hp hiển thị mỗi trang
            $so_trang=ceil($sl_hocphan/$hienthi_hp);//Chia lấy số nguyên trang, tổng học phần / 15 học phần 1 trang

            if (isset($_GET['trang'])){
                $trang=$_GET['trang'];
                if ($trang>$so_trang){ //Truy cập trang lớn hơn tổng số trang
                    $trang=$so_trang;
                } else if ($trang<1){  //Truy cập trang nhỏ hơn 1 thì quá sai
                    $trang=1;
                }
            } else {
                $trang=1;
            }
            $bat_dau_hien_thi=($trang-1)*$hienthi_hp;
            $result=$ketnoi->query("SELECT * FROM `dmhocphan` LIMIT $bat_dau_hien_thi,$hienthi_hp");                                        

            if ($result && $result ->num_rows >0 )
            {   
                while ($row = $result->fetch_assoc()) {
                    $mahp_timkiem=$row['mahp'];
                    $lay_tai_khoan_sosanh=$ketnoi->query("SELECT * FROM `kehoachhoctap` WHERE `mahp`='$mahp_timkiem' && `ID`='$id'");
                    if (mysqli_num_rows($lay_tai_khoan_sosanh)>0)
                    {
                        $dangky='<th class="text-center"><button onClick="xacnhan('."'".$row['mahp']."',0".','.$trang.')" class="btn btn-danger btn-xs" href="#"><span class="glyphicon glyphicon-edit"></span> Xoá</button></th>';
                    } 
                    else
                    {
                        $dangky='<th class="text-center"><button onClick="xacnhan('."'".$row['mahp']."',1".','.$trang.')" class="btn btn-info btn-xs" ><span class="glyphicon glyphicon-edit"></span> Đăng ký</button></th>';
                    }
                    $trave=$trave.'<tr><th class="text-center">'.$row['mahp'].'</th><th>'.$row['tenhocphan'].'</th><th class="text-center">'.$row['tinchi'].'</th>'.$dangky.'</tr>';
                }
            }
        }

        ////Liệt kê môn khi tìm kiếm
        if (isset($_POST['bamtim'])){
            $timkiem = addslashes(trim($_POST['mahp'],' '));
            if (empty($timkiem)){
                $trave="";
                $result = $ketnoi->query("SELECT * FROM `dmhocphan`");
                if ($result && $result->num_rows>0){
                    $sl_hocphan=$result->num_rows; ////Lấy số lượng học phần
                }
                $hienthi_hp=15;///số lượng hp hiển thị mỗi trang
                $so_trang=ceil($sl_hocphan/$hienthi_hp);//Chia lấy số nguyên trang, tổng học phần / 15 học phần 1 trang

                if (isset($_GET['trang'])){
                    $trang=$_GET['trang'];
                    if ($trang>$so_trang){ //Truy cập trang lớn hơn tổng số trang
                        $trang=$so_trang;
                    } else if ($trang<1){  //Truy cập trang nhỏ hơn 1 thì quá sai
                        $trang=1;
                    }
                } else {
                    $trang=1;
                }
                $bat_dau_hien_thi=($trang-1)*$hienthi_hp;
                $result=$ketnoi->query("SELECT * FROM `dmhocphan` LIMIT $bat_dau_hien_thi,$hienthi_hp");                                        

                if ($result && $result ->num_rows >0 )
                {   
                    while ($row = $result->fetch_assoc()) {
                        $mahp_timkiem=$row['mahp'];
                        $lay_tai_khoan_sosanh=$ketnoi->query("SELECT * FROM `kehoachhoctap` WHERE `mahp`='$mahp_timkiem' && `ID`='$id'");
                        if (mysqli_num_rows($lay_tai_khoan_sosanh)>0)
                        {
                            $dangky='<th class="text-center"><button onClick="xacnhan('."'".$row['mahp']."',0".','.$trang.')" class="btn btn-danger btn-xs" href="#"><span class="glyphicon glyphicon-edit"></span> Xoá</button></th>';
                        } 
                        else
                        {
                            $dangky='<th class="text-center"><button onClick="xacnhan('."'".$row['mahp']."',1".','.$trang.')" class="btn btn-info btn-xs" ><span class="glyphicon glyphicon-edit"></span> Đăng ký</button></th>';
                        }
                        $trave=$trave.'<tr><th class="text-center">'.$row['mahp'].'</th><th>'.$row['tenhocphan'].'</th><th class="text-center">'.$row['tinchi'].'</th>'.$dangky.'</tr>';
                    }
                }
            } else
            {  
                $mahp=addslashes(trim($_POST['mahp'],' '));
                $result = $ketnoi->query("SELECT * FROM `dmhocphan` WHERE `mahp` = '$mahp'");
                $trave="";
                if ($result && $result ->num_rows >0 )
                {   
                    while ($row = $result->fetch_assoc()) {
                        $mahp_timkiem=$row['mahp'];
                        $lay_tai_khoan_sosanh=$ketnoi->query("SELECT * FROM `kehoachhoctap` WHERE `mahp`='$mahp_timkiem' && `ID`='$id'");
                        if (mysqli_num_rows($lay_tai_khoan_sosanh)>0)
                        {
                            $dangky='<th class="text-center"><button onClick="xacnhan('."'".$row['mahp']."',0".',1)" class="btn btn-danger btn-xs" href="#"><span class="glyphicon glyphicon-edit"></span> Xoá</button></th>';
                        } 
                        else
                        {
                            $dangky='<th class="text-center"><button onClick="xacnhan('."'".$row['mahp']."',1".',1)" class="btn btn-info btn-xs" ><span class="glyphicon glyphicon-edit"></span> Đăng ký</button></th>';
                        }
                        $trave=$trave.'<tr><th class="text-center">'.$row['mahp'].'</th><th>'.$row['tenhocphan'].'</th><th class="text-center">'.$row['tinchi'].'</th>'.$dangky.'</tr>';
                    }
                }
            };
        }
    }
    ?>
    <!DOCTYPE html>
    <html>
        <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta name="description" content="Trang web giả lập đăng ký học phần CTU">
            <link rel="shortcut icon" href="assets/images/favicon.ico">
            <title>Danh sách - Đăng ký học phần</title>
            <link href="responsive-table/css/rwd-table.min.css" rel="stylesheet" type="text/css" media="screen">
            <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
            <link href="assets/css/core.css" rel="stylesheet" type="text/css" />
            <link href="assets/css/components.css" rel="stylesheet" type="text/css" />
            <link href="assets/css/icons.css" rel="stylesheet" type="text/css" />
            <link href="assets/css/pages.css" rel="stylesheet" type="text/css" />
            <link href="assets/css/menu.css" rel="stylesheet" type="text/css" />
            <link href="assets/css/responsive.css" rel="stylesheet" type="text/css" />
            <link href="assets/sweetalert/sweet-alert.css" rel="stylesheet" type="text/css" />
            <link rel="stylesheet" href="../plugins/switchery/switchery.min.css">
            <script src="assets/js/modernizr.min.js"></script>

        </head>
        <body>
        <?php include_once("menu.php") ?>

            <div class="wrapper">
                <div class="container">

                    <!-- Page-Title -->
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="page-title-box">
                                <h4 class="page-title">Tra cứu học phần</h4>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card-box table-responsive">
                            <div class="container">
                                        <form id="timhp" role="search" method="post" action="ds_dk_hocphan.php">
                                            <div class="col-sm-6 col-sm-offset-3">
                                                <div class="form-group search-box">
                                                    <input type="text" name="mahp" value="<?php echo $timkiem;?>" class="form-control" placeholder="Tìm kiếm học phần...">
                                                    <button type="submit" name="bamtim" class="btn btn-search"><i class="fa fa-search"></i></button>
                                                </div> 
                                            </div>
                                        </form>
                            </div>
                                <div class="container">
                                        <?php if (isset($_SESSION['user']))
                                        {   
                                            echo'                                
                                            <div>
                                            <table class="table table-striped table-bordered">
                                            <thead>
                                                <tr>
                                                    <th class="text-center">Mã học phần</th>
                                                    <th class="text-center">Tên học phần</th>
                                                    <th class="text-center">Số tín chỉ</th>
                                                    <th class="text-center">Thực hiện</th>
                                                </tr>
                                            </thead>';
                                            echo $trave;
                                            echo'
                                            </table>';
                                            echo'
                                            <ul class="pagination">';
                                            if ($trang==1){
                                                echo'
                                                <li class="disabled">
                                                    <a href="#"><i class="fa fa-angle-left"></i><i class="fa fa-angle-left"></i></a>
                                                </li>';
                                                echo'
                                                <li class="disabled">
                                                    <a href="#"><i class="fa fa-angle-left"></i></a>
                                                </li>';
                                            } else if ($trang>1){
                                                echo'
                                                <li>
                                                    <a href="ds_dk_hocphan.php?trang=1"><i class="fa fa-angle-left"></i><i class="fa fa-angle-left"></i></a>
                                                </li>';
                                                echo'
                                                <li>
                                                    <a href="ds_dk_hocphan.php?trang='.($trang-1).'"><i class="fa fa-angle-left"></i></a>
                                                </li>';
                                                
                                            }
                                            $class=[];

                                            if ($trang==1){
                                                echo'
                                                <li class="active">
                                                    <a href="#">1</a>
                                                </li>';
                                                echo'
                                                <li>
                                                    <a href="ds_dk_hocphan.php?trang=2">2</a>
                                                </li>';
                                                echo'
                                                <li>
                                                    <a href="ds_dk_hocphan.php?trang=3">3</a>
                                                </li>';
                                                echo'
                                                <li>
                                                    <a href="ds_dk_hocphan.php?trang=4">...</a>
                                                </li>';
                                            } else if ($trang==$so_trang){
                                                echo'
                                                <li>
                                                    <a href="ds_dk_hocphan.php?trang='.($trang-3).'">...</a>
                                                </li>
                                                <li>
                                                    <a href="ds_dk_hocphan.php?trang='.($trang-2).'">'.($trang-2).'</a>
                                                </li>';
                                                echo'
                                                <li>
                                                    <a href="ds_dk_hocphan.php?trang='.($trang-1).'">'.($trang-1).'</a>
                                                </li>';
                                                echo'
                                                <li class="active">
                                                    <a href="#">'.$trang.'</a>
                                                </li>';
                                            } else {
                                                echo'
                                                <li>
                                                    <a href="ds_dk_hocphan.php?trang='.($trang-1).'">'.($trang-1).'</a>
                                                </li>';
                                                echo'
                                                <li class="active">
                                                    <a href="#">'.($trang).'</a>
                                                </li>';
                                                echo'
                                                <li>
                                                    <a href="ds_dk_hocphan.php?trang='.($trang+1).'">'.($trang+1).'</a>
                                                </li>';
                                            }
                                            if ($trang==$so_trang){
                                                
                                                echo'
                                                <li class="disabled">
                                                    <a href="#"><i class="fa fa-angle-right"></i></a>
                                                </li>';
                                                echo'
                                                <li class="disabled">
                                                    <a href="#"><i class="fa fa-angle-right"></i><i class="fa fa-angle-right"></i></a>
                                                </li>';
                                            } else if ($trang<$so_trang){
                                                echo'
                                                <li>
                                                    <a href="ds_dk_hocphan.php?trang='.($trang+1).'"><i class="fa fa-angle-right"></i></a>
                                                </li>';
                                                echo'
                                                <li>
                                                    <a href="ds_dk_hocphan.php?trang='.($so_trang).'"><i class="fa fa-angle-right"></i><i class="fa fa-angle-right"></i></a>
                                                </li>';
                                                
                                            }    
                                            echo'
                                            </ul>
                                            </div>';
                                        }
                                        else echo '
                                        <div class="alert alert-danger alert-dismissible fade in text-center" role="alert"> Vui lòng đăng nhập để tiếp tục bạn nhé!
                                        </div>';
                                        ?>

                                </div>
                            </div>
                        </div>
                        
                    </div>
                    <!-- Footer -->
                    <footer class="footer text-right">
                        <div class="container">
                            <div class="row">
                                <div class="col-xs-12 text-center">
                                    © 2020. Lieu Tuan Vu B1906810. Có sử dụng nội dung từ trang Quản lí đào tạo CTU
                                </div>
                            </div>
                        </div>
                    </footer>
                    <!-- End Footer -->

                </div> <!-- end container -->
            </div>
            <!-- end wrapper -->


            <!-- jQuery  -->
            <script src="assets/js/jquery.min.js"></script>
            <script src="assets/js/bootstrap.min.js"></script>
            <script src="assets/js/detect.js"></script>
            <script src="assets/js/fastclick.js"></script>
            <script src="assets/js/jquery.blockUI.js"></script>
            <script src="assets/js/waves.js"></script>
            <script src="assets/js/jquery.slimscroll.js"></script>
            <script src="assets/js/jquery.scrollTo.min.js"></script>
            <script src="assets/sweetalert/sweet-alert.min.js"></script>
            <script src="switchery/switchery.min.js"></script>
            <!-- init -->
            <script src="assets/pages/jquery.datatables.init.js"></script>

            <!-- App js -->
            <script src="assets/js/jquery.core.js"></script>
            <script src="assets/js/jquery.app.js"></script>

        <script>
            function xacnhan(x,y,trang){
                
                if(confirm("Bạn thực sự muốn thay đổi trạng thái môn học này?") == true){
                    location.replace("dangky_khht.php?maph="+x+"&thuchien="+y+"&trang="+trang);
                }
            }
        </script>
        </body>
    </html>