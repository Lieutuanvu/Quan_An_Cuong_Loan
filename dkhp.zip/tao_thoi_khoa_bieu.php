<?php 
include_once("cosodulieu.php");
// include_once("taomang.php");
$ketnoi= new mysqli($db_host,$db_user,$db_pass,$db_name);
$thong_bao_trunglop="";
/// ở dưới là phần tạo mảng để đánh dấu
for ($i=0;$i<=8;$i++){ // biến $i là số tiết trong ngày, tiết 1 => i=0, tiết 2 => i=1, tiết 3 => i=2,...
    for ($j=0;$j<=5;$j++) // biển $j là thứ trong tuần thứ 2 => j=0, thứ 3 => j=1, thứ 4 => j=2,...
    { 
        $mang[$i][$j]='-';
    }
}
///Phần ở trên là tạo mảng để chuẩn bị đánh dấu
if (isset($_SESSION['user'])){
$tai_khoan=$_SESSION['user'];
$lay_id=$ketnoi->query("SELECT `ID` FROM `sinhvien` WHERE `user` ='$tai_khoan'");
        if ($lay_id && $lay_id->num_rows>0){
            while($lay_id_array=$lay_id->fetch_assoc())
            {
                $id=$lay_id_array['ID'];
            }
        }

//  Phần lấy thông tin lịch học
$lay_hocphanra = $ketnoi->query("SELECT `stt`,`mahp`,`kyhieu` FROM `dkhocphan` WHERE `ID`='$id' ORDER BY `stt` ASC");
if ($lay_hocphanra && $lay_hocphanra->num_rows>0)
{
    while ($lay_hocphanra_kq=$lay_hocphanra->fetch_assoc())
    {   $stt=$lay_hocphanra_kq['stt'];
        $mahp=$lay_hocphanra_kq['mahp'];
        $kyhieu=$lay_hocphanra_kq['kyhieu'];
        $lay_thoi_gian_hoc=$ketnoi->query("SELECT `thu`, `sotiet`,`tietbd` FROM `hocphan` WHERE `kyhieu`='$kyhieu' AND `mahocphan`='$mahp' ");
        if ($lay_thoi_gian_hoc && $lay_thoi_gian_hoc->num_rows>0)
        {
            while($lay_thoi_gian_hoc_kq=$lay_thoi_gian_hoc->fetch_assoc())
            {
                $thu=$lay_thoi_gian_hoc_kq['thu'];
                $tietbd=$lay_thoi_gian_hoc_kq['tietbd'];
                $sotiet=$lay_thoi_gian_hoc_kq['sotiet'];
                
                // Tạo mảng đánh dấu ở bên dưới 
                $thu_sosanh=$thu - 2;
                $tietbd_sosanh=$tietbd-1;
                $giam_sotiet=$sotiet;
                $dem=1;
                for ($i=0;$i<=8;$i++){ // biến $i là số tiết trong ngày, tiết 1 => i=0, tiết 2 => i=1, tiết 3 => i=2,...
                    if ($i==$tietbd_sosanh){
                            $tietbd_sosanh++;
                            $giam_sotiet--;
                            for ($j=0;$j<=5;$j++) // biển $j là thứ trong tuần thứ 2 => j=0, thứ 3 => j=1, thứ 4 => j=2,...
                            {       
                                    if (($dem<=$sotiet) && ($j==$thu_sosanh) )
                                    {   if ($mang[$i][$j]!="-"){$thong_bao_trunglop= "Trùng lớp";break;}
                                        else
                                        {   $mang[$i][$j]=$mahp;
                                            $dem++;
                                        }
                                    }
                            }
                            if ($giam_sotiet==0) { break;}
                    }
                }
                // Kết thúc tạo mảng đánh dấu
            }
        }
    }
}
//  Kết thúc phần lấy thông tin lịch học
// echo $thu.' '.$tietbd.' '.$sotiet.'</br>';
// $thu=4;$tietbd=6;$sotiet=3;


// $thu_sosanh=$thu - 2;
// $tietbd_sosanh=$tietbd-1;
// $giam_sotiet=$sotiet;
// $dem=1;

        /*Ở dưới là tạo mảng đánh số học--*/
// for ($i=0;$i<=8;$i++){ // biến $i là số tiết trong ngày, tiết 1 => i=0, tiết 2 => i=1, tiết 3 => i=2,...
//     if ($i==$tietbd_sosanh){
//             $tietbd_sosanh++;
//             $giam_sotiet--;
//             for ($j=0;$j<=5;$j++) // biển $j là thứ trong tuần thứ 2 => j=0, thứ 3 => j=1, thứ 4 => j=2,...
//             {   
//                     if (($dem<=$sotiet) && ($j==$thu_sosanh) )
//                     {
//                         $mang[$i][$j]='1';
//                         $dem++;
//                     }
//             }
//             if ($giam_sotiet==0) { break;}
//     }
// }
} else echo "Bạn hãy đăng nhập để xem  nhé!";
?>
    	    <table id="thoi-khoa-bieu" class="table-condensed table-bordered table-striped">
                <thead>
                    <tr>
                        <th class="text-center">Tiết</th>
                        <th class="text-center">Thứ 2</th>
                        <th class="text-center">Thứ 3</th>
                        <th class="text-center">Thứ 4</th>
                        <th class="text-center">Thứ 5</th>
                        <th class="text-center">Thứ 6</th>
                        <th class="text-center">Thứ 7</th>
                    </tr>
                </thead>
                <tbody>
                <?php 
                    for ($i=0;$i<=8;$i++){
                        $tiet=$i;
                        $tiet++;
                        echo'</tr>
                                <td class="text-center">'.$tiet.'</td>';
                        for($j=0;$j<=5;$j++)
                        {   echo '<td class="text-center">'.$mang[$i][$j].'</td>';
                        }
                        echo '</tr>';
                    }
                ?>
                </tbody>
            </table>    

