<?php 
declare(strict_types=1);
ini_set('display_errors', 'TRUE');
error_reporting(-1); // MAXIMUM ERROR REPORTING
$trave="";
include_once("cosodulieu.php");
$ketnoi= new mysqli($db_host,$db_user,$db_pass,$db_name);
mysqli_set_charset($ketnoi, 'UTF8');
$hocphantinchi=0;
if (isset($_SESSION['user']))
{       
        // Phần này lấy ID của user
        $tai_khoan=$_SESSION['user'];
        $lay_id=$ketnoi->query("SELECT `ID` FROM `sinhvien` WHERE `user` ='$tai_khoan'");
        if ($lay_id && $lay_id->num_rows>0){
            while($lay_id_array=$lay_id->fetch_assoc())
            {
                $id=$lay_id_array['ID'];
            }
        } else $id="DKHP00";
        $tim_hp_trong_kehoachhoctap=$ketnoi->query("SELECT * FROM `kehoachhoctap` WHERE `ID`='$id'");
        // Hết phần lấy ID user
        if ($tim_hp_trong_kehoachhoctap && $tim_hp_trong_kehoachhoctap ->num_rows >0 )
        {   
            while ($row = $tim_hp_trong_kehoachhoctap->fetch_assoc()) {
                    $hp_cantim=$row['mahp'];
                    $tim_hp_trong_dkhocphan=$ketnoi->query("SELECT * FROM `dkhocphan` WHERE `ID`='$id' AND `mahp`='$hp_cantim'");
                    if ($tim_hp_trong_dkhocphan && $tim_hp_trong_dkhocphan->num_rows==0){   
                    // In ra các học phần có trong khht mà chưa đăng ký
                        $dangky='<th class="text-center">
                        <div class="btn-switch btn-switch-inverse">
                                <input onClick="dangky('."'dangky_hocphan.php?mahp=".$row['mahp']."','dangkyhocphan','scrollbars=1'".')" type="checkbox" id="dkhocphan_'.$row['mahp'].'">
                                <label for="dkhocphan_'.$row['mahp'].'" class="btn btn-xs btn-rounded btn-inverse waves-effect waves-light">
                                    <em class="glyphicon glyphicon-ok"></em>
                                    <strong> Click để đăng ký</strong>
                                </label>
                        </div></th>';
                    }    
                    // Hết In ra các học phần có trong khht mà chưa đăng ký
                    //In ra các học phần có trong khht mà đã đăng ký
                    else
                    {   $dangky='<th class="text-center">
                        <div class="btn-switch btn-switch-success">
                                <label for="hocphan_'.$row['mahp'].'" class="btn btn-xs btn-rounded btn-success waves-effect waves-light">
                                    <em class="glyphicon glyphicon-ok"></em>
                                    <strong> Đã đăng ký</strong>
                                </label>
                        </div></th>';
                    }
                    //Hết In ra các học phần có trong khht mà  đăng ký
                    $mahp=$row['mahp'];
                    ///Phần dưới đây lấy chi tiết của học phần
                    $tim_mahp_de_in_ra_table=$ketnoi->query("SELECT * FROM `dmhocphan` WHERE `mahp`='$mahp'");
                    if ($tim_mahp_de_in_ra_table && $tim_mahp_de_in_ra_table->num_rows>0)
                    {
                        while ($lay_ra=$tim_mahp_de_in_ra_table->fetch_assoc())
                        {
                            $trave=$trave.'<tr><th class="text-center">'.$lay_ra['mahp'].'</th><th>'.$lay_ra['tenhocphan'].'</th><th class="text-center">'.$lay_ra['tinchi'].'</th>'.$dangky;
                        }
                    }
                } 
        }
        $trave=$trave.'</tr>';
        // Toàn bộ phân trên là phần Đăng ký học phần

        // In ra các học phần đã đăng ký thành công
        $trave1="";
        $stt=0;
        $result = $ketnoi->query("SELECT * FROM `dkhocphan` WHERE `ID`='$id'");
        if ($result && $result ->num_rows >0 )
        {   
            while ($in = $result->fetch_assoc()) {
                    $mahp=$in['mahp'];
                    $lay_ten_hoc_phan= $ketnoi->query("SELECT `tenhocphan` FROM `dmhocphan` WHERE `mahp`='$mahp'");
                    if ($lay_ten_hoc_phan && $lay_ten_hoc_phan->num_rows>0)
                    {   while ($tv_tenhocphan =$lay_ten_hoc_phan->fetch_assoc())
                        $tenhocphan=$tv_tenhocphan['tenhocphan'];
                    }
                    $stt++;
                    $dangky='<th class="text-center"><button onClick="xoahocphan('."'".$in['mahp']."'".')" class="btn btn-danger btn-xs" href="#"><span class="glyphicon glyphicon-edit"></span> Xoá</button></th>';
                    $trave1=$trave1.'<tr><th class="text-center">'.$stt.'</th><th class="text-center">'.$in['kyhieu'].'</th><th class="text-center">'.$in['mahp'].'</th><th>'.$tenhocphan.'</th><th class="text-center">'.$in['tinchi'].'</th>'.$dangky;
                    $hocphantinchi=$hocphantinchi+(int)$in['tinchi'];
            }
        }
} else 
{
    $trave='<div class="alert alert-danger alert-dismissible fade in text-center" role="alert"> Vui lòng đăng nhập để tiếp tục bạn nhé!
    </div>';
    $trave1=$trave;
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="Trang web giả lập đăng ký học phần CTU">
        <link rel="shortcut icon" href="assets/images/favicon.ico">
        <title>Đăng ký học phần</title>
                <!-- DataTables -->
        <link href="datatables/jquery.dataTables.min.css" rel="stylesheet" type="text/css"/>
        <link href="datatables/buttons.bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="datatables/fixedHeader.bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="datatables/responsive.bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="datatables/scroller.bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="datatables/dataTables.colVis.css" rel="stylesheet" type="text/css"/>
        <link href="datatables/dataTables.bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="datatables/fixedColumns.dataTables.min.css" rel="stylesheet" type="text/css"/>
        <link href="responsive-table/css/rwd-table.min.css" rel="stylesheet" type="text/css" media="screen">
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/core.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/components.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/pages.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/menu.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/responsive.css" rel="stylesheet" type="text/css" />
        <link href="assets/sweetalert/sweet-alert.css" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="../plugins/switchery/switchery.min.css">
        <script src="assets/js/modernizr.min.js"></script>
<script type="text/javascript">
//<![CDATA[
function dangky(Url,WindowName,extras,scrollbars) {
var wide = 900;
var high = 600;
var additional= 'WindowName';
var top = (screen.height-high)/2;
var leftside = 0; 
newWindow=window.open(''+ Url + '',''+ WindowName + '','width=' + wide + ',height=' + high + ',top=' + top + ',left=' + leftside + ',features=' + additional + '' + ',scrollbars=1');
newWindow.focus();
newWindow.onbeforeunload = function () {
    setTimeout(function(){
        location.replace("dangkyhocphan.php");
                        }, 500);
}
};
</script>
    </head>
    <body>

<?php include_once("menu.php") ?>

        <div class="wrapper">
            <div class="container">

                <!-- Page-Title -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-title-box">
                            <h4 class="page-title">Đăng ký học phần</h4>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="card-box table-responsive">
                            <h3 class="text-center"> ĐĂNG KÝ CÁC HỌC PHẦN </h3>
                            <div class="container">
                                <div>
                                <div class="row">
                                    <div class="col-md-9">
                                        <div class="grid-container">
                                        <table class="table table-striped table-bordered">
                                            <thead>
                                                <tr>
                                                    <th class="text-center">Mã học phần</th>
                                                    <th class="text-center">Tên học phần</th>
                                                    <th class="text-center">Số tín chỉ</th>
                                                    <th class="text-center">Trạng thái</th>
                                                </tr>
                                            </thead>
                                                <?php echo $trave;?>
                                        </table>    
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="grid-container">
                                            <?php 
                                            include_once("tao_thoi_khoa_bieu.php");
                                            ?>
                                            <?php echo "<h4>Tổng số học phần tín chỉ đã đăng ký: ".$hocphantinchi."</h4>";?>
                                        </div>
                                    </div>
                                </div>
                                <!-- <iframe src="tao_thoi_khoa_bieu.php" width="370px" height="270px"></iframe> -->
                                </div>
                            </div>
                            <!--Bảng in học phần đã đăng ký-->
                            <h3 class="text-center"> CÁC HỌC PHẦN ĐÃ ĐĂNG KÝ THÀNH CÔNG </h3>
                            <div class="container">
                                <div>
                                <table id="#quanli-hocphan"class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th class="text-center">STT</th>
                                        <th class="text-center">Ký hiệu lớp</th>
                                        <th class="text-center">Mã học phần</th>
                                        <th class="text-center">Tên học phần</th>
                                        <th class="text-center">Số tín chỉ</th>
                                        <th class="text-center">Xoá học phần</th>
                                    </tr>
                                </thead>
                                    <?php echo $trave1;?>
                                </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
                <!-- Footer -->
                <footer class="footer text-right">
                    <div class="container">
                        <div class="row">
                            <div class="col-xs-12 text-center">
                                © 2020. Lieu Tuan Vu B1906810. Có sử dụng nội dung từ trang Quản lí đào tạo CTU
                            </div>
                        </div>
                    </div>
                </footer>
                <!-- End Footer -->

            </div> <!-- end container -->
        </div>
        <!-- end wrapper -->


        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/detect.js"></script>
        <script src="assets/js/fastclick.js"></script>
        <script src="assets/js/jquery.blockUI.js"></script>
        <script src="assets/js/waves.js"></script>
        <script src="assets/js/jquery.slimscroll.js"></script>
        <script src="assets/js/jquery.scrollTo.min.js"></script>
        <script src="assets/sweetalert/sweet-alert.min.js"></script>
        <script src="switchery/switchery.min.js"></script>

        <script src="datatables/jquery.dataTables.min.js"></script>
        <script src="datatables/dataTables.bootstrap.js"></script>

        <script src="plugins/datatables/dataTables.buttons.min.js"></script>
        <script src="datatables/buttons.bootstrap.min.js"></script>
        <script src="datatables/jszip.min.js"></script>
        <script src="datatables/pdfmake.min.js"></script>
        <script src="datatables/vfs_fonts.js"></script>
        <script src="datatables/buttons.html5.min.js"></script>
        <script src="datatables/buttons.print.min.js"></script>
        <script src="datatables/dataTables.fixedHeader.min.js"></script>
        <script src="datatables/dataTables.keyTable.min.js"></script>
        <script src="datatables/dataTables.responsive.min.js"></script>
        <script src="datatables/responsive.bootstrap.min.js"></script>
        <script src="datatables/dataTables.scroller.min.js"></script>
        <script src="datatables/dataTables.colVis.js"></script>
        <script src="datatables/dataTables.fixedColumns.min.js"></script>

        <!-- init -->
        <script src="assets/pages/jquery.datatables.init.js"></script>

        <!-- App js -->
        <script src="assets/js/jquery.core.js"></script>
        <script src="assets/js/jquery.app.js"></script>

        <script type="text/javascript">
            $(document).ready(function () {
                $('#datatable').dataTable();
                $('#datatable-keytable').DataTable({keys: true});
                $('#datatable-responsive').DataTable();
                $('#datatable-colvid').DataTable({
                    "dom": 'C<"clear">lfrtip',
                    "colVis": {
                        "buttonText": "Change columns"
                    }
                });
                $('#datatable-scroller').DataTable({
                    ajax: "../plugins/datatables/json/scroller-demo.json",
                    deferRender: true,
                    scrollY: 380,
                    scrollCollapse: true,
                    scroller: true
                });
                var table = $('#datatable-fixed-header').DataTable({fixedHeader: true});
                var table = $('#datatable-fixed-col').DataTable({
                    scrollY: "300px",
                    scrollX: true,
                    scrollCollapse: true,
                    paging: false,
                    fixedColumns: {
                        leftColumns: 1,
                        rightColumns: 1
                    }
                });
            });
            TableManageButtons.init();

        </script>
    <script>
        function xoahocphan(x){
            
            if(confirm("Bạn muốn xoá học phần này?") == true){
                location.replace("xoa_hp.php?maph="+x);
            }
        }
    </script>
    </body>
</html>
<?php $ketnoi->close();
?>