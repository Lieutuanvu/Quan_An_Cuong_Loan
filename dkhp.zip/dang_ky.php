<?php
include_once("cosodulieu.php");
$ketnoi= new mysqli($db_host,$db_user,$db_pass,$db_name);
$taikhoan="";
$matkhau="";
$thongbao="";
$chuyen_huong="";
$soluong=0;
if ((!isset($_POST['taikhoan']) && !isset($_POST['matkhau']))){
    $thongbao="hay_dang_ky();";
} else if((!isset($_POST['taikhoan']) || !isset($_POST['matkhau']))){
    $thongbao="nhap_day_du();";
} else{ 
    $taikhoan=$_POST['taikhoan'];
    $matkhau=$_POST['matkhau'];
    $dem_soluong_user=$ketnoi->query("SELECT * FROM `sinhvien` ORDER BY `stt` ASC");
    if ($dem_soluong_user && $dem_soluong_user->num_rows>0)
    {
        while ($dem=$dem_soluong_user->fetch_assoc())
        {
            $soluong++;
        }
    }
    $kiemtra_tontai_taikhoan=$ketnoi->query("SELECT * FROM `sinhvien` WHERE `user`='$taikhoan'");
    if(mysqli_num_rows($kiemtra_tontai_taikhoan)>0){
        $thongbao="taikhoan_tontai();";
    } else {
            $soluong++;
            $ID_user="DKHP0".$soluong;
            $pass = md5($matkhau);
            $dangky=$ketnoi->query("INSERT INTO `sinhvien`(`stt`, `ID`, `user`, `pass`) VALUES ('$soluong','$ID_user','$taikhoan','$pass')");
            if ($dangky){
                $chuyen_huong='<meta http-equiv="refresh" content="5 url=dang_nhap.php" >';
                $thongbao="dk_tk_thanhcong();";
                $taikhoan="";
                $matkhau="";
            } else {
                $thongbao="co_loi_xayra();";}
    }
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="Trang web giả lập đăng ký học phần, hỗ trợ sinh viên - Liêu Tuấn Vũ CTU">
        <link rel="shortcut icon" href="assets/images/favicon.ico">
        <title>Đăng ký tài khoản</title>
        <!-- App css -->
        <link href="assets/toastr/toastr.min.css" rel="stylesheet" type="text/css" />
        <?php echo $chuyen_huong?>
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/core.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/components.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/pages.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/menu.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/responsive.css" rel="stylesheet" type="text/css" />

    </head>


    <body class="bg-transparent">

        <!-- HOME -->
        <section>
            <div class="container-alt">
                <div class="row">
                    <div class="col-sm-12">

                        <div class="wrapper-page">
                            <div class="m-t-40 account-pages">
                                <div class="text-center account-logo-box">
                                    <h2 class="text-uppercase">
                                        <a href="dang_ky.php" class="text-muted">
                                        Đăng ký tài khoản
                                        </a>
                                    </h2>
                                    <!--<h4 class="text-uppercase font-bold m-b-0">Sign In</h4>-->
                                </div>
                                <div class="account-content">
                                    <form class="form-horizontal" action="dang_ky.php" method="post">
                                        <div class="form-group ">
                                            <div class="col-xs-12">
                                                <input class="form-control" name="taikhoan" type="text" required="" placeholder="Tài khoản" value="<?php echo $taikhoan;?>">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-xs-12">
                                                <input class="form-control" name="matkhau" type="password" required="" placeholder="Mật khẩu" value="<?php echo $matkhau;?>">
                                            </div>
                                        </div>

                                        <div class="form-group account-btn text-center m-t-10">
                                            <div class="col-xs-12">
                                                <button class="btn w-md btn-danger btn-bordered waves-effect waves-light" type="submit">Đăng ký</button>
                                            </div>
                                        </div>

                                    </form>

                                    <div class="clearfix"></div>

                                </div>
                            </div>
                            <!-- end card-box-->


                            <div class="row m-t-50">
                                <div class="col-sm-12 text-center">
                                    <p class="text-muted"><a href="dang_nhap.php" class="text-muted m-l-5"><b>Bấm vào đây để đăng nhập hệ thống!</b></a></p>
                                </div>
                            </div>

                        </div>
                        <!-- end wrapper -->

                    </div>
                </div>
            </div>
          </section>
          <!-- END HOME -->

        <script>
            var resizefunc = [];
        </script>

        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/detect.js"></script>
        <script src="assets/js/fastclick.js"></script>
        <script src="assets/js/jquery.blockUI.js"></script>
        <script src="assets/js/waves.js"></script>
        <script src="assets/js/jquery.slimscroll.js"></script>
        <script src="assets/js/jquery.scrollTo.min.js"></script>

        <!-- App js -->
        <script src="assets/js/jquery.core.js"></script>
        <script src="assets/js/jquery.app.js"></script>
        <script src="assets/toastr/toastr.min.js"></script>
        <script src="assets/toastr/jquery.toastr.js"></script>
        <script>
            function dk_tk_thanhcong(){
                toastr["success"]("Bạn đã đăng ký thành công, hãy đăng nhập để thực hành đăng ký học phần nhé!", "Thành công");

                toastr.options = {
                "closeButton": false,
                "debug": false,
                "newestOnTop": false,
                "progressBar": false,
                "positionClass": "toast-top-center",
                "preventDuplicates": false,
                "onclick": null,
                "showDuration": "300",
                "hideDuration": "1000",
                "timeOut": "20000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
                }
            }
            function taikhoan_tontai(){
                toastr["error"]("Tài khoản bạn chọn đã tồn tại trên hệ thống, vui lòng chọn tài khoản khác hoặc đăng nhập bằng tài khoản đó!", "Tài khoản tồn tại")

                toastr.options = {
                "closeButton": false,
                "debug": false,
                "newestOnTop": false,
                "progressBar": false,
                "positionClass": "toast-top-center",
                "preventDuplicates": false,
                "onclick": null,
                "showDuration": "300",
                "hideDuration": "1000",
                "timeOut": "5000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
                }
            }
            function co_loi_xayra(){
                toastr["error"]("Đã có lỗi xảy ra, bạn vui lòng thử lại sau nhé :(", "Đã có lỗi xảy ra")

                toastr.options = {
                "closeButton": false,
                "debug": false,
                "newestOnTop": false,
                "progressBar": false,
                "positionClass": "toast-top-center",
                "preventDuplicates": false,
                "onclick": null,
                "showDuration": "300",
                "hideDuration": "1000",
                "timeOut": "5000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
                }
            }
            function nhap_day_du(){
                toastr["error"]("Nhập đầy đủ tài khoản và mật khẩu để có thể đăng ký bạn nhé! :(", "Hãy nhập đầy đủ tài khoản và mật khẩu")

                toastr.options = {
                "closeButton": false,
                "debug": false,
                "newestOnTop": false,
                "progressBar": false,
                "positionClass": "toast-top-center",
                "preventDuplicates": false,
                "onclick": null,
                "showDuration": "300",
                "hideDuration": "1000",
                "timeOut": "5000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
                }
            }
            function hay_dang_ky(){
                toastr["info"]("Hãy đăng ký tài khoản để thử đăng ký học phần cho quen bạn nhé ^^", "Hãy đăng ký")

                toastr.options = {
                "closeButton": false,
                "debug": false,
                "newestOnTop": false,
                "progressBar": false,
                "positionClass": "toast-top-center",
                "preventDuplicates": false,
                "onclick": null,
                "showDuration": "300",
                "hideDuration": "1000",
                "timeOut": "5000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
                }
            }
            <?php echo $thongbao;?>
        </script>

    </body>
</html>