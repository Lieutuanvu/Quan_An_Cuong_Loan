<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta charset="UTF-8">
	 <!-- <meta http-equiv="refresh" content="0 url=dangkyhocphan.php" > -->
	<title></title>
</head>
<body>
	<?php 
	include_once("cosodulieu.php");
	$ketnoi = new mysqli($db_host, $db_user, $db_pass, $db_name);
	mysqli_set_charset($ketnoi, 'UTF8');
if (isset($_SESSION['user']))
{					// Phần này lấy ID của user
					$tai_khoan=$_SESSION['user'];
					$lay_id=$ketnoi->query("SELECT `ID` FROM `sinhvien` WHERE `user` ='$tai_khoan'");
					if ($lay_id && $lay_id->num_rows>0){
						while($lay_id_array=$lay_id->fetch_assoc())
						{
							$id=$lay_id_array['ID'];
						}
					}
					$tim_hp_trong_kehoachhoctap=$ketnoi->query("SELECT * FROM `kehoachhoctap` WHERE `ID`='$id'");
					// Hết phần lấy ID user
	if (!isset($_GET['maph']) || !isset($_GET['stc']) || !isset($_GET['kyhieu']))
	{	
		echo "Chẳng có gì ở trang này cả, bạn không được truy cập vào trang này đâu ^^";
		die();
	}
	else 
	{
		$sohp=0;
		$laystt=$ketnoi->query("SELECT `stt` FROM `dkhocphan` ORDER BY `stt` ASC");
		if ($laystt && $laystt ->num_rows>0){
			while ($stt=$laystt->fetch_assoc())
			{
				$sohp=$stt['stt'];
			}
		}
		else {
			$sohp=0;
		}
		include_once("chay_thu_tao_mang.php");//include file này vào để tạo một cái mảng thời khoá biểu trên máy chủ
		$sohp++;
		$mahp=$_GET['maph'];
		$tinchi=$_GET['stc'];
		$kyhieu=$_GET['kyhieu'];
		$tongtc=0;
		$sisoconlai=0;
		$kt_hocphan=0;
				// Kiểm tra sự trùng thời khoá biểu tại đây
				$lay_thoi_gian_hoc=$ketnoi->query("SELECT `thu`, `sotiet`,`tietbd` FROM `hocphan` WHERE `kyhieu`='$kyhieu' AND `mahocphan`='$mahp' ");
				if ($lay_thoi_gian_hoc && $lay_thoi_gian_hoc->num_rows>0)
				{
					while($lay_thoi_gian_hoc_kq=$lay_thoi_gian_hoc->fetch_assoc())
					{
						$thu=$lay_thoi_gian_hoc_kq['thu'];
						$tietbd=$lay_thoi_gian_hoc_kq['tietbd'];
						$sotiet=$lay_thoi_gian_hoc_kq['sotiet'];
						
						// Tạo mảng đánh dấu ở bên dưới 
						$thu_sosanh=$thu - 2;
						$tietbd_sosanh=$tietbd-1;
						$giam_sotiet=$sotiet;
						$dem=1;
						for ($i=0;$i<=8;$i++){ // biến $i là số tiết trong ngày, tiết 1 => i=0, tiết 2 => i=1, tiết 3 => i=2,...
							if ($i==$tietbd_sosanh){
									$tietbd_sosanh++;
									$giam_sotiet--;
									for ($j=0;$j<=5;$j++) // biển $j là thứ trong tuần thứ 2 => j=0, thứ 3 => j=1, thứ 4 => j=2,...
									{       
											if (($dem<=$sotiet) && ($j==$thu_sosanh) )
											{   if ($mang[$i][$j]!="00000"){$thong_bao_trunglop= "Trung";break;}
												else
												{   $mang[$i][$j]=$mahp;
													$dem++;
												}
											}
									}
									if ($giam_sotiet==0) { break;}
							}
						}
						// Kết thúc tạo mảng đánh dấu
					}
				}
						// Kiểm tra sự trùng thời khoá biểu tại đây
		if ($thong_bao_trunglop=="Trung"){
			header('Location: canh_bao_trung_thoi_khoa_bieu.php');
			die();
		}else
		{
			$sql="INSERT INTO `dkhocphan`( `stt`,`mahp`, `kyhieu`,`tinchi`,`ID`) VALUES ('$sohp','$mahp','$kyhieu','$tinchi','$id')";
			$kiemtra_sotinchi_behon20=$ketnoi->query("SELECT `tinchi`, `mahp` FROM `dkhocphan` WHERE `ID`='$id'");
			if ($kiemtra_sotinchi_behon20 && $kiemtra_sotinchi_behon20 ->num_rows>0){
				while ($cong=$kiemtra_sotinchi_behon20->fetch_assoc())
				{
					$tongtc=$tongtc+(int)$cong['tinchi'];
					if ($mahp==$cong['mahp']){
						$kt_hocphan=1;
					}
				}
			}
			$tcdangky=$tongtc+(int)$tinchi;
			if ($kt_hocphan==0){
					if ($tcdangky<=20){
						$kq=mysqli_query($ketnoi,$sql);
						if ($kq) {
							$lay_siso=$ketnoi->query("SELECT `sisoconlai` FROM `hocphan` WHERE `mahocphan` = '$mahp' AND `kyhieu`='$kyhieu'");
							if ($lay_siso && $lay_siso->num_rows>0)
							{
								while ($ss_conlai=$lay_siso->fetch_assoc()){
									$sisoconlai=(int)$ss_conlai['sisoconlai'];
								}
							}
							$sisoconlai--;
							$capnhat_siso=$ketnoi->query("UPDATE `hocphan` SET `sisoconlai`='$sisoconlai' WHERE `mahocphan`='$mahp' AND `kyhieu`='$kyhieu'");
							if ($capnhat_siso){
								header("dangkyhocphan.php");
								echo "<div id='daxong'>Xong</div>";
							}

						}
					}
					else {header('Location: canh_bao.php');}
			}
			else {
				echo "Học phần này đã được đăng ký, vui lòng không đăng ký lại!";
			};
		}
	}
} else
echo "Bạn vui lòng đăng nhập để thực hành đăng ký học phần nhé ^^";
?>
</body>
<script type="text/javascript">
	var kt=document.getElementById('daxong').innerText;
	if (kt=='Xong')
	{	
		close();
	}
</script>
</html>