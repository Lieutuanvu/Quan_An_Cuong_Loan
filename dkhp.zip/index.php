<?php 
$trave="";
$tenmon="";
$tinchi="";
include_once("cosodulieu.php");
$timkiem="";
$ketnoi= new mysqli($db_host,$db_user,$db_pass,$db_name);
mysqli_set_charset($ketnoi, 'UTF8');

if (isset($_POST['bamtim'])){
    $timkiem = addslashes($_POST['mahp']);
    if (empty($timkiem)){
        $trave= "<tr>Nhập mã học phần để tìm kiếm học phần đó.</tr>";
    } else
    {  
        $mahp=$_POST['mahp'];
        $mahp = chop($mahp," ");
        $result = $ketnoi->query("SELECT * FROM `hocphan` WHERE `mahocphan` = '$mahp'");
        if ($result && $result ->num_rows >0 )
        {   
            while ($row = $result->fetch_assoc()) {
                $trave=$trave.'<tr><th class="text-center">'.$row['stt'].'</th><th class="text-center">'.$row['kyhieu'].'</th><th class="text-center">'.$row['thu'].'</th><th class="text-center">'.$row['tietbd'].'</th><th class="text-center">'.$row['sotiet'].'</th><th class="text-center">'.$row['phong'].'</th><th class="text-center">'.$row['siso'].'</th><th class="text-center">'.$row['sisoconlai'].'</th><th>'.$row['tuanhoc'].'</th><th class="text-center">'.$row['lophp'].'</th></tr>';
                $tenmon=$row['tenhocphan'];
                $tinchi=$row['tinchi'];
            }
            $tenmon = "Tên học phần: ".$tenmon;
            $tinchi = "Số tin chỉ: ".$tinchi;
        }
    };
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="Trang web giả lập đăng ký học phần CTU">
        <link rel="shortcut icon" href="assets/images/favicon.ico">
        <title>Tra cứu học phần</title>
                <!-- DataTables -->
        <link href="datatables/jquery.dataTables.min.css" rel="stylesheet" type="text/css"/>
        <link href="datatables/buttons.bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="datatables/fixedHeader.bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="datatables/responsive.bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="datatables/scroller.bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="datatables/dataTables.colVis.css" rel="stylesheet" type="text/css"/>
        <link href="datatables/dataTables.bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="datatables/fixedColumns.dataTables.min.css" rel="stylesheet" type="text/css"/>
        <link href="responsive-table/css/rwd-table.min.css" rel="stylesheet" type="text/css" media="screen">
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/core.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/components.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/pages.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/menu.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/responsive.css" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="../plugins/switchery/switchery.min.css">
        <script src="assets/js/modernizr.min.js"></script>

    </head>
    <body>


    <?php include_once("menu.php") ?>


        <div class="wrapper">
            <div class="container">

                <!-- Page-Title -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-title-box">
                            <h4 class="page-title">Tra cứu học phần</h4>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="card-box table-responsive">
                                    <form role="search" method="post" action="./">
                                                <!-- <input type="text" name="mahp" class="form-control" placeholder="Tìm kiếm học phần..."> -->
                                                <!-- <button type="submit" name="bamtim" class="btn btn-custom waves-effect waves-light btn-md">Tìm</button> -->
                                    <div class="col-sm-6 col-sm-offset-3">
                                        <div class="form-group search-box">
                                            <input type="text" name="mahp" value="<?php $timkiem=chop($timkiem," "); echo strtoupper($timkiem);?>" class="form-control" placeholder="Tìm kiếm học phần...">
                                            <button type="submit" name="bamtim" class="btn btn-search"><i class="fa fa-search"></i></button>
                                        </div>
                                        <h4><?php echo $tenmon;?></h4>
                                        <h4><?php echo $tinchi;?></h4>    
                                    </div>
                                    </form>
                            </br></hr>
                            <table id="datatable-buttons" class="table table-striped table-bordered">
                                <thead>
                                <tr>
                                    <th class="text-center">STT</th>
                                    <th class="text-center">Ký hiệu	</th>
                                    <th class="text-center">Thứ</th>
                                    <th class="text-center">Tiết BĐ	</th>
                                    <th class="text-center">Số tiết	</th>
                                    <th class="text-center">Phòng</th>
                                    <th class="text-center">Sỉ số</th>
                                    <th class="text-center">Sỉ số còn lại</th>
                                    <th>Tuần học</th>
                                    <th class="text-center">Lớp học phần</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php 
                                echo $trave;
                                // if (isset($_POST['bamtim'])){
                                //     $timkiem = addslashes($_POST['mahp']);
                                //     if (empty($timkiem)){
                                //         echo "<tr>Nhập mã học phần để tìm kiếm học phần đó.</tr>";
                                //     } else
                                //     {  
                                //         $mahp=$_POST['mahp'];
                                //         $result = $ketnoi->query("SELECT * FROM `hocphan` WHERE `mahocphan` = '$mahp'");
                                //         if ($result && $result ->num_rows >0 )
                                //         { 
                                //             while ($row = $result->fetch_assoc()) {
                                //                 echo '<tr><th>'.$row['stt'].'</th>';;
                                //                 echo '<th>'.$row['kyhieu'].'</th>';;
                                //                 echo '<th>'.$row['thu'].'</th>';;
                                //                 echo '<th>'.$row['tietbd'].'</th>';;
                                //                 echo '<th>'.$row['sotiet'].'</th>';;
                                //                 echo '<th>'.$row['phong'].'</th>';;
                                //                 echo '<th>'.$row['siso'].'</th>';;
                                //                 echo '<th>'.$row['sisoconlai'].'</th>';;
                                //                 echo '<th>'.$row['tuanhoc'].'</th>';;
                                //                 echo '<th>'.$row['lophp'].'</th></tr>';
                                //                 }
                                //         }
                                //     };
                                // }
                                // ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!-- Footer -->
                <footer class="footer text-right">
                    <div class="container">
                        <div class="row">
                            <div class="col-xs-12 text-center">
                                © 2020. Lieu Tuan Vu B1906810. Có sử dụng nội dung từ trang Quản lí đào tạo CTU
                            </div>
                        </div>
                    </div>
                </footer>
                <!-- End Footer -->

            </div> <!-- end container -->
        </div>
        <!-- end wrapper -->


        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/detect.js"></script>
        <script src="assets/js/fastclick.js"></script>
        <script src="assets/js/jquery.blockUI.js"></script>
        <script src="assets/js/waves.js"></script>
        <script src="assets/js/jquery.slimscroll.js"></script>
        <script src="assets/js/jquery.scrollTo.min.js"></script>
        <script src="switchery/switchery.min.js"></script>

        <script src="datatables/jquery.dataTables.min.js"></script>
        <script src="datatables/dataTables.bootstrap.js"></script>

        <script src="plugins/datatables/dataTables.buttons.min.js"></script>
        <script src="datatables/buttons.bootstrap.min.js"></script>
        <script src="datatables/jszip.min.js"></script>
        <script src="datatables/pdfmake.min.js"></script>
        <script src="datatables/vfs_fonts.js"></script>
        <script src="datatables/buttons.html5.min.js"></script>
        <script src="datatables/buttons.print.min.js"></script>
        <script src="datatables/dataTables.fixedHeader.min.js"></script>
        <script src="datatables/dataTables.keyTable.min.js"></script>
        <script src="datatables/dataTables.responsive.min.js"></script>
        <script src="datatables/responsive.bootstrap.min.js"></script>
        <script src="datatables/dataTables.scroller.min.js"></script>
        <script src="datatables/dataTables.colVis.js"></script>
        <script src="datatables/dataTables.fixedColumns.min.js"></script>

        <!-- init -->
        <script src="assets/pages/jquery.datatables.init.js"></script>

        <!-- App js -->
        <script src="assets/js/jquery.core.js"></script>
        <script src="assets/js/jquery.app.js"></script>

        <script type="text/javascript">
            $(document).ready(function () {
                $('#datatable').dataTable();
                $('#datatable-keytable').DataTable({keys: true});
                $('#datatable-responsive').DataTable();
                $('#datatable-colvid').DataTable({
                    "dom": 'C<"clear">lfrtip',
                    "colVis": {
                        "buttonText": "Change columns"
                    }
                });
                $('#datatable-scroller').DataTable({
                    ajax: "../plugins/datatables/json/scroller-demo.json",
                    deferRender: true,
                    scrollY: 380,
                    scrollCollapse: true,
                    scroller: true
                });
                var table = $('#datatable-fixed-header').DataTable({fixedHeader: true});
                var table = $('#datatable-fixed-col').DataTable({
                    scrollY: "300px",
                    scrollX: true,
                    scrollCollapse: true,
                    paging: false,
                    fixedColumns: {
                        leftColumns: 1,
                        rightColumns: 1
                    }
                });
            });
            TableManageButtons.init();

        </script>


    </body>
</html>