<?php 
for ($i=0;$i<=8;$i++){ // biến $i là số tiết trong ngày, tiết 1 => i=0, tiết 2 => i=1, tiết 3 => i=2,...
    for ($j=0;$j<=5;$j++) // biển $j là thứ trong tuần thứ 2 => j=0, thứ 3 => j=1, thứ 4 => j=2,...
    { 
        $mang[$i][$j]='000000';
    }
}
/*-- Ở trên là tạo mảng 0 */
?>