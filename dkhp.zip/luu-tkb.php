<?php
include_once("cosodulieu.php");
$ketnoi= new mysqli($db_host,$db_user,$db_pass,$db_name);
mysqli_set_charset($ketnoi, 'UTF8');
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="Trang web giả lập đăng ký học phần CTU">
        <link rel="shortcut icon" href="assets/images/favicon.ico">
        <title>Lưu thời khoá biểu</title>
                <!-- DataTables -->
        <link href="responsive-table/css/rwd-table.min.css" rel="stylesheet" type="text/css" media="screen">
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/core.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/components.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/pages.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/menu.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/responsive.css" rel="stylesheet" type="text/css" />
        <link href="assets/sweetalert/sweet-alert.css" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="../plugins/switchery/switchery.min.css">
        <script src="assets/js/modernizr.min.js"></script>

    </head>
    <body>


        <!-- Navigation Bar-->
        <?php include_once("menu.php") ?>

        <div class="wrapper">
            <div class="container">

                <!-- Page-Title -->
                
                <div class="row">
                    <div class="col-sm-12">
                        <div class="card-box table-responsive">
                            </br></hr>
                            <div class="container">
                            <?php 
                            if (isset($_SESSION['user']))
                            {
                                if (isset($_POST['ten']) && isset($_POST['kyhieu'])){
                                    $data1=str_replace("'",'"',$_POST['ten']);
                                    $data2=str_replace("'",'"',$_POST['kyhieu']);
                                    $n=count($data1);
                                    $url=md5(date("Y/m/d/h/m/i"));
                                    $so_huu=$_SESSION['user'];
                                    $luu=$ketnoi->query("INSERT INTO `sep_tkb`( `mahp`, `kyhieu`,`url`,`so_huu`) VALUES ('$data1','$data2','$url','$so_huu')");
                                    if ($luu){
                                        $data1=unserialize($data1);
                                    $data2=unserialize($data2); 
                                    $n=count($data1);
                                    for ($i=0;$i<=$n;$i++){
                                        
                                        $lay_thoi_gian_hoc=$ketnoi->query("SELECT `thu`, `sotiet`,`tietbd` FROM `hocphan` WHERE `kyhieu`='$data2[$i]' AND `mahocphan`='$data1[$i]' ");
                                        if ($lay_thoi_gian_hoc && $lay_thoi_gian_hoc->num_rows>0)
                                        {
                                            while($lay_thoi_gian_hoc_kq=$lay_thoi_gian_hoc->fetch_assoc())
                                            {
                                                $thu=$lay_thoi_gian_hoc_kq['thu'];
                                                $tietbd=$lay_thoi_gian_hoc_kq['tietbd'];
                                                $sotiet=$lay_thoi_gian_hoc_kq['sotiet'];
                                                $tietbd_sosanh=$tietbd-1;
                                                if ($thu == 2){$thu_sosanh	= 0+($tietbd_sosanh*6);}
                                                if ($thu == 3){$thu_sosanh	= 1+($tietbd_sosanh*6);}
                                                if ($thu == 4){$thu_sosanh	= 2+($tietbd_sosanh*6);}
                                                if ($thu == 5){$thu_sosanh	= 3+($tietbd_sosanh*6);}
                                                if ($thu == 6){$thu_sosanh	= 4+($tietbd_sosanh*6);}
                                                if ($thu == 7){$thu_sosanh	= 5+($tietbd_sosanh*6);}
                                                $dem=0;
                                                for ($h=0;$h<=53;$h++){
                                                    if ($h==$thu_sosanh || ($h-$thu_sosanh)==($dem*6)){
                                                        if ($sotiet>0) 
                                                        {
                                                            $in_tkb[$h]=$data1[$i].'-'.$data2[$i];
                                                            $sotiet--;
                                                            $dem++;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    
                                    echo'
                                    
                                    <table class="table table-bordered m-0">
                                                <thead>
                                                    <tr>
                                                        <th class="text-center">Tiết</th>
                                                        <th class="text-center">Thứ 2</th>
                                                        <th class="text-center">Thứ 3</th>
                                                        <th class="text-center">Thứ 4</th>
                                                        <th class="text-center">Thứ 5</th>
                                                        <th class="text-center">Thứ 6</th>
                                                        <th class="text-center">Thứ 7</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                <tr>
                                                <th class="text-center" scope="row">1</th>';
                                                for ($k=0;$k<=5;$k++){ 
                                                                echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                                }
                                    echo   '</tr>
                                            <tr>
                                                <th class="text-center" scope="row">2</th>';
                                                for ($k=6;$k<=11;$k++){ 
                                                                echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                                }
                                    echo   '</tr>
                                            <tr>
                                                <th class="text-center" scope="row">3</th>';
                                                for ($k=12;$k<=17;$k++){ 
                                                                echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                                }
                                    echo   '</tr>
                                            <tr>
                                                <th class="text-center" scope="row">4</th>';
                                                for ($k=18;$k<=23;$k++){ 
                                                                echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                                }
                                    echo   '</tr>
                                            <tr>
                                                <th class="text-center" scope="row">5</th>';       
                                                for ($k=24;$k<=29;$k++){ 
                                                                echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                                }  
                                    echo   '</tr>
                                            <tr>
                                                <th class="text-center" scope="row">6</th>';
                                                for ($k=30;$k<=35;$k++){ 
                                                                echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                                }
                                    echo   '</tr>
                                            <tr>
                                                <th class="text-center" scope="row">7</th>';    
                                                for ($k=36;$k<=41;$k++){ 
                                                                echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                                }   
                                    echo   '</tr>
                                            <tr>
                                                <th class="text-center" scope="row">8</th>';    
                                                for ($k=42;$k<=47;$k++){ 
                                                                echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                                }    
                                    echo   '</tr>
                                            <tr>
                                                <th class="text-center" scope="row">9</th>';  
                                                for ($k=48;$k<=53;$k++){ 
                                                                echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                                } 
                                    echo   '</tr>                                       
                                        </tbody>
                                    </table><hr/>
                                    <div class="form-group">
                                            <label class="col-md-2 control-label">Link TKB:</label>
                                            <div class="col-md-10">
                                                <input type="text" class="form-control" readonly="" value="https://dkhp.quanancuongloan.com/luu-tkb.php?xem='.$url.'">
                                            </div>
                                    </div>';
                                    }

                            
                            
                                } else if (isset($_GET['xem'])){
                                    $url=$_GET['xem'];
                                    $lay=$ketnoi->query("SELECT * FROM `sep_tkb` WHERE `url`='$url'");
                                    if ($lay && $lay->num_rows>0){
                                        while($hien=$lay->fetch_assoc()){
                                            $data1=$hien['mahp'];
                                            $data2=$hien['kyhieu'];
                                        }
                                    } 
                                    $data1=unserialize($data1);
                                    $data2=unserialize($data2); 
                                    $n=count($data1);
                                    for ($i=0;$i<=$n;$i++){
                                        
                                        $lay_thoi_gian_hoc=$ketnoi->query("SELECT `thu`, `sotiet`,`tietbd` FROM `hocphan` WHERE `kyhieu`='$data2[$i]' AND `mahocphan`='$data1[$i]' ");
                                        if ($lay_thoi_gian_hoc && $lay_thoi_gian_hoc->num_rows>0)
                                        {
                                            while($lay_thoi_gian_hoc_kq=$lay_thoi_gian_hoc->fetch_assoc())
                                            {
                                                $thu=$lay_thoi_gian_hoc_kq['thu'];
                                                $tietbd=$lay_thoi_gian_hoc_kq['tietbd'];
                                                $sotiet=$lay_thoi_gian_hoc_kq['sotiet'];
                                                $tietbd_sosanh=$tietbd-1;
                                                if ($thu == 2){$thu_sosanh	= 0+($tietbd_sosanh*6);}
                                                if ($thu == 3){$thu_sosanh	= 1+($tietbd_sosanh*6);}
                                                if ($thu == 4){$thu_sosanh	= 2+($tietbd_sosanh*6);}
                                                if ($thu == 5){$thu_sosanh	= 3+($tietbd_sosanh*6);}
                                                if ($thu == 6){$thu_sosanh	= 4+($tietbd_sosanh*6);}
                                                if ($thu == 7){$thu_sosanh	= 5+($tietbd_sosanh*6);}
                                                $dem=0;
                                                for ($h=0;$h<=53;$h++){
                                                    if ($h==$thu_sosanh || ($h-$thu_sosanh)==($dem*6)){
                                                        if ($sotiet>0) 
                                                        {
                                                            $in_tkb[$h]=$data1[$i].'-'.$data2[$i];
                                                            $sotiet--;
                                                            $dem++;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    
                                    echo'
                                    
                                    <table class="table table-bordered m-0">
                                                <thead>
                                                    <tr>
                                                        <th class="text-center">Tiết</th>
                                                        <th class="text-center">Thứ 2</th>
                                                        <th class="text-center">Thứ 3</th>
                                                        <th class="text-center">Thứ 4</th>
                                                        <th class="text-center">Thứ 5</th>
                                                        <th class="text-center">Thứ 6</th>
                                                        <th class="text-center">Thứ 7</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                <tr>
                                                <th class="text-center" scope="row">1</th>';
                                                for ($k=0;$k<=5;$k++){ 
                                                                echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                                }
                                    echo   '</tr>
                                            <tr>
                                                <th class="text-center" scope="row">2</th>';
                                                for ($k=6;$k<=11;$k++){ 
                                                                echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                                }
                                    echo   '</tr>
                                            <tr>
                                                <th class="text-center" scope="row">3</th>';
                                                for ($k=12;$k<=17;$k++){ 
                                                                echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                                }
                                    echo   '</tr>
                                            <tr>
                                                <th class="text-center" scope="row">4</th>';
                                                for ($k=18;$k<=23;$k++){ 
                                                                echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                                }
                                    echo   '</tr>
                                            <tr>
                                                <th class="text-center" scope="row">5</th>';       
                                                for ($k=24;$k<=29;$k++){ 
                                                                echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                                }  
                                    echo   '</tr>
                                            <tr>
                                                <th class="text-center" scope="row">6</th>';
                                                for ($k=30;$k<=35;$k++){ 
                                                                echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                                }
                                    echo   '</tr>
                                            <tr>
                                                <th class="text-center" scope="row">7</th>';    
                                                for ($k=36;$k<=41;$k++){ 
                                                                echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                                }   
                                    echo   '</tr>
                                            <tr>
                                                <th class="text-center" scope="row">8</th>';    
                                                for ($k=42;$k<=47;$k++){ 
                                                                echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                                }    
                                    echo   '</tr>
                                            <tr>
                                                <th class="text-center" scope="row">9</th>';  
                                                for ($k=48;$k<=53;$k++){ 
                                                                echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                                } 
                                    echo   '</tr>                                       
                                        </tbody>
                                    </table><hr/>
                                    <div class="form-group">
                                            <label class="col-md-2 control-label">Link TKB:</label>
                                            <div class="col-md-10">
                                                <input type="text" class="form-control" readonly="" value="https://dkhp.quanancuongloan.com/luu-tkb.php?xem='.$url.'">
                                            </div>
                                    </div>';
                            
                            
                                } else {
                                    echo'
                                    <h5>CÁC TKB MỚI ĐƯỢC XẾP</h5>
                                    <table class="table table-bordered m-0">
                                                <thead>
                                                    <tr>
                                                        <th class="text-center">ID</th>
                                                        <th class="text-center">Người xếp</th>
                                                        <th class="text-center">Link</th>
                                                    </tr>
                                                </thead>
                                                <tbody>';
                                                
                                    $lay=$ketnoi->query("SELECT * FROM `sep_tkb` ORDER BY `id` DESC LIMIT 15");
                                    if ($lay && $lay->num_rows>0){
                                        while($hienthi=$lay->fetch_assoc()){
                                            echo '
                                            <tr>
                                            <th class="text-center" scope="row">'.$hienthi['id'].'</th>
                                            <th class="text-center" scope="row">'.$hienthi['so_huu'].'</th>
                                            <th class="text-center" scope="row"><a href="luu-tkb.php?xem='.$hienthi['url'].'" target="_blank" class="btn btn-xs btn-primary waves-effect waves-light m-b-5"> <i class="fa fa-rocket m-r-5"></i> <span>Xem</span> </a></th>
                                            </tr>';
                                        }
                                    }
                                    echo   '                                      
                                        </tbody>
                                    </table>';
                                }
                            }
                            else if (isset($_GET['xem'])){
                                $url=$_GET['xem'];
                                $lay=$ketnoi->query("SELECT * FROM `sep_tkb` WHERE `url`='$url'");
                                if ($lay && $lay->num_rows>0){
                                    while($hien=$lay->fetch_assoc()){
                                        $data1=$hien['mahp'];
                                        $data2=$hien['kyhieu'];
                                    }
                                } 
                                $data1=unserialize($data1);
                                $data2=unserialize($data2); 
                                $n=count($data1);
                                for ($i=0;$i<=$n;$i++){
                                    
                                    $lay_thoi_gian_hoc=$ketnoi->query("SELECT `thu`, `sotiet`,`tietbd` FROM `hocphan` WHERE `kyhieu`='$data2[$i]' AND `mahocphan`='$data1[$i]' ");
                                    if ($lay_thoi_gian_hoc && $lay_thoi_gian_hoc->num_rows>0)
                                    {
                                        while($lay_thoi_gian_hoc_kq=$lay_thoi_gian_hoc->fetch_assoc())
                                        {
                                            $thu=$lay_thoi_gian_hoc_kq['thu'];
                                            $tietbd=$lay_thoi_gian_hoc_kq['tietbd'];
                                            $sotiet=$lay_thoi_gian_hoc_kq['sotiet'];
                                            $tietbd_sosanh=$tietbd-1;
                                            if ($thu == 2){$thu_sosanh	= 0+($tietbd_sosanh*6);}
                                            if ($thu == 3){$thu_sosanh	= 1+($tietbd_sosanh*6);}
                                            if ($thu == 4){$thu_sosanh	= 2+($tietbd_sosanh*6);}
                                            if ($thu == 5){$thu_sosanh	= 3+($tietbd_sosanh*6);}
                                            if ($thu == 6){$thu_sosanh	= 4+($tietbd_sosanh*6);}
                                            if ($thu == 7){$thu_sosanh	= 5+($tietbd_sosanh*6);}
                                            $dem=0;
                                            for ($h=0;$h<=53;$h++){
                                                if ($h==$thu_sosanh || ($h-$thu_sosanh)==($dem*6)){
                                                    if ($sotiet>0) 
                                                    {
                                                        $in_tkb[$h]=$data1[$i].'-'.$data2[$i];
                                                        $sotiet--;
                                                        $dem++;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                
                                echo'
                                
                                <table class="table table-bordered m-0">
                                            <thead>
                                                <tr>
                                                    <th class="text-center">Tiết</th>
                                                    <th class="text-center">Thứ 2</th>
                                                    <th class="text-center">Thứ 3</th>
                                                    <th class="text-center">Thứ 4</th>
                                                    <th class="text-center">Thứ 5</th>
                                                    <th class="text-center">Thứ 6</th>
                                                    <th class="text-center">Thứ 7</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            <tr>
                                            <th class="text-center" scope="row">1</th>';
                                            for ($k=0;$k<=5;$k++){ 
                                                            echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                            }
                                echo   '</tr>
                                        <tr>
                                            <th class="text-center" scope="row">2</th>';
                                            for ($k=6;$k<=11;$k++){ 
                                                            echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                            }
                                echo   '</tr>
                                        <tr>
                                            <th class="text-center" scope="row">3</th>';
                                            for ($k=12;$k<=17;$k++){ 
                                                            echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                            }
                                echo   '</tr>
                                        <tr>
                                            <th class="text-center" scope="row">4</th>';
                                            for ($k=18;$k<=23;$k++){ 
                                                            echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                            }
                                echo   '</tr>
                                        <tr>
                                            <th class="text-center" scope="row">5</th>';       
                                            for ($k=24;$k<=29;$k++){ 
                                                            echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                            }  
                                echo   '</tr>
                                        <tr>
                                            <th class="text-center" scope="row">6</th>';
                                            for ($k=30;$k<=35;$k++){ 
                                                            echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                            }
                                echo   '</tr>
                                        <tr>
                                            <th class="text-center" scope="row">7</th>';    
                                            for ($k=36;$k<=41;$k++){ 
                                                            echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                            }   
                                echo   '</tr>
                                        <tr>
                                            <th class="text-center" scope="row">8</th>';    
                                            for ($k=42;$k<=47;$k++){ 
                                                            echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                            }    
                                echo   '</tr>
                                        <tr>
                                            <th class="text-center" scope="row">9</th>';  
                                            for ($k=48;$k<=53;$k++){ 
                                                            echo '<td class="text-center">'.$in_tkb[$k].'</td>';
                                            } 
                                echo   '</tr>                                       
                                    </tbody>
                                </table><hr/>
                                <div class="form-group">
                                        <label class="col-md-2 control-label">Link TKB:</label>
                                        <div class="col-md-10">
                                            <input type="text" class="form-control" readonly="" value="https://dkhp.quanancuongloan.com/luu-tkb.php?xem='.$url.'">
                                        </div>
                                </div>';
                        
                        
                            }
                            else echo '
                                    <div class="alert alert-danger alert-dismissible fade in text-center" role="alert"> Vui lòng đăng nhập để tiếp tục bạn nhé!
                                    </div>';

                                    ?>
                            </div>
                        </div>
                    </div>
                    
                </div>
                <!-- Footer -->
                <footer class="footer text-right">
                    <div class="container">
                        <div class="row">
                            <div class="col-xs-12 text-center">
                                © 2020. Lieu Tuan Vu B1906810. Có sử dụng nội dung từ trang Quản lí đào tạo CTU
                            </div>
                        </div>
                    </div>
                </footer>
                <!-- End Footer -->

            </div> <!-- end container -->
        </div>
        <!-- end wrapper -->


        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/detect.js"></script>
        <script src="assets/js/fastclick.js"></script>
        <script src="assets/js/jquery.blockUI.js"></script>
        <script src="assets/js/waves.js"></script>
        <script src="assets/js/jquery.slimscroll.js"></script>
        <script src="assets/js/jquery.scrollTo.min.js"></script>
        <script src="assets/sweetalert/sweet-alert.min.js"></script>
        <script src="switchery/switchery.min.js"></script>


        <!-- init -->

        <!-- App js -->
        <script src="assets/js/jquery.core.js"></script>
        <script src="assets/js/jquery.app.js"></script>

        

    </body>
</html>