<?php
include_once("cosodulieu.php");
$ketnoi= new mysqli($db_host,$db_user,$db_pass,$db_name);
$taikhoan="";
$chuyen_huong="";
$matkhau="";
if (!isset($_SESSION['user']))
{   $hienthi='                                
    <div class="account-content">
        <form class="form-horizontal" action="dang_nhap.php" method="post">
            <div class="form-group ">
                <div class="col-xs-12">
                    <input class="form-control" name="taikhoan" value="'.$taikhoan.'" type="text" required="" placeholder="Tài khoản">
                </div>
            </div>
            <div class="form-group">
                <div class="col-xs-12">
                    <input class="form-control" name="matkhau" value="'.$matkhau.'" type="password" required="" placeholder="Mật khẩu">
                </div>
            </div>
            <div class="form-group account-btn text-center m-t-10">
                <div class="col-xs-12">
                    <button class="btn w-md btn-bordered btn-danger waves-effect waves-light" type="submit">Đăng nhập</button>
                </div>
            </div>
        </form>
        <div class="clearfix"></div>
    </div>
    <div class="row m-t-50">
    <div class="col-sm-12 text-center">
        <p class="text-muted"><a href="dang_ky.php" class="text-primary m-l-5"><b>Bấm vào đây để đăng ký</b></a></p>
    </div>
    </div>  ';} else
    {   $chuyen_huong='<meta http-equiv="refresh" content="5 url=/" >';
        $hienthi='                                
                    <div class="account-content">
                            <div class="text-center m-b-20">
                                <div class="m-b-20">
                                    <div class="checkmark">
                                        <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                                                viewBox="0 0 161.2 161.2" enable-background="new 0 0 161.2 161.2" xml:space="preserve">
                                            <path class="path" fill="none" stroke="#4bd396" stroke-miterlimit="10" d="M425.9,52.1L425.9,52.1c-2.2-2.6-6-2.6-8.3-0.1l-42.7,46.2l-14.3-16.4
                                                c-2.3-2.7-6.2-2.7-8.6-0.1c-1.9,2.1-2,5.6-0.1,7.7l17.6,20.3c0.2,0.3,0.4,0.6,0.6,0.9c1.8,2,4.4,2.5,6.6,1.4c0.7-0.3,1.4-0.8,2-1.5
                                                c0.3-0.3,0.5-0.6,0.7-0.9l46.3-50.1C427.7,57.5,427.7,54.2,425.9,52.1z"/>
                                            <circle class="path" fill="none" stroke="#4bd396" stroke-width="4" stroke-miterlimit="10" cx="80.6" cy="80.6" r="62.1"/>
                                            <polyline class="path" fill="none" stroke="#4bd396" stroke-width="6" stroke-linecap="round" stroke-miterlimit="10" points="113,52.8
                                                74.1,108.4 48.2,86.4 "/>
                                            <circle class="spin" fill="none" stroke="#4bd396" stroke-width="4" stroke-miterlimit="10" stroke-dasharray="12.2175,12.2175" cx="80.6" cy="80.6" r="73.9"/>
                                        </svg>
                                    </div>
                                </div>
                                <p class="text-muted"> Bạn đã đăng nhập thành công,<a href="/" class="text-primary m-l-5">bấm vào đây </a>để bắt đầu thực hành đăng ký học phần nhé ^^! </p>
                            </div>
                    </div>';
    }

$thongbao="";
if ((!isset($_POST['taikhoan'])) && !isset($_POST['matkhau'])){
    if (!isset($_SESSION['user']))
    {$thongbao="hay_dang_nhap()";};
} else if ((!isset($_POST['taikhoan']) || !isset($_POST['matkhau']))){
    $thongbao="nhap_day_du()";
}  else {
            $taikhoan=$_POST['taikhoan'];
            $matkhau=$_POST['matkhau'];
        $kiemtra_taikhoan=$ketnoi->query("SELECT `user`,`pass` FROM `sinhvien` WHERE `user`='$taikhoan'");
        if (mysqli_num_rows($kiemtra_taikhoan)==0){
            $thongbao="tai_khoan_khong_ton_tai()";
        } else if(mysqli_num_rows($kiemtra_taikhoan)>0) {
                $sosanh_matkhau=mysqli_fetch_array($kiemtra_taikhoan);
                $matkhau=md5($matkhau);
                if ($sosanh_matkhau['pass'] != $matkhau){
                    $thongbao="sai_mat_khau();";
                    $matkhau="";
                } else 
                {
                    $_SESSION['user']=$taikhoan;
                    $thongbao="dn_thanh_cong();";
                    $matkhau="";
                    $chuyen_huong='<meta http-equiv="refresh" content="5 url=/" >';
                    $hienthi='                                
                    <div class="account-content">
                            <div class="text-center m-b-20">
                                <div class="m-b-20">
                                    <div class="checkmark">
                                        <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                                                viewBox="0 0 161.2 161.2" enable-background="new 0 0 161.2 161.2" xml:space="preserve">
                                            <path class="path" fill="none" stroke="#4bd396" stroke-miterlimit="10" d="M425.9,52.1L425.9,52.1c-2.2-2.6-6-2.6-8.3-0.1l-42.7,46.2l-14.3-16.4
                                                c-2.3-2.7-6.2-2.7-8.6-0.1c-1.9,2.1-2,5.6-0.1,7.7l17.6,20.3c0.2,0.3,0.4,0.6,0.6,0.9c1.8,2,4.4,2.5,6.6,1.4c0.7-0.3,1.4-0.8,2-1.5
                                                c0.3-0.3,0.5-0.6,0.7-0.9l46.3-50.1C427.7,57.5,427.7,54.2,425.9,52.1z"/>
                                            <circle class="path" fill="none" stroke="#4bd396" stroke-width="4" stroke-miterlimit="10" cx="80.6" cy="80.6" r="62.1"/>
                                            <polyline class="path" fill="none" stroke="#4bd396" stroke-width="6" stroke-linecap="round" stroke-miterlimit="10" points="113,52.8
                                                74.1,108.4 48.2,86.4 "/>
                                            <circle class="spin" fill="none" stroke="#4bd396" stroke-width="4" stroke-miterlimit="10" stroke-dasharray="12.2175,12.2175" cx="80.6" cy="80.6" r="73.9"/>
                                        </svg>
                                    </div>
                                </div>
                                <p class="text-muted"> Bạn đã đăng nhập thành công,<a href="/" class="text-primary m-l-5">bấm vào đây </a>để bắt đầu thực hành đăng ký học phần nhé ^^! </p>
                            </div>
                    </div>';
                }
        }
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="Trang web giả lập đăng ký học phần, hỗ trợ sinh viên - Liêu Tuấn Vũ CTU">
        <link rel="shortcut icon" href="assets/images/favicon.ico">
        <?php echo $chuyen_huong;?>
        <title>Đăng nhập hệ thống</title>
        <!-- App css -->
        <link href="assets/toastr/toastr.min.css" rel="stylesheet" type="text/css" />

        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/core.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/components.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/pages.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/menu.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/responsive.css" rel="stylesheet" type="text/css" />

    </head>
    <body>
        <section>
            <div class="container-alt">
                <div class="row">
                    <div class="col-sm-12">

                        <div class="wrapper-page">

                            <div class="m-t-40 account-pages">
                                <div class="text-center account-logo-box">
                                    <h2 class="text-uppercase">
                                        <a href="dang_nhap.php" class="text-muted">
                                        Đăng nhập tài khoản
                                        </a>
                                    </h2>
                                </div>
                                <?php echo $hienthi;?>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
          </section>
          <!-- END HOME -->

        <script>
            var resizefunc = [];
        </script>

        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/detect.js"></script>
        <script src="assets/js/fastclick.js"></script>
        <script src="assets/js/jquery.blockUI.js"></script>
        <script src="assets/js/waves.js"></script>
        <script src="assets/js/jquery.slimscroll.js"></script>
        <script src="assets/js/jquery.scrollTo.min.js"></script>
        <script src="assets/toastr/toastr.min.js"></script>
        <script src="assets/toastr/jquery.toastr.js"></script>
        <!-- App js -->
        <script src="assets/js/jquery.core.js"></script>
        <script src="assets/js/jquery.app.js"></script>
        <script>
            function dn_thanh_cong(){
                toastr["success"]("Bạn đã đăng nhập thành công, hãy thực hành đăng ký học phần nhé!", "Thành công");

                toastr.options = {
                "closeButton": false,
                "debug": false,
                "newestOnTop": false,
                "progressBar": false,
                "positionClass": "toast-top-center",
                "preventDuplicates": false,
                "onclick": null,
                "showDuration": "300",
                "hideDuration": "1000",
                "timeOut": "20000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
                }
            }
            function sai_mat_khau(){
                toastr["error"]("Mật khẩu bạn nhập không đúng rồi, bạn nhập lại mật khẩu nhé, hoặc bạn có thể đăng ký tài khoản mới đó bạn :(", "Mật khẩu không chính xác")

                toastr.options = {
                "closeButton": false,
                "debug": false,
                "newestOnTop": false,
                "progressBar": false,
                "positionClass": "toast-top-center",
                "preventDuplicates": false,
                "onclick": null,
                "showDuration": "300",
                "hideDuration": "1000",
                "timeOut": "5000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
                }
            }
            function tai_khoan_khong_ton_tai(){
                toastr["error"]("Tài khoản không tồn tại trên hệ thống, bạn vui lòng nhập lại tài khoản hoặc đăng ký tài khoản mới bạn nhé :(", "Tài khoản không tồn tại")

                toastr.options = {
                "closeButton": false,
                "debug": false,
                "newestOnTop": false,
                "progressBar": false,
                "positionClass": "toast-top-center",
                "preventDuplicates": false,
                "onclick": null,
                "showDuration": "300",
                "hideDuration": "1000",
                "timeOut": "5000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
                }
            }
            function co_loi_xayra(){
                toastr["error"]("Đã có lỗi xảy ra, bạn vui lòng thử lại sau nhé :(", "Đã có lỗi xảy ra")

                toastr.options = {
                "closeButton": false,
                "debug": false,
                "newestOnTop": false,
                "progressBar": false,
                "positionClass": "toast-top-center",
                "preventDuplicates": false,
                "onclick": null,
                "showDuration": "300",
                "hideDuration": "1000",
                "timeOut": "5000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
                }
            }
            function nhap_day_du(){
                toastr["error"]("Nhập đầy đủ tài khoản và mật khẩu để có thể đăng nhập bạn nhé! :(", "Hãy nhập đầy đủ tài khoản và mật khẩu")

                toastr.options = {
                "closeButton": false,
                "debug": false,
                "newestOnTop": false,
                "progressBar": false,
                "positionClass": "toast-top-center",
                "preventDuplicates": false,
                "onclick": null,
                "showDuration": "300",
                "hideDuration": "1000",
                "timeOut": "5000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
                }
            }
            function hay_dang_nhap(){
                toastr["info"]("Hãy đăng nhập tài khoản để thử đăng ký học phần cho quen bạn nhé ^^", "Hãy đăng nhập")

                toastr.options = {
                "closeButton": false,
                "debug": false,
                "newestOnTop": false,
                "progressBar": false,
                "positionClass": "toast-top-center",
                "preventDuplicates": false,
                "onclick": null,
                "showDuration": "300",
                "hideDuration": "1000",
                "timeOut": "5000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
                }
            }
            <?php echo $thongbao;?>
        </script>
    </body>
</html>