<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta charset="UTF-8">
	 <meta http-equiv="refresh" content="0 url=dangkyhocphan.php" >
	<title></title>
</head>
<body>
<?php 
	include_once("cosodulieu.php");
	$ketnoi = new mysqli($db_host, $db_user, $db_pass, $db_name);
	mysqli_set_charset($ketnoi, 'UTF8');
if(isset($_SESSION['user'])){
				// Phần này lấy ID của user
				$tai_khoan=$_SESSION['user'];
				$lay_id=$ketnoi->query("SELECT `ID` FROM `sinhvien` WHERE `user` ='$tai_khoan'");
				if ($lay_id && $lay_id->num_rows>0){
					while($lay_id_array=$lay_id->fetch_assoc())
					{
						$id=$lay_id_array['ID'];
					}
				}
				$tim_hp_trong_kehoachhoctap=$ketnoi->query("SELECT * FROM `kehoachhoctap` WHERE `ID`='$id'");
				// Hết phần lấy ID user
	if (!isset($_GET['maph'])){
		 echo"Bạn không có quyền truy cập vào trang này đâu nhé ^^";
	} else
	{
		$mahp=$_GET['maph'];
		// Lấy ký hiệu học phần để update lại sỉ số lớp
		$lay_ky_hieu=$ketnoi->query("SELECT `kyhieu` FROM `dkhocphan` WHERE `mahp` ='$mahp' AND `ID`='$id'");
		if ($lay_ky_hieu && $lay_ky_hieu ->num_rows>0)
		{
			while ($in_ky_hieu=$lay_ky_hieu->fetch_assoc())
			{
				$kyhieuhp=$in_ky_hieu['kyhieu'];
			}
		}
		// Lấy ký hiệu học phần để update lại sỉ số lớp
		$lenh="DELETE FROM `dkhocphan` WHERE `mahp` ='$mahp' AND `ID`='$id' ";
		$kq=mysqli_query($ketnoi,$lenh);
		$siso_conlaihientai=0;
		$update_siso=$ketnoi->query("SELECT `sisoconlai` FROM `hocphan` WHERE `mahocphan`='$mahp' AND `kyhieu`='$kyhieuhp'");
		if($update_siso && $update_siso->num_rows>0){
			while($lay_siso=$update_siso->fetch_assoc())
			{
				$siso_conlaihientai=(int)$lay_siso['sisoconlai'];
			}
		}
		$siso_conlaihientai++;
		$lenh_update_siso="UPDATE `hocphan` SET `sisoconlai`='$siso_conlaihientai' WHERE `mahocphan`='$mahp' AND `kyhieu`='$kyhieuhp'";
		$update_siso_thanhcong=mysqli_query($ketnoi,$lenh_update_siso);
		if ($kq && $update_siso_thanhcong) {

			 header("dangkyhocphan.php");
		 }
	}

} else echo"Bạn không có quyền truy cập vào trang này đâu nhé ^^";
?>
</body>
</html>