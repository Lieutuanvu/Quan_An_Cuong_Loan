<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body>
	<?php 
	include_once("cosodulieu.php");
	$ketnoi = new mysqli($db_host, $db_user, $db_pass, $db_name);
	mysqli_set_charset($ketnoi, 'UTF8');
	$mahp=$_GET['maph'];
	$trang=$_GET['trang'];
	$thuchien=$_GET['thuchien'];
	if (!isset($_SESSION['user']))
	{
		echo "Bạn không có quyền truy cập vào trang này bạn nhé ^^";
	}else{
		$tai_khoan=$_SESSION['user'];
		$lay_id=$ketnoi->query("SELECT `ID` FROM `sinhvien` WHERE `user` ='$tai_khoan'");
		if ($lay_id && $lay_id->num_rows>0){
			while($lay_id_array=$lay_id->fetch_assoc())
			{
				$id=$lay_id_array['ID'];
			}
		}
		$sql="INSERT INTO `kehoachhoctap`(`ID`, `mahp`) VALUES ('$id','$mahp')";
		$kiemtra="SELECT * FROM `kehoachhoctap` WHERE `mahp`='$mahp' AND `ID`='$id' ";
		$ktt=mysqli_query($ketnoi,$kiemtra);
		if ($thuchien=="1"){
			if (mysqli_num_rows($ktt)==0)
			{
				$kq=mysqli_query($ketnoi,$sql);
				if ($kq) {
				 	header('Location: ds_dk_hocphan.php?trang='.$trang);
				 }
			}
		} else {
			$sql="DELETE FROM `kehoachhoctap` WHERE `ID`='$id' AND `mahp`='$mahp'";
			$kq=mysqli_query($ketnoi,$sql);
			if ($kq) {
				 header('Location: ds_dk_hocphan.php?trang='.$trang);
			 }
		}


	}
	 ?>
</body>
</html>