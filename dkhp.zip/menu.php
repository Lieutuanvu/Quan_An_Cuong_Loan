<?php
if (!isset($_SESSION['user']))
{
    $chucnang='                            
    <li class="dropdown navbar-c-items">
        <a href="dang_nhap.php" class="right-menu-item dropdown-toggle">
            <i class="mdi mdi-login"></i>
            <span class="badge up bg-danger">Đăng nhập</span>
        </a>
    </li>';
} 
else $chucnang='                            
    <li class="dropdown navbar-c-items">
        <a href="dang_xuat.php" class="right-menu-item dropdown-toggle">
            <i class=" mdi mdi-logout"></i>
            <span class="badge up bg-danger">Đăng xuất</span>
        </a>
    </li>';
?>
<header id="topnav">
            <div class="topbar-main">
                <div class="container">
                    <div class="logo">
                        <a href="/" class="logo">
                            Mô phỏng đăng ký học phần
                        </a>
                    </div>
                    <div class="menu-extras">
                    <ul class="nav navbar-nav navbar-right pull-right">
                    <?php echo $chucnang;?>
                    </ul>
                    <div class="menu-item">
                            <!-- Mobile menu toggle-->
                            <a class="navbar-toggle">
                                <div class="lines">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </div>
                            </a>
                            <!-- End mobile menu toggle-->
                        </div>
                    </div>
                </div> <!-- end container -->
            </div>

            <div class="navbar-custom">
                <div class="container">
                    <div id="navigation">
                        <!-- Navigation Menu-->
                        <ul class="navigation-menu">
                            <li class="has-submenu">
                                <a href="index.php"><i class="mdi mdi-view-dashboard"></i>Tra cứu học phần</a>
                            </li>
                            <li class="has-submenu">
                                <a href="ds_dk_hocphan.php"><i class="mdi mdi-diamond"></i>Đăng ký kế hoạch học tập</a>
                            </li>
                            <li class="has-submenu">
                                <a href="khht.php"><i class="mdi mdi-book-multiple"></i>Kế hoạch học tập</a>
                            </li>
                            <li class="has-submenu">
                                <a href="dangkyhocphan.php"><i class="mdi mdi-book-multiple"></i>Đăng ký học phần</a>
                            </li>
							<li class="has-submenu">
                                <a href="auto-2.php"><i class="mdi mdi-book-multiple"></i>Tự xếp lớp</a>
                            </li>
                        </ul>
                        <!-- End navigation menu -->
                    </div> <!-- end #navigation -->
                </div> <!-- end container -->
            </div> <!-- end navbar-custom -->
        </header>