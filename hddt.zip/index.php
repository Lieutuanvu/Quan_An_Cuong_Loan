<html><head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="Hoá đơn điện tử Quán Ăn Cường Loan.">
        <meta name="author" content="Quán Ăn Cường Loan">
        <link rel="shortcut icon" href="assets/images/favicon.ico">
        <title>Hoá đơn điện tử - Quán Ăn Cường Loan</title>
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="assets/css/core.css" rel="stylesheet" type="text/css">
        <link href="assets/css/components.css" rel="stylesheet" type="text/css">
        <script src="https://use.fontawesome.com/973e9903c3.js"></script>
        <link href="assets/css/menu.css" rel="stylesheet" type="text/css">
        <link href="assets/css/responsive.css" rel="stylesheet" type="text/css">

    </head>
    <body>

        <div class="wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                            <?php
                            include_once("cosodulieu.php");
                            if (!isset($_POST['mhd'])){
                                echo '
                                    <img src="img/logo_website_QACL.PNG"/>
                                    <form role="form" method="post">
                                        <div class="form-group">
                                            <label for="mhd">Mã hoá đơn để tra cứu:</label>
                                            <input autofocus type="text" class="form-control" name="mhd" id="mhd" placeholder="Mã hoá đơn của Quý khách">
                                        </div>
                                        <button type="submit" class="btn btn-purple waves-effect waves-light">Xem hoá đơn</button>
                                    </form>';
                            } else if (isset($_POST['mhd'])){
                                $mhd=$_POST['mhd'];
                                $xem_hd=$ketnoi->query("SELECT * FROM `hoadon_vanchuyen` WHERE `id_hoadon`='$mhd'");
                                if ($xem_hd && $xem_hd->num_rows<=0){
                                    echo '
                                    <img src="img/logo_website_QACL.PNG"/>
                                    <div class="alert alert-danger" role="alert">
                                        Mã hoá đơn Quý khách vừa nhập không có trên hệ thống!
                                    </div>
                                        <form role="form" method="post">
                                            <div class="form-group">
                                                <label for="mhd">Mã hoá đơn để tra cứu:</label>
                                                <input autofocus type="text" class="form-control" name="mhd" id="mhd" placeholder="Mã hoá đơn của Quý khách">
                                            </div>
                                            <button type="submit" class="btn btn-purple waves-effect waves-light">Xem hoá đơn</button>
                                        </form>';
                                } else if ($xem_hd && $xem_hd->num_rows>0) {
                                    while($xuat=$xem_hd->fetch_assoc()){
                                    echo'
                                        <style>
                                        .wrapper {
                                            padding-top: 5px;
                                        }
                                        </style>
                                        <div class="panel panel-default">
                                            <div class="panel-body">
                                                <div class="clearfix">
                                                    <div class="pull-left">
                                                        <img src="img/logo_website_QACL.PNG"/>
                                                        <p class="text-inverse font-600">101/17 Hùng Vương, P6, Tp.Sóc Trăng, Sóc Trăng</br>SĐT: 02993826498 - 02993623056 - 0918084371 - 0828084371</p>
                                                    </div>
                                                </div>
                                                <hr>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="pull-left m-t-30">
                                                            <p><strong>Mã hoá đơn: </strong>'.$xuat['id_hoadon'].'</p>
                                                            <p><strong>Khách hàng: </strong>'.$xuat['diachi'].' - '.$xuat['cachlienhe'].'</p>
                                                            
                                                            <p><strong>Tạo lúc: </strong>'.$xuat['gio_tao'].' ngày '.date_format(new DateTime($xuat['ngaytao']),'d-m-Y').'</p>';
                                                                                                                        
                                                            if ($xuat['trang_thai']==1){
                                                                $ng_xac_nhan=$xuat['nguoi_xac_nhan'];
                                                                $layten_nv=$ketnoi->query("SELECT `hoten` FROM `nhanvien` WHERE `ma_nv`='$ng_xac_nhan'");
                                                                if ($layten_nv && $layten_nv->num_rows>0){
                                                                    while($nv=$layten_nv->fetch_assoc()){
                                                                        $nhanvien=$nv['hoten'];
                                                                        $nhanvien="<p><strong>Nhân viên: </strong>".$nhanvien.'</p>';
                                                                        echo'<p><strong>Trạng thái: </strong> <span class="label label-success">Đã thanh toán</span></p>';
                                                                        echo '<p><strong>Thanh toán lúc: </strong>'.$xuat['gio_thanhtoan'].' ngày '.date_format(new DateTime($xuat['ngay_thanhtoan']),'d-m-Y').'</p>';       
                                                                        echo $nhanvien;

                                                                    }
                                                                }
                                                            } else {
                                                                echo'<p><strong>Trạng thái: </strong> <span class="label label-danger">Chưa thanh toán</span></p>';

                                                            } 
                                            echo'           
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="m-h-50"></div>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="table-responsive">
                                                            <table class="table m-t-30">
                                                                <thead>
                                                                    <tr>
                                                                    <th class="text-center">#</th>
                                                                    <th class="text-center">Tên món</th>
                                                                    <th class="text-center">Số lượng</th>
                                                                    <th class="text-center">Đơn giá</th>
                                                                    <th class="text-center">Thành tiền</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>';
                                                                echo '<tr>';
                                                                echo '<td class="text-center">1</td>';
                                                                echo '<td class="text-left">'.$xuat['tenmon_1'].'</td>';
                                                                echo '<td class="text-center">'.$xuat['soluong_1'].'</td>';
                                                                echo '<td class="text-center">'.number_format($xuat['dongia_1'],0,'.','.').'</td>';
                                                                echo '<td class="text-center">'.number_format($xuat['dongia_1']*$xuat['soluong_1'],0,'.','.').'</td>';
                                                                echo '</tr>';
                                                                if ($xuat['tenmon_2']!=""){
                                                                    echo '<tr>';
                                                                    echo '<td class="text-center">2</td>';
                                                                    echo '<td class="text-left">'.$xuat['tenmon_2'].'</td>';
                                                                    echo '<td class="text-center">'.$xuat['soluong_2'].'</td>';
                                                                    echo '<td class="text-center">'.number_format($xuat['dongia_2'],0,'.','.').'</td>';
                                                                    echo '<td class="text-center">'.number_format($xuat['dongia_2']*$xuat['soluong_2'],0,'.','.').'</td>';
                                                                    echo '</tr>';
                                                                }
                                                                if ($xuat['tenmon_3']!=""){
                                                                    echo '<tr>';
                                                                    echo '<td class="text-center">3</td>';
                                                                    echo '<td class="text-left">'.$xuat['tenmon_3'].'</td>';
                                                                    echo '<td class="text-center">'.$xuat['soluong_3'].'</td>';
                                                                    echo '<td class="text-center">'.number_format($xuat['dongia_3'],0,'.','.').'</td>';
                                                                    echo '<td class="text-center">'.number_format($xuat['dongia_3']*$xuat['soluong_3'],0,'.','.').'</td>';
                                                                    echo '</tr>';
                                                                }
                                                                if ($xuat['tenmon_4']!=""){
                                                                    echo '<tr>';
                                                                    echo '<td class="text-center">4</td>';
                                                                    echo '<td class="text-left">'.$xuat['tenmon_4'].'</td>';
                                                                    echo '<td class="text-center">'.$xuat['soluong_4'].'</td>';
                                                                    echo '<td class="text-center">'.number_format($xuat['dongia_4'],0,'.','.').'</td>';
                                                                    echo '<td class="text-center">'.number_format($xuat['dongia_4']*$xuat['soluong_4'],0,'.','.').'</td>';
                                                                    echo '</tr>';
                                                                }
                                                                if ($xuat['tenmon_5']!=""){
                                                                    echo '<tr>';
                                                                    echo '<td class="text-center">5</td>';
                                                                    echo '<td class="text-left">'.$xuat['tenmon_5'].'</td>';
                                                                    echo '<td class="text-center">'.$xuat['soluong_5'].'</td>';
                                                                    echo '<td class="text-center">'.number_format($xuat['dongia_5'],0,'.','.').'</td>';
                                                                    echo '<td class="text-center">'.number_format($xuat['dongia_5']*$xuat['soluong_5'],0,'.','.').'</td>';
                                                                    echo '</tr>';
                                                                }
                                                                if ($xuat['tenmon_6']!=""){
                                                                    echo '<tr>';
                                                                    echo '<td class="text-center">6</td>';
                                                                    echo '<td class="text-left">'.$xuat['tenmon_6'].'</td>';
                                                                    echo '<td class="text-center">'.$xuat['soluong_6'].'</td>';
                                                                    echo '<td class="text-center">'.number_format($xuat['dongia_6'],0,'.','.').'</td>';
                                                                    echo '<td class="text-center">'.number_format($xuat['dongia_6']*$xuat['soluong_6'],0,'.','.').'</td>';
                                                                    echo '</tr>';
                                                                }
                                                                if ($xuat['tenmon_7']!=""){
                                                                    echo '<tr>';
                                                                    echo '<td class="text-center">7</td>';
                                                                    echo '<td class="text-left">'.$xuat['tenmon_7'].'</td>';
                                                                    echo '<td class="text-center">'.$xuat['soluong_7'].'</td>';
                                                                    echo '<td class="text-center">'.number_format($xuat['dongia_7'],0,'.','.').'</td>';
                                                                    echo '<td class="text-center">'.number_format($xuat['dongia_7']*$xuat['soluong_7'],0,'.','.').'</td>';
                                                                    echo '</tr>';
                                                                }
                                                                if ($xuat['tenmon_8']!=""){
                                                                    echo '<tr>';
                                                                    echo '<td class="text-center">8</td>';
                                                                    echo '<td class="text-left">'.$xuat['tenmon_8'].'</td>';
                                                                    echo '<td class="text-center">'.$xuat['soluong_8'].'</td>';
                                                                    echo '<td class="text-center">'.number_format($xuat['dongia_8'],0,'.','.').'</td>';
                                                                    echo '<td class="text-center">'.number_format($xuat['dongia_8']*$xuat['soluong_8'],0,'.','.').'</td>';
                                                                    echo '</tr>';
                                                                }
                                                                if ($xuat['tenmon_9']!=""){
                                                                    echo '<tr>';
                                                                    echo '<td class="text-center">9</td>';
                                                                    echo '<td class="text-left">'.$xuat['tenmon_9'].'</td>';
                                                                    echo '<td class="text-center">'.$xuat['soluong_9'].'</td>';
                                                                    echo '<td class="text-center">'.number_format($xuat['dongia_9'],0,'.','.').'</td>';
                                                                    echo '<td class="text-center">'.number_format($xuat['dongia_9']*$xuat['soluong_9'],0,'.','.').'</td>';
                                                                    echo '</tr>';
                                                                }
                                                                if ($xuat['tenmon_10']!=""){
                                                                    echo '<tr>';
                                                                    echo '<td class="text-center">10</td>';
                                                                    echo '<td class="text-left">'.$xuat['tenmon_10'].'</td>';
                                                                    echo '<td class="text-center">'.$xuat['soluong_10'].'</td>';
                                                                    echo '<td class="text-center">'.number_format($xuat['dongia_10'],0,'.','.').'</td>';
                                                                    echo '<td class="text-center">'.number_format($xuat['dongia_10']*$xuat['soluong_10'],0,'.','.').'</td>';
                                                                    echo '</tr>';
                                                                }
                                            $sotien=$xuat['thanhtien'];
                                            echo'               </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-6 col-sm-6 col-xs-6">
                                                        <p class="text-inverse font-600" id="tienbangchu"></p>
                                                    </div>
                                                    <div class="col-md-3 col-sm-6 col-xs-6 col-md-offset-3">
                                                        <p class="text-right"><b>Tổng cộng:</b> '.number_format($xuat['thanhtien'],0,'.','.').'</p>
                                                        
                                                    </div>
                                                </div>
                                                <hr>
                                                <div class="hidden-print">
                                                    <div class="pull-right">
                                                        <a href="javascript:window.print()" class="btn btn-inverse waves-effect waves-light"><i class="fa fa-print"></i> In</a>
                                                        <a href="https://quanancuongloan.com" class="btn btn-danger waves-effect waves-light">Thoát</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>';
                                    }
                                }
                            }
                            ?>
                    </div>
                </div>
            </div> 
        </div>
<script>  
var Number=function(){var t=["không","một","hai","ba","bốn","năm","sáu","bảy","tám","chín"],r=function(r,n){var o="",a=Math.floor(r/10),e=r%10;return a>1?(o=" "+t[a]+" mươi",1==e&&(o+=" mốt")):1==a?(o=" mười",1==e&&(o+=" một")):n&&e>0&&(o=" lẻ"),5==e&&a>=1?o+=" lăm":4==e&&a>=1?o+=" tư":(e>1||1==e&&0==a)&&(o+=" "+t[e]),o},n=function(n,o){var a="",e=Math.floor(n/100),n=n%100;return o||e>0?(a=" "+t[e]+" trăm",a+=r(n,!0)):a=r(n,!1),a},o=function(t,r){var o="",a=Math.floor(t/1e6),t=t%1e6;a>0&&(o=n(a,r)+" triệu",r=!0);var e=Math.floor(t/1e3),t=t%1e3;return e>0&&(o+=n(e,r)+" nghìn",r=!0),t>0&&(o+=n(t,r)),o};return{doc:function(r){if(0==r)return t[0];var n="",a="";do ty=r%1e9,r=Math.floor(r/1e9),n=r>0?o(ty,!0)+a+n:o(ty,!1)+a+n,a=" tỷ";while(r>0);return n.trim()}}}();
document.getElementById("tienbangchu").innerHTML="Tiền bằng chữ: "+Number.doc(<?php echo $sotien;?>)+" đồng (VND)";
</script>  
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/detect.js"></script>
        <script src="assets/js/fastclick.js"></script>
        <script src="assets/js/waves.js"></script>
        <script src="assets/js/jquery.slimscroll.js"></script>
        <script src="assets/js/jquery.scrollTo.min.js"></script>
    
</body></html>